<?php

/**
 * 腾讯QQ一键登录验证类
 */

class QQ {
    
    //配置APP参数
    private $app_id;
    private $app_secret;
    
    public function __construct($appId, $appSecret) {
        $this->app_id = $appId;
        $this->app_secret = $appSecret;
    }
    
    /**
     * 获取access_token
     * @param string $code 登陆后返回的code
     * @param string $redirect 跳转地址
     */
    public function get_access_token($code, $redirect) {
//        $filename = APP_PATH . '/library/Auth/json/qq_access_token.json';
//        $token = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
        $expires_in = 0;//isset($token['expires_in']) ? (int)$token['expires_in'] : 0;
        if ($expires_in < __TIME__) {
            $query = array(
                'grant_type' => 'authorization_code',
                'client_id' => $this->app_id,
                'redirect_uri' => urlencode($redirect),
                'client_secret' => $this->app_secret,
                'code' => $code
            );
            $token_url = 'https://graph.qq.com/oauth2.0/token?' . http_build_query($query);
            parse_str($this->_curl_get_content($token_url), $token);
            
//            if (isset($token['access_token'])) {
//                $token['expires_in'] = (int)$token['expires_in'] + time();
//                file_put_contents($filename, json_encode($token));
//            }
        }
        return $token;
    }
    
    /**
     * 获取用户唯一ID(openid)
     * @param string $token 授权码
     */
    public function get_open_id($token) {
        $str = $this->_curl_get_content('https://graph.qq.com/oauth2.0/me?unionid=1&access_token=' . $token);
        if (strpos($str, 'callback') !== false) {
            $lpos = strpos($str, '(');
            $rpos = strrpos($str, ')');
            $str = substr($str, $lpos + 1, $rpos - $lpos - 1);
        }
        $user = json_decode($str, true);
        return $user;
    }
    
    /**
     * 获取用户信息
     * @param string $token 授权码
     * @param string $open_id 用户唯一ID
     */
    public function get_user_info($token, $open_id) {
        $query = array(
            'access_token' => $token,
            'oauth_consumer_key' => $this->app_id,
            'openid' => $open_id,
            'format' => 'json'
        );
        $user_info_url = 'https://graph.qq.com/user/get_user_info?' . http_build_query($query);
        $info = json_decode($this->_curl_get_content($user_info_url), true);
        
        return $info;
    }
    
    private function _curl_get_content($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        
        //设置超时时间为3s
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}