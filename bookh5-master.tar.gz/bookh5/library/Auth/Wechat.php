<?php

/**
 * 微信一键登录验证类
 */

class Wechat {
    
    //配置APP参数
    private $app_id;
    private $app_secret;
    
    public function __construct($appId, $appSecret) {
        $this->app_id = $appId;
        $this->app_secret = $appSecret;
    }
    
    /**
     * 获取access_token
     * @param string $code 登陆后返回的code
     */
    public function get_access_token($code) {
        $filename = APP_PATH . '/library/Auth/json/wx_access_token.json';
//        $token = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
//        $expires_in = isset($token['expires_in']) ? (int)$token['expires_in'] : 0;
        $expires_in = 0;
        if ($expires_in < __TIME__) {
            $query = array(
                'appid' => $this->app_id,
                'secret' => $this->app_secret,
                'code' => $code,
                'grant_type' => 'authorization_code',
            );
            $token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?' . http_build_query($query);
            $token = json_decode($this->_curl_get_content($token_url), true);
            
            if (!isset($token['errcode'])) {
                $token['expires_in'] = (int)$token['expires_in'] + time();
                file_put_contents($filename, json_encode($token));
            }
        }
        return $token;
    }
    
    /**
     * 获取用户信息
     * @param string $token 授权码
     * @param string $open_id 用户唯一ID
     */
    public function get_user_info($token, $open_id) {
        $query = array(
            'access_token' => $token,
            'openid' => $open_id,
            'lang' => 'zh_CN'
        );
        $user_info_url = 'https://api.weixin.qq.com/sns/userinfo?' . http_build_query($query);
        $info = json_decode($this->_curl_get_content($user_info_url), true);
        
        return $info;
    }
    
    private function _curl_get_content($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        
        //设置超时时间为3s
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}