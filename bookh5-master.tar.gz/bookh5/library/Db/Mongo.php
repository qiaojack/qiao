<?php

namespace Db;

/**
 * Mongo管理器
 */
class Mongo {

    private static $_connects;
    private $_db = null;
    private $_conn = null;

    /**
     * 取得Mongo实例
     * @param string $id
     * @return \MongoClient
     * @throws \Exception
     */
    static public function getInstance($id = 'default') {
        if (!isset(self::$_connects[$id])) {
            $config = \Yaf_Application::app()->getConfig()->db->mongo;
            if (!isset($config->$id)) {
                throw new \Exception("not found mongo_config for {$id}", E_ERROR);
            }
            $db_config = $config->$id;

            $options = array();
            if (strstr($db_config->hosts, ',') !== false) {
                $options['replicaSet'] = 'myReplSet';
            }

            $con_str = 'mongodb://';
            if ((string) $db_config->username !== '' && (string) $db_config->password !== '') {
                $con_str .= $db_config->username . ':' . $db_config->password . '@';
            }
            $con_str .= $db_config->hosts;
            if ((string) $db_config->options !== '') {
                $con_str .= '?' . $db_config->options;
            }

            //连接 mongo
            $conf = ['url' => $con_str, 'dbname' => $db_config->dbname];
            $mongo = new Mongo($conf, $options);
            self::$_connects[$id] = $mongo;
        }
        return self::$_connects[$id];
    }

    private function __construct(array $conf) {
        $this->_conn = new \MongoDB\Driver\Manager($conf['url'] . '/' . $conf['dbname']);
        $this->_db = $conf['dbname'];
    }

    /**
     * 获取当前mongoDB Manager
     * @return MongoDB\Driver\Manager
     */
    public function getMongoManager() {
        return $this->_conn;
    }

    /**
     * 执行MongoDB命令
     * @param array $param
     * @return \MongoDB\Driver\Cursor
     */
    public function command(array $param) {
        $cmd = new \MongoDB\Driver\Command($param);
        return $this->_conn->executeCommand($this->_db, $cmd);
    }

    /**
     * 查询
     * @param string $collname 集合名称
     * @param array $filter [query]参数详情请参见文档
     * @return \MongoDB\Driver\Cursor
     */
    public function query($collname, array $filter, array $writeOps = []) {
        $cmd = [
            'find' => $collname,
            'filter' => $filter
        ];
        $cmd += $writeOps;
        return $this->command($cmd);
    }

    /**
     * 插入数据
     * @param string $collname 集合名称
     * @param array $documents [["name"=>"values", ...], ...]
     * @param array $writeOps ["ordered"=>boolean,"writeConcern"=>array]
     * @return \MongoDB\Driver\Cursor
     */
    public function insert($collname, array $documents, array $writeOps = []) {
        $cmd = [
            'insert' => $collname,
            'documents' => $documents,
        ];
        $cmd += $writeOps;
        return $this->command($cmd);
    }

    /**
     * 更新数据
     * @param string $collname 集合名称
     * @param array $updates [["q"=>query,"u"=>update,"upsert"=>boolean,"multi"=>boolean], ...]
     * @param array $writeOps ["ordered"=>boolean,"writeConcern"=>array]
     * @return \MongoDB\Driver\Cursor
     */
    public function update($collname, array $updates, array $writeOps = []) {
        $cmd = [
            'update' => $collname,
            'updates' => $updates,
        ];
        $cmd += $writeOps;
        return $this->command($cmd);
    }

    /**
     * 删除数据
     * @param string $collname 集合名称
     * @param array $deletes [["q"=>query,"limit"=>int], ...]
     * @param array $writeOps ["ordered"=>boolean,"writeConcern"=>array]
     * @return \MongoDB\Driver\Cursor
     */
    public function del($collname, array $deletes, array $writeOps = []) {
        foreach ($deletes as &$_) {
            if (isset($_['q']) && !$_['q']) {
                $_['q'] = (Object) [];
            }
            if (isset($_['limit']) && !$_['limit']) {
                $_['limit'] = 0;
            }
        }
        $cmd = [
            'delete' => $collname,
            'deletes' => $deletes,
        ];
        $cmd += $writeOps;
        return $this->command($cmd);
    }

}
