<?php

namespace Db;

/**
 * Redis管理器
 */
class Redis {
    
    //链接
    private $_db = array();
    
    //实例
    private static $_instances = array();
    
    //redis config
    private static $_db_config = null;
    
    //当前redis链接
    private $_redis = null;
    
    //当前是否写操作
    private $_is_write = false;
    
    /**
     * 取得Redis实例
     * @param string $id
     * @return \Redis
     * @throws \Exception
     */
    static public function getInstance($id = 'default') {
        if (!isset(self::$_instances[$id])) {
            $config = \Yaf_Application::app()->getConfig()->db->redis;
            if (!isset($config) || !isset($config->$id)) {
                throw new \Exception("not found redis_config for {$id}", E_ERROR);
            }
            self::$_db_config = $config;
            $db_config = $config->$id;
            self::$_instances[$id] = new static($db_config);
        }
        return self::$_instances[$id];
    }
    
    /**
     * 链接Redis
     * @throws \Exception
     */
    private function connect() {
        $db_key = "redis_";
        // 取得配置
        if (isset(self::$_db_config->default)) {
            //增删改操作主库
            if ($this->_is_write) {
                $db_key .= "master";
                $db_config = self::$_db_config->default->master;
            } else {
                $db_key .= "slave";
                $db_config = self::$_db_config->default->slave;
            }
        } else {
            $db_key .= "default";
            $db_config = self::$_db_config;
        }
        
        if (!isset($this->_db[$db_key])) {
            $redis = new \Redis(); //连接redis
            $redis->connect($db_config->host, $db_config->port); //设置option
            if (!empty($db_config->prefix)) {
                $redis->setOption(\Redis::OPT_PREFIX, $db_config->prefix);
            }
            switch ($db_config->serializer) {
                case 'none':
                    $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_NONE);
                    break;
                case 'php':
                    $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_PHP);
                    break;
                case 'igbinary':
                    if (extension_loaded('igbinary')) {
                        $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_IGBINARY);
                    }
                    break;
                default:
                    $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_NONE);
                    break;
            }
            if (isset($db_config->auth)) {
                $redis->auth($db_config->auth);
            }
            if ($db_config->db !== '') {
                $redis->select((int) $db_config->db);
            }
            $this->_db[$db_key] = $redis;
        }
        $this->_redis = $this->_db[$db_key];
    }
    
    /**
     * 是否为master，并返回Redis链接实例
     * @param boolean $master 是否为写主库
     */
    public function isMaster($master = true) {
        //如果是写操作，一定走主库
        if ($master) {
            $this->_is_write = true;
        }
        $this->connect();
        $this->_is_write = false;
        return $this->_redis;
    }
    
    /**
     * 判断KEY是否存在
     * @param string $key KEY
     */
    public function exists($key) {
        $redis = $this->isMaster(false);
        return $redis->exists($key);
    }
    
    /**
     * 返回满足给定pattern的所有key
     * @param string $pattern
     */
    public function keys($pattern) {
        $redis = $this->isMaster(false);
        return $redis->keys($pattern);
    }
    
    /**
     * 删除缓存
     * @param string $key KEY
     */
    public function del($key) {
        $redis = $this->isMaster(true);
        return $redis->del($key);
    }
    
    /**
     * 清空当前数据库的缓存
     * @param string $key KEY
     */
    public function flushdb() {
        $redis = $this->isMaster(true);
        return $redis->flushdb();
    }
    
    /**
     * 设定一个key的活动时间
     * @param string $key KEY
     * @param int $expire 过期时间(单位:秒)
     */
    public function expire($key, $expire) {
        $redis = $this->isMaster(true);
        return $redis->expire($key, $expire);
    }
    
    /**
     * 给数据库中名称为key的string赋予值value
     * @param string $key
     * @param string $value
     */
    public function set($key, $value) {
        $redis = $this->isMaster(true);
        $redis->set($key, $value);
    }
    
    /**
     * 向库中添加string（名称为key，值为value）同时，设定过期时间time
     * @param string $key KEY
     * @param int $expire 过期时间
     * @param string $value 值
     */
    public function setex($key, $expire, $value) {
        $redis = $this->isMaster(true);
        $redis->setex($key, $expire, $value);
    }
    
    /**
     * 如果不存在名称为key的string，则向库中添加string，名称为key，值为value
     * @param string $key KEY
     * @param string $value 值
     */
    public function setnx($key, $value) {
        $redis = $this->isMaster(true);
        $redis->setnx($key, $value);
    }
    
    /**
     * 返回数据库中名称为key的string的value
     * @param string $key KEY
     */
    public function get($key) {
        $redis = $this->isMaster(false);
        return $redis->get($key);
    }
    
    /**
     * 名称为key的string增加integer
     * @param string $key KEY
     * @param int $integer 增加值
     */
    public function incrby($key, $integer) {
        $redis = $this->isMaster(true);
        return $redis->incrby($key, $integer);
    }
    
    /**
     * 名称为key的string减少integer
     * @param string $key
     * @param int $integer 减少值
     */
    public function decrby($key, $integer) {
        $redis = $this->isMaster(true);
        return $redis->decrby($key, $integer);
    }
    
    /**
     * 在名称为key的list尾添加一个值为value的元素
     * @param string $key
     * @param string $value
     */
    public function rpush($key, $value) {
        $redis = $this->isMaster(true);
        return $redis->rpush($key, $value); //尾部插入
    }
    
    /**
     * 在名称为key的list头添加一个值为value的 元素
     * @param string $key
     * @param string $value
     */
    public function lpush($key, $value) {
        $redis = $this->isMaster(true);
        return $redis->lpush($key, $value); //头部插入
    }
    
    /**
     * 返回名称为key的list的长度
     * @param string $key KEY
     */
    public function llen($key) {
        $redis = $this->isMaster(false);
        return $redis->llen($key);
    }
    
    /**
     * 返回名称为key的list中start至end之间的元素（下标从0开始）
     * @param string $key KEY
     * @param int $start 开始值
     * @param int $end 结束值
     */
    public function lrange($key, $start, $end) {
        $redis = $this->isMaster(false);
        return $redis->lrange($key, $start, $end);
    }
    
    /**
     * 返回并删除名称为key的list中的首元素
     * @param string $key KEY
     */
    public function lpop($key) {
        $redis = $this->isMaster(true);
        return $redis->lpop($key);
    }
    
    /**
     * 返回并删除名称为key的list中的尾元素
     * @param string $key KEY
     */
    public function rpop($key) {
        $redis = $this->isMaster(true);
        return $redis->rpop($key);
    }
    
    /**
     * 向名称为key的set中添加元素member
     * @param string $key
     * @param string $member
     */
    public function sadd($key, $member) {
        $redis = $this->isMaster(true);
        return $redis->sadd($key, $member);
    }
    
    /**
     * 删除名称为key的set中的元素member
     * @param string $key
     * @param string $member
     */
    public function srem($key, $member) {
        $redis = $this->isMaster(true);
        return $redis->srem($key, $member);
    }
    
    /**
     * 向名称为key的zset中添加元素member，score用于排序
     * 如果该元素已经存在，则根据score更新该元素的顺序
     * @param string $key
     * @param int $score
     * @param string $member
     */
    public function zadd($key, $score, $member) {
        $redis = $this->isMaster(true);
        return $redis->zadd($key, $score, $member);
    }
    
    /**
     * 删除名称为key的zset中的元素member
     * @param string $key
     * @param string $member
     */
    public function zrem($key, $member) {
        $redis = $this->isMaster(true);
        return $redis->zrem($key, $member);
    }
    
    /**
     * 如果在名称为key的zset中已经存在元素member，则该元素的score增加increment
     * 否则向集合中添加该元素，其score的值为increment
     * @param string $key
     * @param int $increment
     * @param string $member
     */
    public function zincrby($key, $increment, $member) {
        $redis = $this->isMaster(true);
        return $redis->zincrby($key, $increment, $member);
    }
    
    /**
     * 顺序返回名称为key的zset中的index从start到end的所有元素
     * @param string $key KEY
     * @param int $start 开始值
     * @param end $end 截止值
     */
    public function zrange($key, $start, $end) {
        $redis = $this->isMaster(false);
        return $redis->zrange($key, $start, $end);
    }
    
    /**
     * 逆序返回名称为key的zset中的index从start到end的所有元素
     * @param string $key KEY
     * @param int $start 开始值
     * @param end $end 截止值
     */
    public function zrevrange($key, $start, $end) {
        $redis = $this->isMaster(false);
        return $redis->zrevrange($key, $start, $end);
    }
    
    /**
     * 返回名称为key的hash中field对应的value
     * @param string $key
     * @param string $field
     * @param string $value
     */
    public function hset($key, $field, $value) {
        $redis = $this->isMaster(true);
        return $redis->hset($key, $field, $value);
    }
    
    /**
     * 向名称为key的hash中添加元素field<—>value
     * @param string $key KEY
     * @param string $field 域
     * @param string $value 值
     */
    public function hget($key, $field) {
        $redis = $this->isMaster(false);
        return $redis->hget($key, $field);
    }
    
    /**
     * 名称为key的hash中是否存在键为field的域
     * @param string $key KEY
     * @param string $field 域
     */
    public function hexists($key, $field) {
        $redis = $this->isMaster(false);
        return $redis->hexists($key, $field);
    }
    
    /**
     * 删除名称为key的hash中键为field的域
     * @param string $key KEY
     * @param string $field 域
     */
    public function hdel($key, $field) {
        $redis = $this->isMaster(true);
        return $redis->hdel($key, $field);
    }
    
    /**
     * 将名称为key的hash中field的value增加integer
     * @param string $key
     * @param string $field
     * @param int $integer
     */
    public function hincrby($key, $field, $integer) {
        $redis = $this->isMaster(true);
        return $redis->hincrby($key, $field, $integer);
    }
    
    /**
     * 返回名称为key的hash中元素个数
     * @param string $key
     */
    public function hlen($key) {
        $redis = $this->isMaster(false);
        return $redis->hlen($key);
    }
    
    /**
    *禁止外部克隆对象  
    */
    private function __clone() {
    }
    
    //销毁链接
    public function disconnect() {
        if (!empty($this->_redis)) {
            $this->_db = array();
            $this->_redis = null;
        }
    }
}
