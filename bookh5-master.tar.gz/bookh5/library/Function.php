
<?php

/* 常用工具函数 */

/**
 * 浏览器友好的变量输出
 * @return type
 */
function dump() {
    $args = func_get_args();

    ob_start();
    foreach ($args as $val) {
        var_dump($val);
    }
    $output = ob_get_clean();

    if (!extension_loaded('xdebug') && !__IS_CGI__) {
        $output = preg_replace('/\]\=\>\n(\s+)/m', '] => ', $output);
        $output = '<pre>' . htmlspecialchars($output, ENT_QUOTES) . '</pre>';
    }
    echo '<pre>';
    echo $output;
    exit;
    return;
}
/**
 * 把返回的数据集转换成Tree
 * @param array $list 要转换的数据集
 * @param string $pid parent标记字段
 * @param string $level level标记字段
 * @return array
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function list_to_tree($list, $pk='id', $pid = 'pid', $child = 'child', $root = 0) {
    // 创建Tree
    $tree = array();
    if(is_array($list)) {
        // 创建基于主键的数组引用
        $refer = array();
        foreach ($list as $key => $data) {
            $refer[$data[$pk]] =& $list[$key];
        }

        foreach ($list as $key => $data) {
            // 判断是否存在parent
            $parentId =  $data[$pid];
            if ($root == $parentId) {
                $tree[] =& $list[$key];
            }else{
                if (isset($refer[$parentId])) {
                    $parent =& $refer[$parentId];
                    $parent[$child][] =& $list[$key];
                }
            }
        }
    }
    return $tree;
}

    function findson($arr,$id=0){  
        //$id栏目的儿子有哪些呢？  
        //答数组循环一遍，谁的parent值等于$id，谁就是它儿子  
        $sons=array(); //子栏目数组  
        foreach($arr as $v){  
            if($v['parent']==$id){  
                $sons[]=$v;  
            }  
        }  
     return $sons;  
    }  
    
/**
 * 优化的require_once
 * @staticvar array $_importFiles
 * @param string $filename
 * @return file_content
 */
function require_cache($filename) {
    static $_importFiles = array();

    if (!file_exists_case($filename) || !is_readable($filename))
        return false;

    $realpath = realpath($filename);
    if (!isset($_importFiles[$realpath])) {
        require $filename;
        $_importFiles[$realpath] = true;
    }
    return $_importFiles[$realpath];
}

/**
 * 判断文件是否存在 (区分大小写)
 * @param string $filename
 * @return boolean
 */
function file_exists_case($filename) {
    if (!is_file($filename)) {
        return false;
    }
    if (basename(realpath($filename)) != basename($filename)) {
        return false;
    }

    return true;
}

/**
 * 循环创建目录
 * @param string $dir
 * @param type $mode
 * @return boolean
 */
function mk_dir($dir, $mode = 0777) {
    if (is_dir($dir) || @mkdir($dir, $mode, true))
        return true;
    if (!mk_dir(dirname($dir), $mode))
        return false;
    return @mkdir($dir, $mode, true);
}

/**
 * 批量创建目录
 * @param array $dirs
 * @param type $mode
 * @return boolean
 */
function mk_dirs(array $dirs, $mode = 0777) {
    if (!is_array($dirs))
        return false;
    foreach ($dirs as $dir) {
        if (!is_dir($dir))
            mk_dir($dir, $mode);
    }
}

/**
 * 删除目录及目录下所有文件或删除指定文件
 * @param string $path 待删除目录路径
 * @param boolean $delDir 是否删除目录，1或true删除目录，0或false则只删除文件保留目录（包含子目录）
 */
function delDirAndFile($path, $delDir = false) {
    if (!is_dir($path)) return false;
    $handle = opendir($path);
    if ($handle) {
        while (false !== ( $item = readdir($handle) )) {
            if ($item != "." && $item != "..")
                is_dir("$path/$item") ? delDirAndFile("$path/$item", $delDir) : unlink("$path/$item");
        }
        closedir($handle);
        if ($delDir)
            return rmdir($path);
    } else {
        if (file_exists($path)) {
            return unlink($path);
        } else {
            return false;
        }
    }
}

/**
 * 字符串截取，支持中文和其他编码
 * @param string $str 需要转换的字符串
 * @param string $start 开始位置
 * @param string $length 截取长度
 * @param string $charset 编码格式
 * @param string $suffix 截断显示字符
 */
function msubstr($str, $start = 0, $length = null, $charset = 'utf-8', $suffix = true) {
    if (function_exists('mb_substr')) {
        return mb_substr($str, $start, $length, $charset);
    } elseif (function_exists('iconv_substr')) {
        return iconv_substr($str, $start, $length, $charset);
    }

    $re['utf-8'] = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
    $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
    $re['gbk'] = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
    $re['big5'] = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
    preg_match_all($re[$charset], $str, $match);
    $slice = join('', array_slice($match[0], $start, $length));
    if ($suffix)
        return $slice . '...';
    return $slice;
}

/**
 * XML编码
 * @param mixed $data 数据
 * @param string $encoding 数据编码
 * @param string $root 根节点名
 * @return string
 */
function xml_encode($data, $encoding = 'utf-8', $root = '') {
    $xml = '<?xml version="1.0" encoding="' . $encoding . '"?>';
    $xml.= data_to_xml($data);
    if (!empty($root)) {
        $xml = "<{$root}>{$xml}</{$root}>";
    }

    return $xml;
}

/**
 * 数据XML编码
 * @param mixed $data 数据
 */
function data_to_xml($data) {
    if (is_object($data)) {
        $data = get_object_vars($data);
    }
    $xml = '';
    foreach ($data as $key => $val) {
        is_numeric($key) && $key = 'item id="' . $key . '"';
        $xml.='<' . $key . '>';
        $xml.= ( is_array($val) || is_object($val)) ? data_to_xml($val) : $val;
        list($key, ) = explode(' ', $key);
        $xml.='</' . $key . '>';
    }
    return $xml;
}

/**
 * 多维数组排序
 * @param array $multi_array 排序的数组
 * @param string $sort_key 需排序的KEY
 * @param string $sort 排序方式
 */
function multi_array_sort($multi_array, $sort_key, $sort = SORT_ASC) {
    if (is_array($multi_array)) {
        foreach ($multi_array as $row_array) {
            if (is_array($row_array)) {
                $key_array[] = $row_array[$sort_key];
            } else {
                return false;
            }
        }
    } else {
        return false;
    }
    if (!empty($key_array) && !empty($multi_array)) {
        array_multisort($key_array, $sort, $multi_array);
    }
    return $multi_array;
}

/**
 * URL重定向
 * @param string $url
 * @param int $time
 * @param string $msg
 */
function redirect($url, $time = 0, $msg = '') {
    //多行URL地址支持
    $url = str_replace(array("\n", "\r"), '', $url);
    if (empty($msg))
        $msg = '系统将在' . $time . '秒之后自动跳转到' . $url . '！';
    if (!headers_sent()) {
        // redirect
        if (0 === $time) {
            header('Location: ' . $url);
        } else {
            header('refresh:' . $time . ';url=' . $url);
            echo($msg);
        }
        exit();
    } else {
        $str = '<meta http-equiv="Refresh" content="' . $time . ';URL=' . $url . '">';
        if ($time != 0) {
            $str .= $msg;
        }
        exit($str);
    }
}

/**
 * 产生随机字串，可用来自动生成密码 默认长度6位 字母和数字混合
 * @param string $len 长度
 * @param string $type 字串类型
 * 1:字母(大小写混合); 2:数字; 3:特殊符号; 4:中文
 * @param string $addChars 额外字符
 */
function rand_string($len = 6, $type = null, $addChars = null) {
    $str = '';
    switch ($type) {
        case 1:
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' . $addChars;
            break;
        case 2:
            $chars = str_repeat('0123456789', 3);
            break;
        case 3:
            $chars = '~!@#$%^&*()-_=+{}[]|?<>' . $addChars;
            break;
        case 4:
            $chars = '们以我到他会作时要动国产的一是工就年阶义发成部民可出能方进在了不和有大这主中人上为来分生对于学下级地个用同行面说种过命度革而多子后自社加小机也经力线本电高量长党得实家定深法表着水理化争现所二起政三好十战无农使性前等反体合斗路图把结第里正新开论之物从当两些还天资事队批点育重其思与间内去因件日利相由压员气业代全组数果期导平各基或月毛然如应形想制心样干都向变关问比展那它最及外没看治提五解系林者米群头意只明四道马认次文通但条较克又公孔领军流入接席位情运器并飞原油放立题质指建区验活众很教决特此常石强极土少已根共直团统式转别造切九你取西持总料连任志观调七么山程百报更见必真保热委手改管处己将修支识病象几先老光专什六型具示复安带每东增则完风回南广劳轮科北打积车计给节做务被整联步类集号列温装即毫知轴研单色坚据速防史拉世设达尔场织历花受求传口断况采精金界品判参层止边清至万确究书术状厂须离再目海交权且儿青才证低越际八试规斯近注办布门铁需走议县兵固除般引齿千胜细影济白格效置推空配刀叶率述今选养德话查差半敌始片施响收华觉备名红续均药标记难存测士身紧液派准斤角降维板许破述技消底床田势端感往神便贺村构照容非搞亚磨族火段算适讲按值美态黄易彪服早班麦削信排台声该击素张密害侯草何树肥继右属市严径螺检左页抗苏显苦英快称坏移约巴材省黑武培著河帝仅针怎植京助升王眼她抓含苗副杂普谈围食射源例致酸旧却充足短划剂宣环落首尺波承粉践府鱼随考刻靠够满夫失包住促枝局菌杆周护岩师举曲春元超负砂封换太模贫减阳扬江析亩木言球朝医校古呢稻宋听唯输滑站另卫字鼓刚写刘微略范供阿块某功套友限项余倒卷创律雨让骨远帮初皮播优占死毒圈伟季训控激找叫云互跟裂粮粒母练塞钢顶策双留误础吸阻故寸盾晚丝女散焊功株亲院冷彻弹错散商视艺灭版烈零室轻血倍缺厘泵察绝富城冲喷壤简否柱李望盘磁雄似困巩益洲脱投送奴侧润盖挥距触星松送获兴独官混纪依未突架宽冬章湿偏纹吃执阀矿寨责熟稳夺硬价努翻奇甲预职评读背协损棉侵灰虽矛厚罗泥辟告卵箱掌氧恩爱停曾溶营终纲孟钱待尽俄缩沙退陈讨奋械载胞幼哪剥迫旋征槽倒握担仍呀鲜吧卡粗介钻逐弱脚怕盐末阴丰雾冠丙街莱贝辐肠付吉渗瑞惊顿挤秒悬姆烂森糖圣凹陶词迟蚕亿矩康遵牧遭幅园腔订香肉弟屋敏恢忘编印蜂急拿扩伤飞露核缘游振操央伍域甚迅辉异序免纸夜乡久隶缸夹念兰映沟乙吗儒杀汽磷艰晶插埃燃欢铁补咱芽永瓦倾阵碳演威附牙芽永瓦斜灌欧献顺猪洋腐请透司危括脉宜笑若尾束壮暴企菜穗楚汉愈绿拖牛份染既秋遍锻玉夏疗尖殖井费州访吹荣铜沿替滚客召旱悟刺脑措贯藏敢令隙炉壳硫煤迎铸粘探临薄旬善福纵择礼愿伏残雷延烟句纯渐耕跑泽慢栽鲁赤繁境潮横掉锥希池败船假亮谓托伙哲怀割摆贡呈劲财仪沉炼麻罪祖息车穿货销齐鼠抽画饲龙库守筑房歌寒喜哥洗蚀废纳腹乎录镜妇恶脂庄擦险赞钟摇典柄辩竹谷卖乱虚桥奥伯赶垂途额壁网截野遗静谋弄挂课镇妄盛耐援扎虑键归符庆聚绕摩忙舞遇索顾胶羊湖钉仁音迹碎伸灯避泛亡答勇频皇柳哈揭甘诺概宪浓岛袭谁洪谢炮浇斑讯懂灵蛋闭孩释乳巨徒私银伊景坦累匀霉杜乐勒隔弯绩招绍胡呼痛峰零柴簧午跳居尚丁秦稍追梁折耗碱殊岗挖氏刃剧堆赫荷胸衡勤膜篇登驻案刊秧缓凸役剪川雪链渔啦脸户洛孢勃盟买杨宗焦赛旗滤硅炭股坐蒸凝竟陷枪黎救冒暗洞犯筒您宋弧爆谬涂味津臂障褐陆啊健尊豆拔莫抵桑坡缝警挑污冰柬嘴啥饭塑寄赵喊垫丹渡耳刨虎笔稀昆浪萨茶滴浅拥穴覆伦娘吨浸袖珠雌妈紫戏塔锤震岁貌洁剖牢锋疑霸闪埔猛诉刷狠忽灾闹乔唐漏闻沈熔氯荒茎男凡抢像浆旁玻亦忠唱蒙予纷捕锁尤乘乌智淡允叛畜俘摸锈扫毕璃宝芯爷鉴秘净蒋钙肩腾枯抛轨堂拌爸循诱祝励肯酒绳穷塘燥泡袋朗喂铝软渠颗惯贸粪综墙趋彼届墨碍启逆卸航衣孙龄岭骗休借' . $addChars;
            break;
        default :
            // 默认去掉了容易混淆的字符oOLl和数字01，要添加请使用addChars参数
            $chars = 'ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789' . $addChars;
            break;
    }
    $chars_len = mb_strlen($chars, 'utf-8');
    //位数过长重复字符串一定次数
    if ($len > $chars_len && $type != 4) {
        $chars = str_shuffle(str_repeat($chars, ceil($len / $chars_len)));
        $str = substr($chars, 0, $len);
    } else {
        // 中文随机字
        for ($i = 0; $i < $len; $i++) {
            $str.= msubstr($chars, mt_rand(0, $chars_len - 1), 1);
        }
    }
    return $str;
}

/**
 * 获取客户端IP地址
 * @staticvar null $ip
 */
function get_client_ip() {
    static $ip = null;
    if ($ip !== null) {
        return $ip;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($arr[0]);
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

/**
 * 解析命令行中传参
 * example: ./test.php --l=4 -d --n=6
 * @param array $argv
 */
function arguments(array $argv) {
    $_ARG = array();
    foreach ($argv as $arg) {
        $reg = array();
        if (preg_match('/--([^=]+)=(.*)/', $arg, $reg)) {
            $_ARG[$reg[1]] = $reg[2];
        } elseif (preg_match('/^-([a-zA-Z0-9])/', $arg, $reg)) {
            $_ARG[$reg[1]] = 'true';
        }
    }
    return $_ARG;
}

/**
 * 字节格式化 把字节数格式为 B K M G T 描述的大小
 */
function byte_format($size, $dec = 2) {
    $a = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
    $pos = 0;
    while ($size >= 1024) {
        $size /= 1024;
        $pos++;
    }
    return round($size, $dec) . ' ' . $a[$pos];
}

function base64_encode4url($str) {
    $baseStr = base64_encode($str);
    $search = array('+', '/', '=');
    $replace = array('*', '-', '.');
    return str_replace($search, $replace, $baseStr);
}

function base64_decode4url($str) {
    $search = array('*', '-', '.');
    $replace = array('+', '/', '=');
    $str = str_replace($search, $replace, $str);
    return base64_decode($str);
}

/**
 * 快速掉用RPC
 * @param string $server_addr
 * @param string $method
 * @param array $parameters
 * @param string $charset
 * @return mixed 如果返回值为 -9999, 则表示RPC错误
 */
function fast_rpc_call($server_addr, $method, array $parameters, $charset = 'utf-8') {
    $request = xmlrpc_encode_request($method, $parameters, array(
        'escaping' => 'markup',
        'encoding' => $charset
    ));
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-Type: text/xml',
            'content' => $request
        )
    ));
    $_response = file_get_contents($server_addr, null, $context);

    $response = xmlrpc_decode($_response);
    if (is_array($response)) {
        if (xmlrpc_is_fault($response)) {
            return - 9999;
        }
    }
    return $response;
}

/**
 * 对字符串进行XSS安全过滤
 * @param string $string 要过滤的字符 
 */
function remove_xss($string) {
    $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/S', '', $string);
    $parm1 = Array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');
    $parm2 = Array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload');
    $parm = array_merge($parm1, $parm2);

    for ($i = 0; $i < sizeof($parm); $i++) {
        $pattern = '/';
        for ($j = 0; $j < strlen($parm[$i]); $j++) {
            if ($j > 0) {
                $pattern .= '(';
                $pattern .= '(&#[x|X]0([9][a][b]);?)?';
                $pattern .= '|(&#0([9][10][13]);?)?';
                $pattern .= ')?';
            }
            $pattern .= $parm[$i][$j];
        }
        $pattern .= '/i';
        $string = preg_replace($pattern, ' ', $string);
    }
    return $string;
}

/**
 * 去掉HTML、空格等特殊字符
 * @param string $str 字符串
 */
function cutstr_html($str) {
    $str = strip_tags($str);
    $str = preg_replace("/\t/", '', $str); //使用正则表达式替换内容，如：空格，换行，并将替换为空。
    $str = preg_replace("/\r\n/", '', $str);
    $str = preg_replace("/\r/", '', $str);
    $str = preg_replace("/\n/", '', $str);
    $str = preg_replace('/( |　|\s)*/', '', $str); //匹配html中的空格
    $str = str_replace('&nbsp;', '', $str);
    return trim($str); //返回字符串 
}

/**
 * 判断图片链接是否能打开
 * @param string $url 图片链接
 */
function url_exists($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    //不下载
    curl_setopt($ch, CURLOPT_NOBODY, 1);
    //设置超时
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($http_code == 200) {
        return true;
    }
    return false;
}

/**
 * 格式化成某种时间展示
 * @param string $the_time 要格式化的时间
 */
/** 
 * 计算几分钟前、几小时前、几天前、几月前、几年前。 
 * @param int $agoTime 时间戳
 */  
function time_ago($agoTime) {
    //计算出当前日期时间到之前的日期时间的毫秒数
    $time = time() - $agoTime;
    
    if ($time >= 31104000) { // N年前  
        $num = (int) ($time / 31104000);
        return $num . '年前';
    }
    if ($time >= 2592000) { // N月前  
        $num = (int) ($time / 2592000);
        return $num . '月前';
    }
    if ($time >= 86400) { // N天前  
        $num = (int) ($time / 86400);
        return $num . '天前';
    }
    if ($time >= 3600) { // N小时前  
        $num = (int) ($time / 3600);
        return $num . '小时前';
    }
    if ($time > 60) { // N分钟前  
        $num = (int) ($time / 60);
        return $num . '分钟前';
    }
    return '1分钟前';
}

/**
 * 返回http的状态码 
 * @param string $url 
 */
function get_http_code($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url); //设置URL
    curl_setopt($curl, CURLOPT_HEADER, 1); //获取Header
    curl_setopt($curl, CURLOPT_NOBODY, true); //Body就不要了吧，我们只是需要Head
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //数据存到成字符串吧，别给我直接输出到屏幕了
    curl_exec($curl);
    $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    
    return $code;
}

/**
 * 把秒数转换为时分秒的格式
 * @param Int $times 时间，单位 秒
 */
function secToTime($times){
    $result = '00:00:00';
    if ($times>0) {
        $hour = floor($times/3600);
        $minute = floor(($times-3600 * $hour)/60);
        $second = floor((($times-3600 * $hour) - 60 * $minute) % 60);
        $result = $hour.':'.$minute.':'.$second;
    }
    return $result;
}

/**
 * 获取指定日期段内每一天的日期
 * @param  Date  $startdate 开始日期
 * @param  Date  $enddate   结束日期
 */
function getDateFromRange($startdate, $enddate) {
    $stimestamp = strtotime($startdate);
    $etimestamp = strtotime($enddate);

    //计算日期段内有多少天
    $days = ($etimestamp - $stimestamp) / 86400 + 1;

    //保存每天日期
    $date = array();
    for ($i = 0; $i < $days; $i++) {
        $date[] = date('Ymd', $stimestamp + (86400 * $i));
    }

    return $date;
}

/**
 * 从array中取出指定字段
 * @param $array
 * @param $key
 * @return array|null
 */
function simpleArray($array, $key) {
    if (!empty($array) && is_array($array)) {
        $result = array();
        foreach ($array as $k => $item) {
            $result[$k] = $item[$key];
        }
        return $result;
    }
    return null;
}

//返回当前的毫秒时间戳
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float) sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    return $msectime;
}

/**
 * 过滤字符串中可能引起SQL注入的字符串
 * @param string $keyword 关键字
 */
function real_escape_string($keyword) {
    $arr = array('and', 'AND', 'execute', 'update', 'count', 'chr', 'mid', 'master', 'truncate', 'char', 
        'declare', 'select', 'create', 'delete', 'insert', "'", '"', "or", "OR", "%", '#', '=');
    $string = str_replace($arr, array(''), $keyword);
    return $string;
}

/**
 * 封装file_get_contents函数
 * @param string $url 要请求的URL
 * @param int $timeout 超时时间
 */
function fileGetContents($url, $timeout = 10) {
    $context = array('http' => ['timeout' => $timeout]);
    return @file_get_contents($url, 0, stream_context_create($context));
}

/**
 * 格式化章节内容
 * @param string $str 章节内容
 */
function formatContent($str) {
    $str = preg_replace("/^\s+/", '', $str);
    $str = preg_replace("/\s+$/", '', $str);
    $str = preg_replace("/[ \f\r\t]+/", '', $str);
    $str = preg_replace("/\r\n/", "\n", $str);
    $str = str_replace(["\n\n", '\u3000', '\xa0', '　　', '<br/>'], ["\n", '', '', '', "\n"], $str);
    $str = str_replace(['\\', '<p></p><p>', '</p><p>', '""', '<p>', 'n', '\r\n', '\n', '</p>'], ['', '', "\n", '', '', "\n", "\n", "\n", "\n"], $str);
    return $str;
}

/**
 * URL参数加密解密
 * @param string $args 需加密的参数
 * @param string $option 加密解密方式 默认ENCODE | DECODE
 */
function authcode($args, $option = 'ENCODE') {
    $key = md5('13#sd%@56yy$*7^9(@up');
    $key_length = strlen($key);
    
    $string = $option == 'DECODE' ? base64_decode($args) : substr(md5($args . $key), 0, 8) . $args;
    $string_length = strlen($string);
    $rndkey = $box = array();
    $result = '';
    
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($key[$i % $key_length]);
        $box[$i] = $i;
    }
    for ($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    
    if ($option == 'DECODE') {
        if (substr($result, 0, 8) == substr(md5(substr($result, 8) . $key), 0, 8)) {
            return substr($result, 8);
        } else {
            return '';
        }
    } else {
        return str_replace('=', '', base64_encode($result));
    }
}

//判断是否为微信浏览器
function isWxbrowser() {
    if (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
        return true;
    }
    return false;
}

function curl_get_https($url){
    $curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);  // 从证书中检查SSL加密算法是否存在
    $tmpInfo = curl_exec($curl);     //返回api的json对象
    //关闭URL请求
    curl_close($curl);
    return $tmpInfo;    //返回json对象
}

/* PHP CURL HTTPS POST */
function curl_post_https($url,$data){ // 模拟提交数据函数
    $curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
    curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
    $tmpInfo = curl_exec($curl); // 执行操作
    if (curl_errno($curl)) {
        echo 'Errno'.curl_error($curl);//捕抓异常
    }
    curl_close($curl); // 关闭CURL会话
    return $tmpInfo; // 返回数据，json格式
}

/**
 * 将数组数据转换成XML
 * @param array $arr 数组
 * @return string
 */
function arrayToXml($arr) {
    $xml = "<xml>";
    foreach ($arr as $key => $val) {
        if (is_numeric($val)) {
            $xml.="<" . $key . ">" . $val . "</" . $key . ">";
        } else
            $xml.="<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
    }
    $xml.="</xml>";
    return $xml;
}

/**
 * 将xml转为array
 * @param string $xml
 */
function xmlToArray($xml) {
    //将XML转为array        
    $array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
    return $array_data;
}