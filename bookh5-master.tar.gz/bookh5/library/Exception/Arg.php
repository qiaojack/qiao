<?php

/**
 * 参数检验异常
 *
 * @package Exception
 * @author vxing <wangwx@baihe.com>
 */
class Exception_Arg extends Exception_Msg {

    /**
     * 构造方法
     *
     * @param int $code
     * @param string $message
     * @param mixed $metadata
     */
    public function __construct($code, $message = '', $metadata = null) {
        parent::__construct($code, $message);
    }

}