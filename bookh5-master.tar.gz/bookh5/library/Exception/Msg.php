<?php

/**
 * 消息级别异常(一般与业务逻辑相关, 用于消息提示或通知上层程序做不同处理等)
 *
 * @package Exception
 * @author vxing <wangwx@baihe.com>
 */
class Exception_Msg extends Exception_Abstract {

}