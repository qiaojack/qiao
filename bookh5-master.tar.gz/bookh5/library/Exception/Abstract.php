<?php

/**
 * 异常抽象类
 *
 * @package Exception
 * @author vxing <wangwx@baihe.com>
 */
abstract class Exception_Abstract extends Exception {

    /**
     * 出现异常时生产环境发现异常是否写入日志
     *
     * @var type
     */
    protected $write_log = false;

    /**
     * 异常元数据
     *
     * @var array
     */
    protected $metadata = array();

    /**
     * 构造方法
     *
     * @param int $code
     * @param string $message
     * @param mixed $metadata
     */
    public function __construct($code, $message = '', $metadata = array()) {
        // 异常内容为空的话,尝试从配置获取
        !$message && $message = Comm_I18n::text('errcode.' . $code);

        parent::__construct($message, $code);

        // 生产环境发现系统或者接口异常, 写日志记录
        /*if (in_array(DEVELOP_LEVEL, array(3, 4)) && $this->write_log) {
            Helper_Error::writeExceptionLog($this);
        }*/

        Comm_Response::contentType(Comm_Response::TYPE_JSON);
        echo Comm_Response::failJson($code, $message, $metadata);
        exit;
    }

    /**
     * 获取元数据
     *
     * @return array
     */
    public function getMetadata() {
        return $this->metadata;
    }

}