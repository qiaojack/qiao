<?php

/**
 * 调用内部接口出错
 *
 * @package Exception
 * @author vxing <wangwx@baihe.com>
 */
class Exception_Api extends Exception_Abstract {

    protected $write_log = true;

    /**
     * 构造方法
     *
     * @param int $code
     * @param string $message
     * @param array $metadata
     */
    public function __construct($code, $message = '', $metadata = null) {
        $this->metadata = $metadata;

        parent::__construct($code, $message);
    }

}