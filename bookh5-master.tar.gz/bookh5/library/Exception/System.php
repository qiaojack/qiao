<?php

/**
 * 系统级别异常(错误类异常)
 *
 * 此级别的异常属于系统本身的错误, 如系统服务不可用, 程序代码配置错误等
 * 此类异常会记录文件日志
 * 判断标准为：若系统一切正常，任意操作都不可能出现的异常
 *
 * @package Exception
 * @author vxing <wangwx@baihe.com>
 */
class Exception_System extends Exception_Abstract {

    protected $write_log = true;

    /**
     * 构造方法
     *
     * @param int $code
     * @param string $message
     * @param array $metadata
     */
    public function __construct($code, $message = '', $metadata = null) {
        $this->metadata = $metadata;

        // 系统级异常屏蔽掉内容,只显示code
        parent::__construct($code, $code);
    }

}