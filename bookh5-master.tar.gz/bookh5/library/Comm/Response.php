<?php

/**
 * 输出结构
 *
 * @package Comm
 * @author vxing <wangwx@baihe.com>
 */
abstract class Comm_Response {

    // 响应体类型(JSON)
    const TYPE_JSON = 'json';

    // 响应体类型(HTML)
    const TYPE_HTML = 'html';

    // 响应体类型(JS)
    const TYPE_JS = 'js'; 

    // 响应体类型(JPG)
    const TYPE_JPG = 'jpg';

    /**
     * 输出响应类型
     *
     * @param type $type
     */
    static public function contentType($type) {
        if (headers_sent()) {
            return false;
        }

        switch ($type) {
            case 'json':
                header('Content-type: application/json');
                break;
            case 'js':
                header('text/javascript; charset=utf-8');
                break;
            case 'jpg':
                header('Content-Type: image/jpeg');
                break;
            case 'html':
            default:
                header('Content-type: text/html; charset=utf-8');
                break;
        }

        return true;
    }

    /**
     * success Json output
     *
     * @param array $result
     * @return string
     */
    static public function successJson($result) {
        $result = json_encode(array(
            'code' => '200',
            'msg' => '',
            'rows' => $result
        ));

//        $debug_model = Yaf_Registry::get('debug_model');
//        if (!$debug_model) {
//    		$user_id = Yaf_Registry::get('cur_user_id');
//    		$decrypt_obj = new Helper_Des();
//         	$result = $decrypt_obj->encrypt($result);
//        }
        return $result;
    }

    /**
     * fail Json output
     *
     * @param integer $code
     * @param string $message
     * @return string
     */
    static public function failJson($code, $message, $metadata) {
        $result = json_encode(array(
            'code' => $code,
            'msg' => $message,
            'rows' => (object)$metadata
        ));

        $debug_model = Yaf_Registry::get('debug_model');
//        if (!$debug_model) {
//    		$user_id = Yaf_Registry::get('cur_user_id');
//    		$decrypt_obj = new Helper_Des();
//         	$result = $decrypt_obj->encrypt($result);
//        }
        return $result;
    }

}