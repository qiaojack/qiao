<?php

/**
 * 配置信息读取类
 *
 * @package Comm
 * @author vxing <wangwx@baihe.com>
 */
class Comm_Config {

    /**
     * 读取配置信息
     *
     * @param string $path 节点路径，第一个是文件名，使用点号分隔。如:"app","app.product.routes"
     * @return array/string 成功返回数组或string
     */
    static public function get($path) {

        $arr = explode('.', $path, 2);
        try {
            $conf = new Yaf_Config_ini(APP_PATH . 'conf/' . $arr[0] . '.ini');
        } catch (Exception $e) {
        }
        !empty($arr[1]) && !empty($conf) && $conf = $conf->get($arr[1]);
        
        if (!isset($conf) || is_null($conf)) {
            throw new Exception_System('200301');
        }

        return is_object($conf) ? $conf->toArray() : $conf;
    }

    /**
     * 读取配置信息（使用静态数据缓存）
     *
     * @param string $path 节点路径，第一个是文件名，使用点号分隔。如:"app","app.product.routes"
     * @return array/string    成功返回数组或string
     */
    static public function getUseStatic($path) {
        $static_key = 'get_' . $path;

        $result = Comm_Sdata::get(__CLASS__, $static_key);
        if ($result === false) {
            $result = self::get($path);
            Comm_Sdata::set(__CLASS__, $static_key, $result);
        }
        return $result;
    }

}