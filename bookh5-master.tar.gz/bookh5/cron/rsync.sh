#!/bin/sh
# 同步数据到远程107

# processCount=`ps -ef | grep "scp" | grep -v "grep" | wc -l`

# if [ $processCount -eq 0 ]; then
# 	fileList=`ls /data/novel/ | head -n 5`
# 	fileCount=${#fileList}

# 	if [ $fileCount -gt 0 ]; then
# 		for name in $fileList
# 		do
# 			scp -r -P 12570 /data/novel/$name root@221.195.1.107:/data/novel/ && rm -rf /data/novel/$name
# 		done
# 	fi
# fi
# 

for ((i=2; i<=2948; i ++))  
do
    mv /data/novel/$i /data/book/
done