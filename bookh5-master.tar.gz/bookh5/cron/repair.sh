#!/bin/sh
# 修复章节问题

processCount=`ps -ef | grep "reset" | grep -v "grep" | wc -l`

if [ $processCount -eq 0 ]; then
    logPath="/data/wwwroot/bookapi/log/errorbook.log"
    # idinfo=`cat $logPath | sed -n "1,1p"`
    fileList=`cat $logPath | sed -n "1,100p"`
    fileCount=${#fileList}

    # if [ $idinfo ]; then
        # curl -S "http://192.168.0.211:1250/gather/qiantang/chapter?book_id=${idinfo}" && curl -S "http://192.168.0.211:1250/gather/qiantang/content?book_id=${idinfo}" && rsync -avH --progress /data/novel/$idinfo rsync@221.195.1.107::novel --password-file=/etc/passwd.txt &
        #sed -i '1d' $logPath
    # fi

    if [ $fileCount -gt 0 ]; then
	    for name in $fileList
	    do
	    	curl -S "http://221.195.1.107/gather/operate/resetText?book_id=${name}" &
        	sed -i '1d' $logPath
	    done
	fi
fi