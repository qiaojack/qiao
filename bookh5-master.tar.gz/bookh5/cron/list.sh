#!/bin/sh
# 采集新书

requestURL="https://m.jiuwei.com/gather/qiantang"

for ((i=0; i<=20; i ++))  
do
    curl -S "${requestURL}/list?page=${i}"
done