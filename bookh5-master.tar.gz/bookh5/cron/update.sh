#!/bin/sh
# 采集书籍更新(钱塘)

processCount=`ps -ef | grep "qiantang" | grep -v "grep" | wc -l`
requestURL="https://m.jiuwei.com/gather/qiantang"

if [ $processCount -eq 0 ]; then
    logPath="/data/wwwroot/h5bookapi/log/qiantang.log"
    fileList=`cat $logPath | sed -n "1,5p"`
    fileCount=${#fileList}
    
    if [ $fileCount -gt 0 ]; then
        for bookId in $fileList
        do
            curl -S "${requestURL}/chapter?book_id=${bookId}" && curl -S "${requestURL}/content?book_id=${bookId}" &
            sed -i '1d' $logPath
        done
    fi
fi