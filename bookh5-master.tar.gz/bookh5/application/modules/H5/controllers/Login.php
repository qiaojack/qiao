<?php

/**
 * 用户登录
 */
class LoginController extends BaseController {
    
    private $_userModel, $_redis, $_wechatPc, $_qq;
    private $domain, $channel;
    
    public function init() {
        parent::init();
        $this->_userModel = UserModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $novelConf = new Yaf_Config_Ini(APP_PATH . '/config/novel.ini');
        $this->_wechatPc = $novelConf->wechat->pc;
        $this->_qq = $novelConf->qq;
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    //验证用户登录
    public function checkAction() {
        $userInfo = $this->getLoginUser();
        $isLogin = !empty($userInfo) ? 1 : 0;
        
        $assign = ['isLogin' => $isLogin];
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //自动登录
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $jump = isset($request['jump']) ? urldecode($request['jump']) : __DOMAIN_URL__;
        $showqq = ($this->channel == 'm') ? 1 : 0;
        $isWeixin = isWxbrowser(); //是否微信浏览器
        
        $assign = [
            'jump' => $jump,
            'isWeixin' => $isWeixin,
            'showqq' => $showqq,
        ];
        $this->display('index', $assign);
    }
    
    //用户协议与隐私政策
    public function authAction() {
        $request = $this->getRequest()->getQuery();
        $id = isset($request['id']) ? (int)$request['id'] : 1;
        
        $assign = [
            'id' => $id,
        ];
        $this->display('auth', $assign);
    }

    //中转登录
    public function autoAction() {
        $request = $this->getRequest()->getQuery();
        $type = isset($request['t']) ? $request['t'] : '';
        $jump = isset($request['u']) && !empty($request['u']) ? urldecode($request['u']) : __DOMAIN_URL__;
        
        if ($type == 'wechat') {
            $config = $this->_userModel->getSysMpConf($this->domain);
//            dump($config);
            $redirect_uri = __DOMAIN_URL__ . '/h5/login/wechat?jump=' . urlencode($jump);
            
            if (isWxbrowser()) { //如果是微信浏览器
                $query = array(
                    'appid' => $config['app_id'],
                    'redirect_uri' => $redirect_uri,
                    'response_type' => 'code',
                    'scope' => 'snsapi_userinfo',
                    'state' => '#wechat_redirect',
                );
                $oauthURL = "https://open.weixin.qq.com/connect/oauth2/authorize?";
            } else { //微信网页授权扫码
                $query = array(
                    'appid' => $this->_wechatPc->AppId,
                    'redirect_uri' => $redirect_uri,
                    'response_type' => 'code',
                    'scope' => 'snsapi_login',
                    'state' => ''
                );
                $oauthURL = "https://open.weixin.qq.com/connect/qrconnect?";
            }
            $requestURL = $oauthURL . http_build_query($query);
            $this->redirect($requestURL);
        }
        else if ($type == 'qq') { //QQ授权登录
            $redirect_uri = __CALLBACK_URL__ . '/h5/login/qq?jump=' . urlencode($jump);
            $params = array(
                'client_id' => $this->_qq->AppId,
                'redirect_uri' => $redirect_uri,
                'response_type' => 'code',
                'state' => '1'
            );
            $requestLoginURL = 'https://graph.qq.com/oauth2.0/authorize?' . http_build_query($params);
            $this->redirect($requestLoginURL);
        }
    }
    
    //微信登录
    public function wechatAction() {
        $request = $this->getRequest()->getQuery();
        $code = isset($request['code']) ? $request['code'] : '';
        $jump = isset($request['jump']) ? urldecode($request['jump']) : '';
        
        //公众号登录或者扫码登录
        $config = $this->_userModel->getSysMpConf($this->domain);
        $appId = isWxbrowser() ? $config['app_id'] : $this->_wechatPc->AppId;
        $appSecret = isWxbrowser() ? $config['app_secret'] : $this->_wechatPc->AppSecret;
        
        Yaf_Loader::import(APP_PATH . '/library/Auth/Wechat.php');
        $wxsdk = new Wechat($appId, $appSecret);
        
        //获取登录token
        $tokenRest = $wxsdk->get_access_token($code);
        $access_token = isset($tokenRest['access_token']) ? $tokenRest['access_token'] : '';
        $openid = isset($tokenRest['openid']) ? $tokenRest['openid'] : '';
        
        //授权获取用户信息
        $wxUserInfo = $wxsdk->get_user_info($access_token, $openid);
        $unionid = isset($wxUserInfo['unionid']) ? $wxUserInfo['unionid'] : '';
        
//        eYaf\Logger::getLogger('login')->info(var_export($wxUserInfo, true));
        
        if (!empty($wxUserInfo)) {
            $userInfo = $this->_userModel->getUserInfo(['openid' => $openid]);
            if (!empty($userInfo)) {
                $user_id = (int)$userInfo['user_id'];
                $params = array(
                    'nickname' => $wxUserInfo['nickname'],
                    'avatar' => $wxUserInfo['headimgurl'],
                    'lastlogintime' => __TIME__,
                );
                $this->_userModel->update('novel_user', $params, "user_id = {$user_id}");
            } else {
                $userInfo = array(
                    'nickname' => isset($wxUserInfo['nickname']) ? $wxUserInfo['nickname'] : '',
                    'sex' => isset($wxUserInfo['sex']) ? ($wxUserInfo['sex'] == 1 ? 1 : 0) : 1,
                    'openid' => $openid,
                    'unionid' => $unionid,
                    'avatar' => isset($wxUserInfo['headimgurl']) ? $wxUserInfo['headimgurl'] : '',
                    'login_type' => 1,
                    'login_fromid' => 1,
                    'lastlogintime' => __TIME__,
                    'create_at' => __TIME__,
                    'channel' => $this->channel,
                );
                $user_id = $this->_userModel->insertIgnore('novel_user', $userInfo); //新增用户
                $userInfo['user_id'] = $user_id;
            }
            
            //用户登录操作
            $this->settingLogin($userInfo, $this->domain);
            
            //登录成功，系统跳转
            if (!empty($jump)) {
                $this->redirect($jump);
                exit;
            }
        }
    }
    
    //QQ登录
    public function qqAction() {
        $request = $this->getRequest()->getQuery();
        $code = isset($request['code']) ? $request['code'] : '';
        $jump = isset($request['jump']) ? urldecode($request['jump']) : '';
        
        //QQ登录appid apsecret
        $appId = $this->_qq->AppId;
        $appSecret = $this->_qq->AppSecret;
        
        //获取用户的access_token
        Yaf_Loader::import(APP_PATH . '/library/Auth/QQ.php');
        $qqsdk = new QQ($appId, $appSecret);
        $tokenRest = $qqsdk->get_access_token($code, $jump);
        $access_token = isset($tokenRest['access_token']) ? $tokenRest['access_token'] : '';
        if (empty($access_token)) {
            $this->redirect(__DOMAIN_URL__);
            exit;
        }
        
        //获取用户的openid
        $openRest = $qqsdk->get_open_id($access_token);
        $openid = !empty($openRest) ? $openRest['openid'] : '';
        $unionid = !empty($openRest) ? $openRest['unionid'] : '';
        if (empty($unionid)) {
            $this->redirect(__DOMAIN_URL__);
            exit;
        }
        
        //获取用户信息
        $qqUserData = $qqsdk->get_user_info($access_token, $openid);
        
        if (!empty($qqUserData)) {
            //校验用户登录数据
            $userInfo = $this->_userModel->getUserInfo(['unionid' => $unionid]);
            if (!empty($userInfo)) {
                $user_id = (int)$userInfo['user_id'];
                $params = array(
                    'nickname' => $qqUserData['nickname'],
                    'avatar' => $qqUserData['figureurl_qq_2'],
                    'lastlogintime' => __TIME__,
                );
                $this->_userModel->update('novel_user', $params, "user_id = {$user_id}");
            } else {
                $userInfo = array(
                    'nickname' => isset($qqUserData['nickname']) ? $qqUserData['nickname'] : '',
                    'sex' => (isset($qqUserData['gender']) && $qqUserData['gender'] == '男') ? 1 : 0,
                    'openid' => $openid,
                    'unionid' => $unionid,
                    'avatar' => isset($qqUserData['figureurl_qq_2']) ? $qqUserData['figureurl_qq_2'] : '',
                    'login_type' => 2,
                    'login_fromid' => 1,
                    'lastlogintime' => __TIME__,
                    'create_at' => __TIME__,
                    'channel' => $this->channel,
                );
                $user_id = $this->_userModel->insertIgnore('novel_user', $userInfo); //新增用户
                $userInfo['user_id'] = $user_id;
            }

            //用户登录操作
            $this->settingLogin($userInfo, $this->domain);

            //登录成功，系统跳转
            $qqRedirect = !empty($jump) ? $jump : __DOMAIN_URL__;
            $this->redirect($qqRedirect);
            exit;
        }
    }
    
    //手机号登录
    public function mobileAction() {
        $postData = $this->getRequest()->getPost();
        
        //验证手机号是否有误
        $mobile = trim($postData['mobile']);
        if (!preg_match("/^1\d{10}$/", $mobile)) {
            throw new Exception_Msg(101, '手机号有误');
        }
        //检验验证码是否有误
        $cachecode = $this->_redis->get("mobile_{$mobile}");
        $verify_code = isset($postData['verifycode']) ? trim($postData['verifycode']) : '';
        if (strtolower($verify_code) != strtolower($cachecode)) {
            throw new Exception_Msg(102, '验证码有误');
        }
        
        //校验用户登录数据
        $openid = md5(sha1($mobile));
        $userInfo = $this->_userModel->getUserInfo(['mobile' => $mobile]);
        if (!empty($userInfo)) {
            $user_id = (int)$userInfo['user_id'];
            $params = array(
                'openid' => $openid,
                'lastlogintime' => __TIME__,
            );
            $this->_userModel->update('novel_user', $params, "user_id = {$user_id}");
        } else {
            $userInfo = array(
                'nickname' => $mobile,
                'mobile' => $mobile,
                'sex' => 1,
                'openid' => $openid,
                'unionid' => '',
                'avatar' => '',
                'login_type' => 0,
                'login_fromid' => 1,
                'lastlogintime' => __TIME__,
                'create_at' => __TIME__,
                'channel' => $this->channel,
            );
            $user_id = $this->_userModel->insertIgnore('novel_user', $userInfo); //新增用户
            $userInfo['user_id'] = $user_id;
        }
        
        //用户登录操作
        $this->settingLogin($userInfo, $this->domain);
        
        echo $this->stringifyJSON(['code' => 200]);
        exit;
    }
    
    //验证码
    public function smsCodeAction() {
        $postData = $this->getRequest()->getPost();
        $mobile = isset($postData['mobile']) ? $postData['mobile'] : 0;
        $captcha = str_pad(mt_rand(0, pow(10, 6) - 1), 6, '0', STR_PAD_LEFT); //生成验证码
        
        $message = 'OK';
        $key = "mobile_{$mobile}";
        if (!$this->_redis->exists($key)) {
            $this->_redis->setex($key, 120, $captcha);
            $params = array(
                'userid' => 800957, //企业ID
                'password' => 'MKyn81bN', //密码
                'account' => 800957,
                'mobile' => $mobile,
                'sendtime' => '',
                'extno' => '106902202230',
                'content' => "【钱塘阅读】您的验证码为{$captcha}，请于1分钟内正确输入，如非本人操作，请忽略此短信。",
            );
            $requestUrl = 'http://39.106.108.70:7803/sms?action=send';
            $httpClient = new HttpClient($requestUrl, 'POST');
            $httpClient->setRequestBody($params); //设置请求的内容
            $httpClient->exec();
            $xml = simplexml_load_string($httpClient->getResponseBody());
            $message = trim($xml->message);
        }
        echo $this->stringifyJSON(['code' => $message]);
        exit;
    }
    
    //退出登录
    public function logoutAction() {
        $channel = isset($_COOKIE['channel']) ? $_COOKIE['channel'] : '';
        $openId = isset($_COOKIE['openId']) ? $_COOKIE['openId'] : '';
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        $this->_redis->hdel('h5_bookshelf', $user_id);
        $this->_redis->del("{$channel}_{$openId}");
        
        //清空SESSION
        session_destroy();
        setcookie('openId', '', __TIME__ - 3600, '/', $this->domain);
        setcookie('channel', '', __TIME__ - 3600, '/', $this->domain);
        
        $this->redirect('/h5/login');
        exit;
    }
}
