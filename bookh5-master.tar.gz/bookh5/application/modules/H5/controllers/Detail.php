<?php

/**
 * 书籍详情
 */
class DetailController extends BaseController {
    
    private $_novelModel;
    
    public function init() {
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
    }
    
    //读取书籍详情数据
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int)$request['book_id'] : 0;
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        //获取书籍数据
        $bookInfo = $this->getBookInfo($book_id);
        if (empty($bookInfo)) {
            $this->redirect('/');
            exit;
        }
        $bookInfo['last_uptime'] = time_ago($bookInfo['last_uptime']);
        
        //该书是否已加入书架
        $haveBook = !empty($user_id) ? $this->isHaveBook($user_id, $book_id) : 0;
        
        //大家都在看
        $allLike = $this->allLike();
        
        //相似书籍
        $similar = $this->similar($bookInfo['cate_id']);
        
        //统计书籍浏览热度
        $this->_novelModel->updateUserLike($book_id);
        
        $assign = array(
            'bookInfo' => $bookInfo,
            'allLike' => $allLike,
            'similar' => $similar,
            'userInfo' => ['haveBook' => $haveBook],
        );
        $this->display('index', $assign);
    }
    
    //大家都在看
    public function changeLikeAction() {
        $allLike = $this->allLike(true);
        $record = array(
            'code' => 200,
            'rows' => $allLike,
        );
        echo $this->stringifyJSON($record);
        exit;
    }
    
    /**
     * 大家都在看
     */
    private function allLike($shuffle = false) {
        $records = [];
        $result = $this->_novelModel->getLikeBook(0, 30);
        foreach ($result as $book_id) {
            $bookInfo = !empty($book_id) ? $this->getBookInfo($book_id) : [];
            if (!empty($bookInfo) && !empty($bookInfo['cover'])) {
                $records[] = array(
                    'book_id' => (int)$bookInfo['book_id'],
                    'name' => $bookInfo['name'],
                    'author' => $bookInfo['author'],
                    'cover' => $bookInfo['cover'],
                );
            }
        }
        $lookList = [];
        if (!empty($records)) {
            if ($shuffle) {
                shuffle($records);
            }
            $lookList = array_slice($records, date('G'), 4);
        }
        return $lookList;
    }
    
    //相似书籍
    public function changeSimilarAction() {
        $request = $this->getRequest()->getQuery();
        $cate_id = isset($request['cate_id']) ? (int)$request['cate_id'] : 0;
        
        $similar = $this->similar($cate_id, true);
        $record = array(
            'code' => 200,
            'rows' => $similar,
        );
        echo $this->stringifyJSON($record);
        exit;
    }
    
    /**
     * 相似书籍
     * @param int $cate_id 书籍分类ID
     */
    private function similar($cate_id = 0, $shuffle = false) {
        $records = [];
        $result = $this->_novelModel->getCateListById(array('cate_id' => $cate_id), 0, 20);
        foreach ($result as $value) {
            $bookInfo = $this->getBookInfo($value['book_id']);
            if (!empty($bookInfo) && !empty($bookInfo['cover'])) {
                $records[] = array(
                    'book_id' => (int)$bookInfo['book_id'],
                    'name' => $bookInfo['name'],
                    'author' => $bookInfo['author'],
                    'cover' => $bookInfo['cover'],
                );
            }
        }
        if ($shuffle) {
            shuffle($records);
        }
        $records = count($records) > 4 ? array_slice($records, 0, 4) : $records;
        return $records;
    }
}