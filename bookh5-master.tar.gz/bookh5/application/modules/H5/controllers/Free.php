<?php

/**
 * 免费专区
 */
class FreeController extends BaseController {
    
    private $_novelModel;
    
    public function init() {
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
    }
    
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $type = isset($request['type']) ? (int)$request['type'] : 0;
        $page = isset($request['page']) ? (int)$request['page'] : 1;
        $length = isset($request['length']) ? (int)$request['length'] : 20;
        $shuffle = isset($request['shuffle']) ? (int)$request['shuffle'] : 0;
        
        if (!empty($type)) {
            $recommend = $this->getConfData($type, $page, $length, $shuffle);
            $assign = array(
                'code' => 200,
                'rows' => $recommend,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        
        $assign = array(
            'limit' => $this->timelimit(1, 0, 4), //限时免费
            'xsmf' => $this->getConfData(7, 1, 8), //新书免费
            'jpmf' => $this->getConfData(8, 1, 8), //精品免费
        );
        $this->display('index', $assign);
    }
    
    /**
     * 限时免费书籍
     * @param int $limit_type 限时类型
     * @param int $offset 偏移量
     * @param int $length 展示数量
     */
    private function timelimit($limit_type = 1, $offset = 0, $length = 4) {
        $recordList = [];
        $query = $this->_novelModel->getTimelimitData($limit_type);
        if (!empty($query)) {
            foreach ($query as $key => $value) {
                $bookInfo = !empty($value['book_id']) ? $this->getBookInfo($value['book_id']) : [];
                if (!empty($bookInfo) && $value['timeout'] > __TIME__) {
                    $recordList['book'][] = array(
                        'book_id' => (int)$bookInfo['book_id'],
                        'name' => $bookInfo['name'],
                        'author' => $bookInfo['author'],
                        'cover' => $bookInfo['cover'],
                    );
                    if ($key == count($query) - 1) {
                        $recordList['timeout'] = (int)$value['timeout'] - __TIME__;
                    }
                }
            }
            $recordList = array_slice($recordList, $offset, $length);
        }
        return $recordList;
    }
}
