<?php

/**
 * 第三方支付
 */
class JumpController extends BaseController {

    private $_AppId = '301954686';
    private $_PayKey = '6@wQ#8^(#t~$g*66)U_%93&LAx';
    private $_payModel, $_userModel, $_statsModel;
    private $domain, $channel;
    
    public function init() {
        parent::init();
        $this->_payModel = PayModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_statsModel = StatsModel::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    //爱贝支付
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $bkey = isset($request['bkey']) ? base64_decode4url($request['bkey']) : '';
        if (empty($bkey)) {
            $this->redirect(__DOMAIN_URL__);
            exit;
        }
        
        parse_str($bkey, $request);
        $user_id = isset($request['user_id']) ? (int)$request['user_id'] : 0;
        $channel = isset($request['channel']) ? $request['channel'] : '';
        $price = isset($request['price']) ? $request['price'] : 0;
        $jump = isset($request['jump']) ? urldecode(base64_decode($request['jump'])) : __DOMAIN_URL__;
        
        //根据回调地址分析来源于哪本书或渠道
        $book_id = $extend_id = 0;
        if (!empty($jump)) {
            $explode = explode('?', $jump);
            if (isset($explode[1])) {
                parse_str($explode[1], $params);
                $book_id = isset($params['book_id']) ? (int)$params['book_id'] : 0;
            }
            $extend_id = $this->_userModel->getUserFromExtend($user_id, $channel); //获取推广ID
        }
        
        //生成订单
        $orderId = strtoupper(substr(sha1($user_id . $price . __TIME__), 8, 16));
        $data = [
            'pay_coin' => $price * 100,
            'pay_amt' => $price,
            'user_id' => $user_id,
            'order_id' => $orderId,
            'create_at' => __TIME__,
            'ftype' => $channel != 'm' ? 1 : 3,
            'extend_id' => $extend_id,
            'channel' => $channel != 'm' ? $channel : '', //渠道
            'book_id' => $book_id,
        ];
        
        $transid = $this->transOrder($data);
        if (empty($transid)) {
            throw new Exception_Msg(211, '生成订单失败');
        }
        $data['transid'] = $transid; //得到下单号
        $order = $this->_payModel->createOrder($data); //生成订单入库
        
        $gatewayId = 403; //支付方式 [401:支付宝; 402:财付通; 403:微信支付, 116:qq钱包]
        $delivery = array(
            'tid' => $transid,
            'app' => $this->_AppId,
            'url_r' => $jump,
            'url_h' => $jump,
            'ptype' => $gatewayId,
        );
        
        //组装请求报文，对数据签名
        $appkey = $this->getKey('private');
        $reqData = $this->composeReq($delivery, $appkey, 'data');
        $payRequestURL = 'https://web.iapppay.com/h5/d/gateway?' . $reqData;
        
        $assign = array(
            'code' => $order ? 200 : 201,
            'rows' => array(
                'orderid' => $transid,
                'payjumpurl' => $payRequestURL,
            )
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //爱贝支付回调通知
    public function notifyurlAction() {
        $string = $this->getRequest()->getPost(); //接收post请求数据
        $transdata = isset($string['transdata']) ? $string['transdata'] : '';
        
        //记录回调通知日志
        eYaf\Logger::getLogger('pay_notify')->info($transdata);
        
        $callmsg = 'failed'; //验签失败 
        $data = json_decode($transdata);
        if ($data->result == 0) { //处理订单逻辑
            $chargeInfo = $this->_payModel->getOrderInfo($data->cporderid); //查询订单
            if (!empty($chargeInfo) && $chargeInfo['order_st'] == 0) {
                $pay_amt = (int)$chargeInfo['pay_amt'];
                $user_id = (int)$chargeInfo['user_id'];
                $bookCoin = $this->giveBookCoins($pay_amt);
                $giveCoins = !is_array($bookCoin) ? (int)$bookCoin : 0;
                $pay_coin = (int)$chargeInfo['pay_coin'] + $giveCoins;
                
                //更新支付状态
                $this->_payModel->update('novel_pay_record', ['order_st' => 1, 'tickets' => $giveCoins, 'transid' => $data->transid], "order_id = '{$data->cporderid}'");
                
                //更新书币账户
                $this->_payModel->updateUserCoin($user_id, $pay_coin);
                
                //更新用户缓存数据
                $query = $this->_userModel->getUserByUserId($user_id);
                $userInfo = $this->getLoginUser($query['channel'], $query['openid']);
                $this->_userModel->updateUserInfo($userInfo, ['addcoin' => $pay_coin]);
                
                //更新统计相关数据
                $this->_statsModel->updateInshow($user_id, $pay_amt);
                
                $callmsg = 'success';
            }
        }
        
        echo $callmsg;
        exit;
    }
    
    //向爱贝服务后台请求下单
    private function transOrder($data = array()) {
        $appkey = $this->getKey('private'); //私钥
        $platpkey = $this->getKey('public'); //平台公钥
        $orderReq = array(
            'appid' => $this->_AppId,
            'waresid' => 1,
            'waresname' => '123',
            'cporderid' => $data['order_id'],
            'price' => (float) money_format("%.2n", $data['pay_amt']),
            'currency' => 'RMB',
            'appuserid' => '514678',
            'cpprivateinfo' => isset($data['extInfo']) ? urlencode($data['extInfo']) : 'extInfo',
            'notifyurl' => __DOMAIN_URL__ . '/h5/jump/notifyurl'
        );
        
        //组装请求报文  对数据签名
        $reqData = $this->composeReq($orderReq, $appkey);
        
        //发送到爱贝服务后台请求下单
        $orderUrl = 'http://ipay.iapppay.com:9999/payapi/order';
        $respData = $this->request_by_curl($orderUrl, $reqData, 'order data');
        
        //验签数据并且解析返回报文
        $transid = '';
        if ($this->parseResp($respData, $platpkey, $respJson)) {
            $transid = $respJson->transid;
        }
        return $transid;
    }
    
    //充值补单
    // https://m.jiuwei.com/h5/jump/supplement?orderid=F2E1FFF0565F9997
    public function supplementAction() {
        $request = $this->getRequest()->getQuery();
        $orderid = isset($request['orderid']) ? $request['orderid'] : '';
        
        $result = 'failed';
        $chargeInfo = $this->_payModel->getOrderInfo($orderid); //查询订单
//        dump($chargeInfo);
        if (!empty($chargeInfo)) {
            $pay_amt = intval((int)$chargeInfo['pay_amt']);
            $user_id = (int)$chargeInfo['user_id'];
            $giveCoins = $this->giveBookCoins($pay_amt);
            $pay_coin = (int)$chargeInfo['pay_coin'] + $giveCoins;
            
            //更新支付状态
            $this->_payModel->update('novel_pay_record', ['order_st' => 1, 'tickets' => $giveCoins], "order_id = '{$orderid}'");
            
            //更新书币账户
            $this->_payModel->updateUserCoin($user_id, $pay_coin);
            
            //更新用户缓存数据
            $query = $this->_userModel->getUserByUserId($user_id);
            $userInfo = $this->getLoginUser($query['channel'], $query['openid']);
            $this->_userModel->updateUserInfo($userInfo, ['addcoin' => $pay_coin]);
            
            $result = 'success';
        }
        $assign = array(
            'result' => $result,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //读取KEY
    private function getKey($key) {
        $conf = array(
            'private' => 'MIICXAIBAAKBgQDciY4pUCbvQurqAQaxuM/YD/G8O6JfJI0FIUEjUGA/SJUzJ7b4wlxtqsaS2Pyp8HsdCMPpwJwRSv+e3cxmOKLbtyBV6uaHSzCUQLw4vJ2sH6eoNJ1OqTVUxiFNDbU4Z+7UF1oOl/WG5dGIFTtf505buMy2wewG89YPYWrtzJyIjQIDAQABAoGBAM00vXAZobDeDmIhBE6YTeWYqHFi9+oZw5IzaD3oyzX3XsUTvkBn8cMltdHsT+X820Gf51P5If9BTutPLKMtLfMTmbbJrFtH4sWoeBzrq5sTtASERJsGHxemURQ7xiGe8mcKzYMGijkntzJLLLeB95Zk5AqNy15JPhDzWUDn+xZtAkEA7j0uNcvqOdTvbBrR59kFmkStvyYTF2EMDJh56EhtlMFm4O0pVBJJ62VAjBWRR5a/KqWJYKPLC7Oyq1Heuy/YJwJBAOz6iVf0CtDb94jx9uQ/j7l1ZfxoHDP/pGy9tqRmtj3corYfdZ5O1b+6ldGrKKofrd2u0E92PFUYxvlqp6YNNisCQFBHhX7TTAZY3qULFJiP5PdrFTFIXz6NkUXdS5cecO6jjUtWH4sY7pfH8sxBqEb7YUe5qGVMTGuRDi/00p05LhkCQDi+wVaDRHfAxGRRdEoxgivplbM8BszYwTmcr/hr8+WaSIgNvm9a90oC1s8vCfy6uzpjGtR8PnQuC687v8s+TKMCQCeSdOGL14AOkX+uzPg+aGY3rLHtxoI5ByfLKKmUv7RYZZa8uZQ+npikw7IU+6+z2X3uuRyY3qdC9VSkF08mTOs=',
            'public' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDTiRAoF1l3fllYWCxSYL5mpmHHk4PQmGYDecO6UBUfL/3isBIyclvWLwSBoY8h+/XiU8H1bWpCnmdoU0XtmeGcblFDb23txYOHizFlNjx2DwTNVfHJSINL6sRuQXov633xdtE7fUbkdcJxTey8NZ/LKT94mcbGjNTclsqd9QxD8QIDAQAB'
        );
        return $conf[$key];
    }

    /** 格式化公钥
     * @param $pubKey PKCS#1格式的公钥串
     * @return pem格式公钥，可以保存为.pem文件
     */
    private function formatPubKey($pubKey) {
        $fKey = "-----BEGIN PUBLIC KEY-----\n";
        $len = strlen($pubKey);
        for ($i = 0; $i < $len;) {
            $fKey = $fKey . substr($pubKey, $i, 64) . "\n";
            $i += 64;
        }
        $fKey .= "-----END PUBLIC KEY-----";
        return $fKey;
    }

    /**
     * 格式化私钥
     * @param string $priKey PKCS#1格式的私钥串
     * @return pem格式私钥
     */
    private function formatPriKey($priKey) {
        $fKey = "-----BEGIN RSA PRIVATE KEY-----\n";
        $len = strlen($priKey);
        for ($i = 0; $i < $len;) {
            $fKey = $fKey . substr($priKey, $i, 64) . "\n";
            $i += 64;
        }
        $fKey .= "-----END RSA PRIVATE KEY-----";
        return $fKey;
    }

    /**
     * RSA签名(签名用商户私钥，使用MD5摘要算法，最后的签名，需要用base64编码)
     * @param $data 待签名数据
     * @param $priKey 商户私钥
     * @return Sign签名
     */
    private function sign($data, $priKey) {
        //转换为openssl密钥
        $res = openssl_get_privatekey($priKey);

        //调用openssl内置签名方法，生成签名$sign
        openssl_sign($data, $sign, $res, OPENSSL_ALGO_MD5);

        //释放资源
        openssl_free_key($res);

        //base64编码
        $sign = base64_encode($sign);
        return $sign;
    }

    /**
     * 组装request报文
     * @param $reqJson 需要组装的json报文
     * @param $vkey cp私钥，格式化之前的私钥
     * @param string $type 类型
     * @return 返回组装后的报文
     */
    private function composeReq($reqJson, $vkey, $type = 'transdata') {
        //获取待签名字符串
        $content = json_encode($reqJson);

        //格式化key，建议将格式化后的key保存，直接调用
        $vkey = $this->formatPriKey($vkey);

        //生成签名
        $sign = $this->sign($content, $vkey);

        //组装请求报文，目前签名方式只支持RSA这一种
        $reqData = "{$type}=" . urlencode($content) . "&sign=" . urlencode($sign) . "&signtype=RSA";

        return $reqData;
    }

    /**
     * 解析response报文
     * @param $content 收到的response报文
     * @param $pkey 爱贝平台公钥，用于验签
     * @param $respJson 返回解析后的json报文
     * @return 解析成功TRUE，失败FALSE
     */
    private function parseResp($content, $pkey, &$respJson) {
        $arr = array_map(create_function('$v', 'return explode("=", $v);'), explode('&', $content));
        foreach ($arr as $value) {
            $resp[($value[0])] = $value[1];
        }

        //解析transdata
        if (array_key_exists("transdata", $resp)) {
            $respJson = json_decode($resp["transdata"]);
        } else {
            return false;
        }

        //验证签名，失败应答报文没有sign，跳过验签
        if (array_key_exists("sign", $resp)) {
            //校验签名
            $pkey = $this->formatPubKey($pkey);
            return $this->verify($resp["transdata"], $resp["sign"], $pkey);
        } else if (array_key_exists("errmsg", $respJson)) {
            return false;
        }

        return true;
    }

    /**
     * RSA验签
     * @param string $data 待签名数据
     * @param string $sign 需要验签的签名
     * @param string $pubKey 爱贝公钥
     * @return 验签是否通过 bool值
     */
    private function verify($data, $sign, $pubKey) {
        //转换为openssl格式密钥
        $res = openssl_get_publickey($pubKey);

        //调用openssl内置方法验签，返回bool值
        $result = (bool) openssl_verify($data, base64_decode($sign), $res, OPENSSL_ALGO_MD5);

        //释放资源
        openssl_free_key($res);

        //返回资源是否成功
        return $result;
    }

    /**
     * curl方式发送post报文
     * @param $remoteServer 请求地址
     * @param $postData post 报文内容
     * @param $userAgent 用户属性
     * @return 返回报文
     */
    private function request_by_curl($remoteServer, $postData, $userAgent) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $remoteServer);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        $data = urldecode(curl_exec($ch));
        curl_close($ch);
        return $data;
    }

}
