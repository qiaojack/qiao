<?php

/**
 * 用户类
 */
class UserController extends BaseController {
    
    private $_userModel, $_novelModel, $_redis;
    
    public function init() {
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
    }
    
    //用户书架
    public function bookshelfAction() {
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        $bookshelf = $this->getBookshelf($user_id);
        if (!empty($bookshelf)) {
            foreach ($bookshelf as $key => $value) {
                $book_id = (int)$value['book_id'];
                $bookInfo = $this->getBookInfo($book_id);
                if (!empty($bookInfo)) {
                    $readIndex = !empty($value['chapter_id']) ? (int)$value['chapter_id'] : 1;
                    $bookshelf[$key] = [
                        'book_id' => $book_id,
                        'name' => $bookInfo['name'],
                        'cover' => isset($bookInfo['cover']) ? $bookInfo['cover'] : '',
                        'read_time' => (int)$value['read_time'],
                        'read_index' => $readIndex,
                        'readrate' => round(($readIndex / $bookInfo['count']) * 100),
                    ];
                }
            }
        }
//        dump($bookshelf);
        $assign = array(
            'isLogin' => ($user_id > 0) ? 1 : 0,
            'bookList' => !empty($bookshelf) ? $bookshelf : [],
        );
        $this->display('bookshelf', $assign);
    }
    
    //加入书架
    public function addBookAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int) $request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int) $request['chapter_id'] : 1;
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            throw new Exception_Msg(201, 'The user is not logged in');
        }
        
        $haveBook = $this->isHaveBook($user_id, $book_id);
        if (!$haveBook) {
            $insertData = [
                'user_id' => $user_id,
                'book_id' => $book_id,
                'chapter_id' => $chapter_id,
                'read_time' => 0,
            ];
            $insertId = $this->_userModel->insert('novel_bookshelf', $insertData);
            if (!empty($insertId)) {
                $bookshelf = $this->getBookshelf($user_id);
                array_unshift($bookshelf, $insertData);
                $this->_redis->hset('h5_bookshelf', $user_id, $bookshelf);
            }
        } else {
            throw new Exception_Msg(202, 'A bookshelf has been added');
        }
        
        $assign = array(
            'code' => 200,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //删除书籍
    public function delbookAction() {
        $postData = $this->getRequest()->getPost();
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            throw new Exception_Msg(201, 'The user is not logged in');
        }
        
        $read_book = isset($postData['read_book']) ? $postData['read_book'] : [];
        $bookshelf = $this->getBookshelf($user_id);
        if (!empty($user_id) && !empty($read_book)) {
            foreach ($bookshelf as $key => $value) {
                if (in_array($value['book_id'], $read_book)) {
                    $this->_userModel->delete('novel_bookshelf', 'user_id = :user_id AND book_id = :book_id', [':user_id' => $user_id, ':book_id' => $value['book_id']]);
                    unset($bookshelf[$key]);
                }
            }
            //存入Redis缓存
            $this->_redis->hset('h5_bookshelf', $user_id, $bookshelf);
        }
        
        $assign = array(
            'code' => 200,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //我的个人中心
    public function centerAction() {
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($user_id)) {
            $this->redirect('/h5/login');
            exit;
        }
        
        $assign = array(
            'userInfo' => $userInfo
        );
        $this->display('center', $assign);
    }
    
    //购书记录
    public function buylogAction() {
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        $queryData = $this->_userModel->getUserBuyLog($user_id);
        
        $buyLogList = [];
        if (!empty($userInfo) && !empty($queryData)) {
            foreach ($queryData as $value) {
                $bookInfo = $this->getBookInfo($value['book_id']);
                if (!empty($bookInfo)) {
                    $buyLogList[] = array(
                        'book_id' => $value['book_id'],
                        'name' => $bookInfo['name'],
                        'author' => $bookInfo['author'],
                        'cover' => $bookInfo['cover'],
                        'trade_coin' => (int)$value['trade_coin'],
                        'buytime' => date('Y-m-d', $value['create_at']),
                    );
                }
            }
        }
        
        $assign = array(
            'buyLogList' => $buyLogList
        );
        $this->display('buylog', $assign);
    }
    
    //充值记录
    public function rechargelogAction() {
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        $queryData = $this->_userModel->getUserRechargeLog($user_id);
        $rechargeLog = [];
        if (!empty($queryData)) {
            foreach ($queryData as $value) {
                $rechargeLog[] = array(
                    'title' => '充值金额',
                    'pay_coin' => $value['pay_coin'],
                    'pay_amt' => $value['pay_amt'],
                    'recharge_time' => date('Y-m-d', $value['create_at']),
                );
            }
        }
        
        $assign = array(
            'rechargeLog' => $rechargeLog
        );
        $this->display('rechargelog', $assign);
    }
    
    //阅读记录
    public function readingAction() {
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        $bookList = [];
        $readLog = $this->_redis->hget('readlog', $user_id);
        if (!empty($readLog)) {
            $sum1 = array_sum(array_column($readLog, 'readIndex'));
            $readdblog = $this->_userModel->getBookReadLog($user_id);
            $sum2 = array_sum(array_column($readdblog, 'chapter_id'));
            
            //如果发现有数据变化则更新db数据
            if ($sum1 != $sum2) {
                $insertData = [];
                $this->_userModel->delete('novel_read_log', "user_id = {$user_id}");
                foreach ($readLog as $key => $value) {
                    $insertData[] = array(
                        'user_id' => $user_id,
                        'book_id' => $value['book_id'],
                        'read_time' => isset($value['readTime']) ? $value['readTime'] : 0,
                        'chapter_id' => $value['readIndex'],
                    );
                }
                $this->_userModel->insertMulti('novel_read_log', $insertData);
            }
            
            foreach ($readLog as $key => $value) {
                $book_id = $value['book_id'];
                $bookInfo = $this->getBookInfo($book_id);
                if (!empty($bookInfo)) {
                    $bookList[] = array(
                        'book_id' => $book_id,
                        'read_index' => $value['readIndex'],
                        'name' => $bookInfo['name'],
                        'author' => $bookInfo['author'],
                        'cover' => $bookInfo['cover'],
                        'read_now' => $value['readName'],
                        'book_new' => $value['lastName'],
                    );
                }
            }
        }
        
        $assign = array(
            'reading' => $bookList
        );
        $this->display('reading', $assign);
    }
}
