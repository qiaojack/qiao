<?php

/**
 * 书籍章节支付
 */
class PayController extends BaseController {
    
    private $_novelModel, $_userModel, $_payModel, $_statsModel, $_redis;
    private $domain, $channel;
    
    public function init(){
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_payModel = PayModel::getInstance();
        $this->_statsModel = StatsModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $jump = isset($request['jump']) ? urldecode($request['jump']) : __DOMAIN_URL__ . '/h5/pay';
        
        $selected = 2; //默认选中第几项
        $recharge = $this->giveBookCoins();
        
        if (!empty($recharge)) {
            $userInfo = $this->getLoginUser();
            $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
            
            foreach ($recharge as $key => $value) {
                $urlquery = "user_id={$user_id}&channel={$this->channel}&price={$value['price']}&jump=" . base64_encode($jump);
                $recharge[$key]['bkey'] = base64_encode4url($urlquery);
            }
        }
        
        $assign = array(
            'appid' => 'wx52117d0dac9962b0', //jw21钱塘文学appid
            'jump' => $jump,
            'selected' => $selected,
            'recharge' => $recharge,
        );
        $this->display('index', $assign);
    }
    
    //微信支付
    public function wechatAction() {
        $request = $this->getRequest()->getQuery();
        $bkey = isset($request['bkey']) ? base64_decode4url($request['bkey']) : '';
        if (empty($bkey)) {
            $this->redirect(__DOMAIN_URL__);
            exit;
        }
        
        parse_str($bkey, $request);
        $user_id = isset($request['user_id']) ? (int)$request['user_id'] : 0;
        $channel = isset($request['channel']) ? $request['channel'] : '';
        $price = isset($request['price']) ? $request['price'] : 0;
        $jump = isset($request['jump']) ? urldecode(base64_decode($request['jump'])) : __DOMAIN_URL__;
        
        //根据回调地址分析来源于哪本书或渠道
        $book_id = $extend_id = $channel_type = 0;
        if (!empty($jump)) {
            $explode = explode('?', $jump);
            if (isset($explode[1])) {
                parse_str($explode[1], $params);
                $book_id = isset($params['book_id']) ? (int)$params['book_id'] : 0;
            }
            $channelExtend = $this->_userModel->getUserFromExtend($user_id, $channel); //获取推广ID
            $extend_id = $channelExtend['extend_id'];
            $channel_type = $channelExtend['channel_type'];
        }
        
        //调用微信支付
        $mchid = '1486218332'; //微信支付商户号 PartnerID 通过微信支付商户资料审核后邮件发送
        $appid = 'wx52117d0dac9962b0'; //微信支付申请对应的公众号的APPID
        $appKey = '90b7911fb21f998fa8eb675d027e898a'; //微信支付申请对应的公众号的APP Key
        $apiKey = 'CZXf58h9vBe2e8o3CAStD8YrCFMY8gOQ'; //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
        
        //1.获取用户openid
        Yaf_Loader::import(APP_PATH . '/library/WxpayService.php');
        $wxPay = new WxpayService($mchid, $appid, $appKey, $apiKey);
        $openId = $wxPay->GetOpenid();
        if (empty($openId)) {
            $this->redirect(__DOMAIN_URL__);
            exit;
        }
        
        //2.统一下单
        $outTradeNo = strtoupper(substr(sha1($user_id . $price . __TIME__), 8, 16));
        $orderName = '微信充值书币';  //订单标题
        $notifyUrl = __DOMAIN_URL__ . '/h5/pay/notify'; //付款成功后的回调地址(不要有问号)
        $apiResult = $wxPay->createJsBizPackage($openId, $price, $outTradeNo, $orderName, $notifyUrl, __TIME__);
        $jsApiParameters = json_encode($apiResult);
        
        if (!empty($apiResult)) {
            //生成订单
            $data = [
                'pay_coin' => $price * 100,
                'pay_amt' => $price,  //付款金额，单位:元
                'user_id' => $user_id,
                'order_id' => $outTradeNo,
                'create_at' => __TIME__,
                'ftype' => $channel != 'm' ? 1 : 3,
                'extend_id' => $extend_id,
                'book_id' => $book_id,
                'channel' => $channel != 'm' ? $channel : '', //渠道
                'channel_type' => $channel_type,
            ];
            $this->_payModel->createOrder($data); //生成订单入库
        }
        
        $assign = array(
            'jump' => $jump,
            'jsApiParameters' => $jsApiParameters
        );
        $this->display('wechat', $assign);
    }
    
    //微信支付回调方法
    public function notifyAction() {
        $input = file_get_contents("php://input");
        $result = xmlToArray($input);
        $return_code = isset($result['result_code']) ? $result['result_code'] : 'FAIL';
        $transaction_id = isset($result['transaction_id']) ? $result['transaction_id'] : '';
        
        //记录支付回调日志
        eYaf\Logger::getLogger('pay_notify')->info(json_encode($result));
        
        $status = 'FAIL';
        if (!empty($result) && $return_code == 'SUCCESS') {
            //商户订单号
            $order_id = isset($result['out_trade_no']) ? trim($result['out_trade_no']) : '';
            $chargeInfo = $this->_payModel->getOrderInfo($order_id); //查询订单
            
            if (!empty($chargeInfo) && $chargeInfo['order_st'] == 0) {
                $pay_amt = is_float($chargeInfo['pay_amt']) ? (float)$chargeInfo['pay_amt'] : (int)$chargeInfo['pay_amt'];
                $user_id = (int)$chargeInfo['user_id'];
                $bookCoin = $this->giveBookCoins($pay_amt);
                $giveCoins = !is_array($bookCoin) ? (int)$bookCoin : 0;
                $pay_coin = (int)$chargeInfo['pay_coin'] + $giveCoins;
                
                //更新支付状态
                $updateData = ['order_st' => 1, 'tickets' => $giveCoins, 'transid' => $transaction_id];
                $this->_payModel->update('novel_pay_record', $updateData, "order_id = '{$order_id}'");
                
                //更新书币账户
                $this->_payModel->updateUserCoin($user_id, $pay_coin);
                
                //更新用户缓存数据
                $query = $this->_userModel->getUserByUserId($user_id);
                $userInfo = $this->getLoginUser($query['channel'], $query['openid']);
                $this->_userModel->updateUserInfo($userInfo, ['addcoin' => $pay_coin]);
                
                //更新统计相关数据
//                $extend_id = (int)$chargeInfo['extend_id'];
//                $book_id = (int)$chargeInfo['book_id'];
//                if (!empty($extend_id) && !empty($book_id)) {
//                    $this->_statsModel->updateInshow($user_id, $extend_id, $book_id, $pay_amt);
//                }
                
                $status = 'SUCCESS';
            }
            
            if (!empty($chargeInfo) && $chargeInfo['order_st'] == 1) {
                $status = 'SUCCESS';
            }
        }
        
        echo $status;
        exit;
    }
    
    //购买章节
    public function chapterAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int)$request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int)$request['chapter_id'] : 0;
        $endindex = isset($request['endindex']) ? (int)$request['endindex'] : 0; //批量购买截止数
        
        //取得用户信息
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        $book_coin = isset($userInfo['book_coin']) ? $userInfo['book_coin'] : 0;
        
        //计算购买章节的价格
        $handle = $this->_payModel->chapterHandle($user_id, $book_id, $chapter_id, $endindex);
        $trade_coin = $handle['amount'];
        
        //获取限时免费的书籍
        $isFree = $this->_novelModel->getTimelimitBook($book_id);
        
        //如果是免费或限免章节则跳过
        if (!$handle['isVip'] || $isFree) {
            throw new Exception_Msg(200, '免费或限免章节');
        }
        
        //用户是否登录
        if (empty($userInfo)) {
            throw new Exception_Msg(201, '用户未登录');
        }
        
        //判断用户的账户余额是否够扣
        if ($book_coin < $trade_coin) {
            throw new Exception_Msg(202, '账户余额不足');
        }
        
        //查看用户是否对该章节付费
        if (!$endindex) {
            $isbuy = $this->_payModel->isUserPayChapter($user_id, $book_id, $chapter_id);
            
            if ($isbuy) {
                throw new Exception_Msg(203, '该章已购买');
            }
        }
        
        //扣除书币
        $this->_payModel->deductions($user_id, $trade_coin);
        
        //扣除用户缓存的书币数据
        $this->_userModel->updateUserInfo($userInfo, ['decoin' => $trade_coin]);
        
        //记录章节消费记录
        $this->_payModel->tradeRecord($user_id, $book_id, $trade_coin);
        
        //已购买的章节记入缓存
        $this->_payModel->updatePayChapter($user_id, $book_id, $handle['chapters']);
        
        //章节书币消耗记录
        $this->_payModel->chapterExpend($book_id, $chapter_id, $trade_coin);
        $this->userPayLog($user_id, $handle['paylog']); //书币消耗记录到mongo
        
        $assign = [
            'code' => 200,
            'rows' => [
                'isbuy' => 1,
                'trade_coin' => $trade_coin,
            ]
        ];
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    /**
     * 用户书币消耗日志
     * @param int $user_id 用户ID
     * @param array $paylog 用户书币消耗日志
     */
    public function userPayLog($user_id = 0, $paylog = []) {
        $mongo = Db\Mongo::getInstance();
        if (!empty($paylog)) {
            $flag = $user_id % 10;
            $mongo->insert('user_consume_record_' . $flag, $paylog);
        }
    }
    
    //给用户充值书币
    public function chargecoinAction() {
        $user_id = 89140;
        $pay_coin = 5500;
        $channel = 'jw21';
        $openid = 'oky_dv38x8b3V_54-Wcgiac8sqUg';
        
        //更新书币账户
        $this->_payModel->updateUserCoin($user_id, $pay_coin);
        
        //更新用户缓存数据
        $userInfo = $this->getLoginUser($channel, $openid);
        $this->_userModel->updateUserInfo($userInfo, ['addcoin' => $pay_coin]);
    }
}
