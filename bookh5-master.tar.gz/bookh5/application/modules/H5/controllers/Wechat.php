<?php

/**
 * 微信功能开发
 */
class WechatController extends BaseController {
    
    private $_wechatModel, $_searchModel, $_userModel, $_payModel, $_redis;
    private $domain, $channel;
    
    public function init() {
        parent::init();
        $this->_wechatModel = WechatModel::getInstance();
        $this->_searchModel = SearchModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_payModel = PayModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    /**
     * 公众号登录
     * @param array $postData 数组数据
     */
    private function mplogin($postData = []) {
        $queryData = $this->_userModel->getInfo('novel_user', 'openid', $postData['openid'], 'user_id');
        if (!empty($queryData)) {
            $user_id = (int)$queryData['user_id'];
            $params = array(
                'nickname' => $postData['nickname'],
                'avatar' => $postData['headimgurl'],
                'lastlogintime' => __TIME__,
            );
            $this->_userModel->update('novel_user', $params, "user_id = {$user_id}");
        } else {
            $userInfo = array(
                'nickname' => isset($postData['nickname']) ? $postData['nickname'] : '',
                'sex' => isset($postData['sex']) ? ($postData['sex'] == 1 ? 1 : 0) : 1,
                'openid' => $postData['openid'],
                'unionid' => isset($postData['unionid']) ? $postData['unionid'] : '',
                'avatar' => isset($postData['headimgurl']) ? $postData['headimgurl'] : '',
                'login_type' => 1,
                'login_fromid' => 1,
                'lastlogintime' => __TIME__,
                'create_at' => __TIME__,
                'channel' => $this->channel,
            );
            $user_id = $this->_userModel->insertIgnore('novel_user', $userInfo); //新增用户
            $userInfo['user_id'] = $user_id;
        }
        
        $this->settingLogin($userInfo, $this->domain);
        
        return $user_id;
    }
    
    //签到与最近阅读
    public function lastReadAction() {
        $postData = file_get_contents('php://input');
        parse_str($postData, $wxUser);
        
        $openId = isset($wxUser['openid']) ? $wxUser['openid'] : '';
        $userInfo = $this->getLoginUser($this->channel, $openId);
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            $user_id = !empty($wxUser) ? $this->mplogin($wxUser) : 0; //自动登录
        }
        
        //阅读记录
        $lastread = $this->_userModel->getUserRead($user_id, 0, 1);
        $readlist = $this->_userModel->getUserRead($user_id, 0, 3);
        
        //记录签到
        $book_coin = 50;
        $readSign = $this->_wechatModel->bookReadSign($user_id, $book_coin);
        
        //赠送书币
        if ($readSign['issign'] == 1) {
            //更新数据表书币
            $this->_payModel->updateUserCoin($user_id, $book_coin);
            //更新用户缓存数据
            $this->_userModel->updateUserInfo($userInfo, ['addcoin' => $book_coin]);
        }
        
        $assign = array(
            'code' => 200,
            'rows' => [
                'lastread' => $lastread,
                'readlist' => $readlist,
                'givecoin' => $readSign['givecoin'],
                'issign' => $readSign['issign'],
            ]
        );
        
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //关注并继续阅读
    public function goreadAction() {
        $postData = file_get_contents('php://input');
        parse_str($postData, $wxUser);
        $openId = isset($wxUser['openid']) ? $wxUser['openid'] : '';
        
        $userInfo = $this->getLoginUser($this->channel, $openId);
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            $user_id = !empty($wxUser) ? $this->mplogin($wxUser) : 0; //自动登录
        }
        
        $records = [];
        $readlog = $this->_userModel->getUserRead($user_id, 0, 1); //阅读记录
        if (!empty($readlog)) {
            $data = isset($readlog[0]) ? $readlog[0] : [];
            $book_id = !empty($data) ? $data['book_id'] : 0;
            $name = !empty($data) ? $data['name'] : '';
            $chapter_id = !empty($data) ? $data['readIndex'] : 0;
            $records = ['book_id' => $book_id, 'name' => $name, 'chapter_id' => $chapter_id + 1];
        }
        
        //更新用户为已关注状态
        $this->_wechatModel->update('novel_user', ['follow' => 1], "user_id = {$user_id} AND `channel` = '{$this->channel}'");
        $this->_userModel->updateUserFollow($user_id, $this->channel);
        
        $assign = array(
            'code' => 200,
            'rows' => $records,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //关键词搜索
    public function keywordAction() {
        $postData = file_get_contents('php://input');
        parse_str($postData, $wxUser);
        $openId = isset($wxUser['openid']) ? $wxUser['openid'] : '';
        $q = isset($wxUser['q']) ? trim($wxUser['q']) : '';
        $userInfo = $this->getLoginUser($this->channel, $openId);
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            $user_id = !empty($wxUser) ? $this->mplogin($wxUser) : 0; //自动登录
        }
        
        //过滤可能引起SQL注入的字符
        $keyword = !empty($q) ? real_escape_string($q) : '';
        
        $searchResult = array();
        $sysMpConf = $this->_userModel->getSysMpConf($this->domain);
        $sysUserId = isset($sysMpConf['sys_user_id']) ? (int)$sysMpConf['sys_user_id'] : 0;
        $query = $this->_wechatModel->getMpKeyword($sysUserId, $keyword);
        if (!empty($user_id) && !empty($query)) {
            $this->_wechatModel->searchKeywordStats($user_id, $query[0]['id']); //关键词搜索统计
        } else {
            $query = $this->_searchModel->getSearchResult($keyword, 30);
        }
        if (!empty($query)) {
            foreach ($query as $value) {
                $bookInfo = $this->getBookInfo($value['book_id']);
                if (!empty($bookInfo) && !empty($bookInfo['cover'])) {
                    $searchResult[] = array(
                        'book_id' => $bookInfo['book_id'],
                        'name' => $bookInfo['name'],
                        'cover' => $bookInfo['cover'],
                        'chapter_id' => isset($value['chapter_id']) ? $value['chapter_id'] : 0,
                    );
                }
            }
            $searchResult = array_slice($searchResult, 0, 6);
        }
        
        //第一个搜索结果存入数据库，添加搜索记录日志
        if (isset($searchResult[0]['name'])) {
            $this->_searchModel->updateSearch($searchResult[0]['name']);
        }
        
        $assign = array(
            'code' => 200,
            'rows' => $searchResult,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //上传微信安全回调域文件
    public function safecbackAction() {
        $global = file_get_contents('php://input');
        parse_str($global, $safeData);
        
        $filename = isset($safeData['filename']) ? $safeData['filename'] : '';
        $filetext = isset($safeData['filetext']) ? $safeData['filetext'] : '';
        
        if (empty($filename)) {
            throw new Exception_Msg(201, '文件错误');
        }
        
        $filepath = APP_PATH . "/public/{$filename}";
        file_put_contents($filepath, $filetext);
        
        $assign = array(
            'code' => 200,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //取消关注
    public function unfollowAction() {
        $postData = file_get_contents('php://input');
        parse_str($postData, $wxUser);
        $openId = isset($wxUser['openid']) ? $wxUser['openid'] : '';
        
        $userInfo = $this->getLoginUser($this->channel, $openId);
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        if (empty($userInfo)) {
            $user_id = !empty($wxUser) ? $this->mplogin($wxUser) : 0; //自动登录
        }
        
        //取消关注
        $condition = "user_id = {$user_id} AND `channel` = '{$this->channel}'";
        $this->_wechatModel->update('novel_mp_follow', ['follow' => 0], $condition);
        $this->_wechatModel->update('novel_user', ['follow' => 0], $condition);
        
        $assign = array(
            'code' => 200,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
}
