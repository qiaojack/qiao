<?php

/**
 * 读取分类
 */
class CategoryController extends BaseController {
    
    private $_novelModel, $_redis;
    
    public function init(){
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
    }
    
    //读取分类数据
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $format = isset($request['format']) ? (int) $request['format'] : 0;
        $cate_parent = $cate_childs = $third_childs = array();
        
        if (!$this->_redis->exists('h5_category')) {
            $queryData = $this->_novelModel->getCategoryList();
            if (!empty($queryData)) {
                foreach ($queryData as $value) {
                    $pid = $value['cate_pid'];
                    if ($pid == 0) {
                        $cate_parent[$value['cate_id']] = array('id' => $value['cate_id'], 'name' => $value['cate_name'], 'child' => [], 'third' => []);
                    } else {
                        $child_pid = $value['cate_id'];
                        $cate_childs[$pid][] = array('id' => $value['cate_id'], 'name' => $value['cate_name'], 'third' => $this->getChild($queryData, $child_pid));
                    }
                }
            }
            $categoryList = $cate_parent;
            foreach ($categoryList as $key => $value) {
                $categoryList[$key]['child'] = $cate_childs[$key];
            }
            $this->_redis->hset('h5_category', 1, $categoryList);
            $this->_redis->expire('h5_category', 2 * 3600); //缓存2小时
        } else {
            $categoryList = $this->_redis->hget('h5_category', 1);
        }
        
        if ($format) {
            $temp = array();
            foreach ($categoryList as $key => $value) {
                $temp[] = $value;
            }
            $categoryList = multi_array_sort($temp, 'id');
        }
        
        $assign = ['category' => $categoryList];
        $this->display('index', $assign);
    }
    
    //分类类型
    public function cateListAction() {
        $request = $this->getRequest()->getQuery();
        $cate_id = isset($request['cate_id']) ? (int) $request['cate_id'] : -1;
        if ($cate_id == -1) {
            echo $this->stringifyJSON(array('code' => 400, 'row' => []));
            exit;
        }
        
        $cateList = $this->_novelModel->getCateList($cate_id);
        
        $assign = array(
            'code' => 200,
            'rows' => $cateList,
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    //分类所属书籍的数据
    public function bookDataAction() {
        $request = $this->getRequest()->getQuery();
        $cate_id = isset($request['cate_id']) ? (int) $request['cate_id'] : -1;
        $page = isset($request['page']) ? (int) $request['page'] : 1;
        $book_size = isset($request['book_size']) ? (int) $request['book_size'] : 0;
        $length = isset($request['length']) ? (int) $request['length'] : 10;
        $st = isset($request['st']) ? (int) $request['st'] : -1;
        $r = isset($request['r']) ? (int) $request['r'] : 0;
        $offset = ($page - 1) * $length;
        
        $conditions = array();
        if ($cate_id > -1) {
            $conditions = array('cate_id' => $cate_id);
        }
        $childList = $this->_novelModel->getCateList($cate_id); //查看是否有子分类
        if (!empty($childList)) {
            $cateid_arr = array_column($childList, 'cate_id');
            array_unshift($cateid_arr, $cate_id);
            $conditions = array('cate_id' => $cateid_arr);
        }
        
        if ($st > -1) {
            $conditions['status'] = $st;
        }
        $conditions['size'] = $book_size;
        $bookList = $this->_novelModel->getCateListById($conditions, $offset, $length);
        if (!empty($bookList)) {
            foreach ($bookList as $key => $value) {
                $bookInfo = $this->getBookInfo($value['book_id']);
                if (empty($bookInfo)) continue;
                $bookList[$key] = array(
                    'book_id' => (int) $bookInfo['book_id'],
                    'name' => $bookInfo['name'],
                    'author' => $bookInfo['author'],
                    'cover' => $bookInfo['cover'],
                    'intro' => $bookInfo['intro'],
                    'cate_name' => $bookInfo['cate_name'],
                    'size' => $bookInfo['size'],
                    'status' => (int) $bookInfo['status'],
                );
            }
        }
        if ($r > 0) {
            $assign = array(
                'code' => 200,
                'rows' => $bookList
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        
        $assign = array(
            'cate_id' => $cate_id,
            'cateList' => $childList,
            'bookList' => $bookList,
        );
        $this->display('bookdata', $assign);
    }
    
    /**
     * 得到子级数组
     * @param int $data
     * @param int $myId
     */
    private function getChild($data, $myId) {
        $newArr = [];
        if (is_array($data)) {
            $k = 0;
            foreach ($data as $a) {
                if ($a['cate_pid'] == $myId) {
                    $newArr[$k]['cate_id'] = $a['cate_id'];
                    $newArr[$k]['cate_pid'] = $a['cate_pid'];
                    $newArr[$k]['cate_name'] = $a['cate_name'];
                    $k++;
                }
            }
        }
        return $newArr ? $newArr : [];
    }

}
