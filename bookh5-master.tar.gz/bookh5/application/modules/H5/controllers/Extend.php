<?php

/**
 * 推广中转页
 */
class ExtendController extends BaseController {
    
    private $_userModel, $_statsModel, $_redis;
    private $domain, $channel;
    
    public function init() {
        parent::init();
        $this->_userModel = UserModel::getInstance();
        $this->_statsModel = StatsModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int)$request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int)$request['chapter_id'] : 1;
        $extend_id = isset($request['cid']) ? (int)$request['cid'] : 0; //推广ID
        $channel_type = isset($request['channel_type']) ? (int)$request['channel_type'] : 1; //渠道类型 0:内推 1:外推
        
        //取得用户数据
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        //内推统计
        if (!empty($user_id) && $channel_type == 0) {
            $this->_statsModel->inshow($user_id, $extend_id, $book_id);
        }
        
        $params = array(
            'book_id' => $book_id,
            'chapter_id' => $chapter_id,
            'cid' => $extend_id,
            'channel_type' => $channel_type,
        );
        $redirect_uri = __DOMAIN_URL__ . '/h5/read/content?' . http_build_query($params);
        
        //如果用户之前登录过则直接跳转
        if (!empty($user_id)) {
            $this->redirect($redirect_uri);
            exit;
        }
        
        $config = $this->_userModel->getSysMpConf($this->domain);
        $query = array(
            'appid' => $config['app_id'],
            'redirect_uri' => $redirect_uri,
            'response_type' => 'code',
            'scope' => 'snsapi_userinfo',
            'state' => '#wechat_redirect',
        );
        
        $requestURL = "https://open.weixin.qq.com/connect/oauth2/authorize?" . http_build_query($query);
        $this->redirect($requestURL);
    }
}
