
<?php

/**
 * 搜索小说
 */
class SearchController extends BaseController {
    
    private $_searchModel;
    
    public function init() {
        parent::init();
        $this->_searchModel = SearchModel::getInstance();
    }
    
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $shuffle = isset($request['shuffle']) ? (int)$request['shuffle'] : 0;
        
        if (!empty($shuffle)) {
            $hotdata = $this->hot(8);
            $assign = array(
                'code' => 200,
                'rows' => $hotdata,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        
        $searchResult = $this->hot(8);
        $assign = array(
            'searchResult' => $searchResult
        );
        $this->display('index', $assign);
    }
    
    //根据关键词搜索数据
    public function resultAction() {
        $request = $this->getRequest()->getQuery();
        $q = isset($request['q']) ? trim(urldecode($request['q'])) : '';
        
        //过滤可能引起SQL注入的字符
        $keyword = !empty($q) ? real_escape_string($q) : '';
        
        $searchResult = $this->query($keyword);
        
        $assign = array(
            'searchResult' => $searchResult,
        );
        $this->display('result', $assign);
    }
    
    /**
     * 热门搜索
     * @param int $count 获取的条数
     */
    private function hot($count = 8) {
        $searchHot = $this->_searchModel->getHotSearch(40);
        $data = array();
        if (!empty($searchHot)) {
            foreach ($searchHot as $value) {
                $bookInfo = $this->_searchModel->getBookInfoByName($value['content']);
                if (!empty($bookInfo)) {
                    $data[] = array('book_id' => $bookInfo['book_id'], 'name' => $value['content']);
                }
            }
            shuffle($data);
            $data = array_slice($data, 0, $count);
        }
        return $data;
    }
    
    /**
     * 搜索自动补全内容
     * @param string $keywords 关键词
     */
    public function completeAction() {
        $request = $this->getRequest()->getQuery();
        $q = isset($request['q']) ? trim(urldecode($request['q'])) : '';
        
        //过滤可能引起SQL注入的字符
        $keyword = !empty($q) ? real_escape_string($q) : '';
        
        $searchResult = array();
        if (!empty($keyword)) {
            $searchResult = $this->_searchModel->completeData($keyword);
        }
        
        $assign = array(
            'code' => 200,
            'rows' => $searchResult
        );
        echo $this->stringifyJSON($assign);
        exit;
    }

    /**
     * 搜索结果查询
     * @param string $keywords 关键词
     */
    private function query($keywords) {
        $searchResult = array();
        $query = $this->_searchModel->getSearchResult($keywords, 50);
        
        if (!empty($query)) {
            foreach ($query as $value) {
                $bookInfo = $this->getBookInfo($value['book_id']);
                if (!empty($bookInfo)) {
                    $searchResult[] = $bookInfo;
                }
            }
        }
        //第一个搜索结果存入数据库，添加搜索记录日志
        if (isset($searchResult[0]['name'])) {
            $this->_searchModel->updateSearch($searchResult[0]['name']);
        }
        
        return $searchResult;
    }
}
