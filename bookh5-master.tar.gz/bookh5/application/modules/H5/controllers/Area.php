<?php

/**
 * 男女生专区
 */
class AreaController extends BaseController {
    
    private $_novelModel;
    
    public function init() {
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
    }
    
    //男生专区
    public function boyAction() {
        $request = $this->getRequest()->getQuery();
        $type = isset($request['type']) ? (int)$request['type'] : 0;
        $page = isset($request['page']) ? (int)$request['page'] : 1;
        $length = isset($request['length']) ? (int)$request['length'] : 20;
        $shuffle = isset($request['shuffle']) ? (int)$request['shuffle'] : 0;
        
        if (!empty($type)) {
            $recommend = $this->getConfData($type, $page, $length, $shuffle);
            $assign = array(
                'code' => 200,
                'rows' => $recommend,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        $assign = array(
            'a' => $this->getConfData(105, 1, 4), //小编推荐
            'b' => $this->getChildBook(1), //热门分类
            'c' => $this->getConfData(108, 1, 8), //完结热推
            'd' => $this->getConfData(107, 1, 5), //人气最热
        );
        $this->display('boy', $assign);
    }
    
    //女生专区
    public function girlAction() {
        $request = $this->getRequest()->getQuery();
        $type = isset($request['type']) ? (int)$request['type'] : 0;
        $page = isset($request['page']) ? (int)$request['page'] : 1;
        $length = isset($request['length']) ? (int)$request['length'] : 20;
        $shuffle = isset($request['shuffle']) ? (int)$request['shuffle'] : 0;
        
        if (!empty($type)) {
            $recommend = $this->getConfData($type, $page, $length, $shuffle);
            $assign = array(
                'code' => 200,
                'rows' => $recommend,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        $assign = array(
            'a' => $this->getConfData(109, 1, 4), //小编推荐
            'b' => $this->getChildBook(2), //热门分类
            'c' => $this->getConfData(112, 1, 8), //完结热推
            'd' => $this->getConfData(111, 1, 5), //人气最热
        );
        $this->display('girl', $assign);
    }
    
    //查看更多
    public function moreAction() {
        $request = $this->getRequest()->getQuery();
        $mode = isset($request['mode']) ? (int)$request['mode'] : 1;
        
        $silde_id = $mode == 1 ? 4 : 5;
        $typeid_a = $mode == 1 ? 115 : 118;
        $typeid_b = $mode == 1 ? 116 : 119;
        $typeid_c = $mode == 1 ? 117 : 120;
        
        $assign = array(
            'mode' => $mode,
            'slide' => $this->_novelModel->carouselSlide($silde_id, 3), //幻灯片
            'a' => $this->getConfData($typeid_a, 1, 5), //精品热推
            'b' => $this->getConfData($typeid_b, 1, 8), //最佳人气
            'c' => $this->getConfData($typeid_c, 1, 10), //潜力新书
        );
        $this->display('more', $assign);
    }
    
    /**
     * 读取热门分类下数据
     * @param int $cate_id 父级分类
     */
    private function getChildBook($cate_id = 1) {
        $cateList = $this->_novelModel->getCateList($cate_id);
        $data = [];
        foreach ($cateList as $value) {
            $child_cateid = $value['cate_id'];
            $childCateList = $this->_novelModel->getCateList($child_cateid);
            $childCateArr = array_column($childCateList, 'cate_id');
            $conditions = ['cate_id' => $childCateArr];
            $bookList = $this->_novelModel->getCateListById($conditions, 1, 4);
            if (!empty($bookList) && count($bookList) >= 4) {
                foreach ($bookList as $bk => $bv) {
                    $bookInfo = $this->getBookInfo($bv['book_id']);
                    if (!empty($bookInfo)) {
                        $bookList[$bk] = array(
                            'book_id' => (int)$bookInfo['book_id'],
                            'name' => $bookInfo['name'],
                            'author' => $bookInfo['author'],
                            'cover' => $bookInfo['cover'],
                        );
                    }
                }
                $data[] = ['name' => $value['cate_name'], 'data' => $bookList];
            }
        }
        shuffle($data);
        $recordList = array_slice($data, 0, 4);
        return $recordList;
    }
    
}
