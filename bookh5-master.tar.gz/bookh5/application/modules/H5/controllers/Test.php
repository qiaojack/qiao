<?php

/**
 * 测试用文件
 */
class TestController extends BaseController {
    
    private $_userModel, $_payModel, $_novelModel, $_redis;
    private $domain, $channel;
    
    public function init(){
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_payModel = PayModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    public function indexAction() {
        $assign = array();
        $this->display('index', $assign);
    }
    
    public function mongodbAction() {
//        $manager = new MongoDB\Driver\Manager("mongodb://bookuser:p3I5wybaJlh0MYnx@192.168.1.107:27017");
////        dump($manager);
//
//        $bulk = new MongoDB\Driver\BulkWrite;
//        $document = array( 
//            'user_id' => 1, 
//            'nickname' => "随风随影", 
//            'book_id' => 100,
//            'book_name' => "血祀",
//            'chapter_id' => 21,
//            'chapter_name' => '第二十一章 水彩画上的坟地',
//            'book_coin' => 20,
//            'create_at' => __TIME__,
//        );
////        $bulk->insert($document);
////        $manager->executeBulkWrite('novel.user_consume_1', $bulk);
//        
//        $manager = Db\Mongo::getInstance();
//        $manager->insert('user_consume_1', [$document]);
        
//        $mongo = Db\Mongo::getInstance();
//        $delets = [
//            ['q' => [], 'limit' => 0]
//        ];
//        $mongo->del('user_consume_1', $delets);
    }

    public function removeAction() {
        $list = $this->_redis->keys('bookdata_conf_*');
//        dump($list);
        foreach ($list as $value) {
            $this->_redis->del($value);
        }
    }
    
    public function frombookAction() {
        $sys_user_id = 10;
        $keywordStats = $this->_redis->hGet('mp_keyword_stats', $sys_user_id);
        
        $recordList = [];
        $sql = "SELECT id, user_id, book_id FROM novel_pay_record WHERE order_st = 1 AND create_at > 1530174520";
        $datalist = $this->_userModel->fetchAll($sql);
        foreach ($datalist as $value) {
            $user_id = $value['user_id'];
            if ($value['book_id'] == 0) { 
                $recordList[] = array(
                    'id' => $value['id'],
                    'user_id' => $user_id,
                    'book_id' => in_array($user_id, $keywordStats) ? 3567 : 0,
                );
            }
        }
//        dump($recordList);
        foreach ($recordList as $value) {
            $this->_userModel->update('novel_pay_record', ['book_id' => $value['book_id']], "id = {$value['id']}");
        }
    }
    
    public function redisAction() {
//        $data = $this->_redis->set('test', ['a' => 1, 'b' => 2, 'c' => 3]);
//        $data = $this->_redis->del('test');
//        $data = $this->_redis->get('bookdata_conf_111');
//        dump($data);
        
//        $sql = "SELECT user_id, create_at FROM novel_bookcoin";
//        $bookCoin = $this->_novelModel->fetchAll($sql);
////        dump($bookCoin);
//        foreach ($bookCoin as $value) {
//            $this->_redis->hset('sign_bookcoin', $value['user_id'], $value['create_at']);
//        }
        $book_id = 3322;
        $cacheKey = 'book_list';
        $query = $this->_redis->hget($cacheKey, $book_id);
//        dump($query);
        if (empty($query)) {
            echo 1111;
        } else {
            dump($query);
        }
    }
    
    public function cacheAction() {
        $book_id = 5173;
        $index = 3;
        $cacheKey = "content_{$book_id}";
        if (!$this->_redis->hexists($cacheKey, $index)) {
            $apipath = "http://192.168.1.107:17331/app/read/index?book_id={$book_id}&index={$index}";
            $httpClient = new HttpClient($apipath, 'GET');
            $httpClient->exec();
            $response = $httpClient->getResponseBody();
            $jsonInfo = !empty($response) ? json_decode($response, true) : [];
            $body = isset($jsonInfo['info']) ? $jsonInfo['info'] : '';
            $this->_redis->hset($cacheKey, $index, $body);
            if ($this->_redis->hlen($cacheKey) == 1) {
                $this->_redis->expire($cacheKey, 8 * 3600);
            }
        } else {
            $body = $this->_redis->hget($cacheKey, $index);
        }
        dump($body);
    }
    
    public function remAction() {
        $sql = "SELECT book_id, COUNT(*) AS num FROM novel_chapter GROUP BY book_id  HAVING num > 1 ORDER BY num DESC";
        $dataList = $this->_userModel->fetchAll($sql);
        foreach ($dataList as $value) {
            $sql = "SELECT id FROM novel_chapter WHERE book_id = {$value['book_id']}";
            $query = $this->_userModel->fetchAll($sql);
            if (!empty($query)) {
                $idarrs = array_column($query, 'id');
//                var_dump($idarrs);
                $result = array_slice($idarrs, 1, count($idarrs));
//                var_dump($result);
                $sql = "DELETE FROM novel_chapter WHERE id IN (" . join(',', $result) . ")";
                $this->_userModel->execute($sql);
            }
        }
    }
    
    public function followAction() {
        $sql = "select * from novel_mp_follow where channel = 'jw12' and create_at >= 1531263600";
        $dataList = $this->_userModel->fetchAll($sql);
        foreach ($dataList as $value) {
            $condition = "user_id = {$value['user_id']} AND extend_id = {$value['extend_id']} AND book_id = 4189";
            $this->_novelModel->update('novel_channel_stats', ['follow_num' => 1], $condition);
        }
    }
    
    
    public function paytimeAction() {
        $sql = "select id, create_at from novel_pay_record where ftype = 1";
        $dataList = $this->_userModel->fetchAll($sql);
        foreach ($dataList as $value) {
            $condition = "id = {$value['id']}";
//            $datetime = date('Y-m-d H:i:s', $value['create_at']);
            $this->_novelModel->update('novel_pay_record', ['pay_tid' => $value['create_at']], $condition);
        }
    }
    
    public function uniqidAction() {
//        $sql = "select user_id from novel_user where uniqid = '0'";
//        $dataList = $this->_userModel->fetchAll($sql);
//        foreach ($dataList as $value) {
//            $condition = "user_id = {$value['user_id']}";
//            $uniqid = mt_rand(pow(10,9), pow(10,10)-1);
//            $this->_novelModel->update('novel_user', ['uniqid' => $uniqid], $condition);
//        }
    }
    
    public function formatAction() {
        $book_id = 5287;
        $chapterlist = $this->_novelModel->readChapter($book_id, 'list');
        if (!empty($chapterlist)) {
            foreach ($chapterlist as $value) {
                $filepath = "/data/book/{$book_id}/{$value['index']}.txt";
                $content = fileGetContents($filepath);
                file_put_contents($filepath, formatContent($content));
            }
        }
    }
}
