<?php

/**
 * 章节及内容接口
 */
class ReadController extends BaseController {
    
    private $_userModel, $_payModel, $_novelModel, $_redis;
    private $domain, $channel;
    
    public function init(){
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_payModel = PayModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
        
        $this->domain = $_SERVER['HTTP_HOST'];
        $this->channel = explode('.', $this->domain)[0];
    }
    
    //章节列表
    public function chapterAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int) $request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int) $request['chapter_id'] : 0;
        $order = isset($request['order']) ? (int) $request['order'] : 0;
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        
        $totals = 0;
        $vipcount = 0;
        $bookdata = array();
        $chapterlist = $this->_novelModel->readChapter($book_id, 'list');
        if (!empty($chapterlist)) {
            $vipcount = array_sum(array_column($chapterlist, 'isvip'));
            if ($order == 1) {
                $chapterlist = array_reverse($chapterlist);
            }
            $totals = count($chapterlist);
            $bookdata = $chapterlist;
            
            //是否已购买章节
            $haystack = $this->_payModel->getBuyChapterRecord($user_id, $book_id);
            
            //获取限时免费的书籍
            $isFree = $this->_novelModel->getTimelimitBook($book_id);
            
            //0:免费 1:付费 2:已购 3:限免
            foreach ($bookdata as $key => $value) {
                $status = !$value['isvip'] ? 0 : 1;
                if ($isFree) { //限免
                    $status = 3;
                } else {
                    if (in_array($value['index'], $haystack)) {
                        $status = 2;
                    }
                }
                $bookdata[$key]['status'] = $status;
            }
        }
        
        $bookInfo = $this->getBookInfo($book_id);
        $assign = array(
            'book_id' => $book_id,
            'chapter_id' => $chapter_id,
            'isLogin' => !empty($user_id) ? 1 : 0,
            'name' => !empty($bookInfo) ? $bookInfo['name'] : '',
            'author' => !empty($bookInfo) ? $bookInfo['author'] : '',
            'count' => $totals,
            'freeTag' => $vipcount ? 0 : 1,
            'chapters' => $bookdata,
        );
        $this->display('chapter', $assign);
    }
    
    //章节内容
    public function contentAction() {
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int) $request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int) $request['chapter_id'] : 0;
        $extend_id = isset($request['cid']) ? (int) $request['cid'] : 0; //推广ID
        $channel_type = isset($request['channel_type']) ? (int) $request['channel_type'] : 1; //推广类型 0:内推 1:外推
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? (int)$userInfo['user_id'] : 0;
        
        //根据推广渠道判断是否有强制关注公众号
        if (!empty($userInfo) && !empty($extend_id) && $channel_type == 1) {
            $followRest = $this->_userModel->isFollowMp($user_id, $extend_id, $book_id);
            if (!$followRest['is_follow'] && $chapter_id >= $followRest['follow_id']) {
                if (isset($request['ajax'])) {
                    throw new Exception_Msg(2001, '公众号关注');
                } else {
                    $this->redirect('/h5/read/follow');
                    exit;
                }
            }
        }
        
        //关键字回复统计新增用户数
        if (!empty($userInfo)) {
            $this->_userModel->updateMpKeyWordNew($book_id, $userInfo, $this->domain);
        }
        
        //读取章节数据
        $chapterList = $this->_novelModel->readChapter($book_id, 'list');
        $chapterInfo = (!empty($chapterList) && isset($chapterList[$chapter_id - 1])) ? $chapterList[$chapter_id - 1] : [];
        if (empty($chapterInfo)) {
            $this->redirect("/h5/detail?book_id={$book_id}");
            exit;
        }
        
        $chapterCount = count($chapterList);
        $record = [
            'book_id' => $book_id,
            'chapter_id' => $chapter_id,
            'extend_id' => $extend_id,
            'channel_type' => $channel_type,
            'name' => !empty($chapterInfo) ? $chapterInfo['name'] : '', //章节名称
            'isvip' => !empty($chapterInfo) ? $chapterInfo['isvip'] : 1, //是否vip章节
            'size' => !empty($chapterInfo) ? $chapterInfo['size'] : 0, //字数
            'count' => $chapterCount,
            'book_coin' => 0,
            'isLogin' => !empty($user_id) ? 1 : 0,
            'haveBook' => 0,
            'isbuy' => 0,
        ];
        $content = $this->_novelModel->readChapter($book_id, $chapter_id);
        
        //判断书架、阅读进度、阅读记录
        if (!empty($user_id)) {
            $record['haveBook'] = $this->isHaveBook($user_id, $book_id); //是否已加入书架
            $record['isLogin'] = 1;
            $this->_userModel->updateBookshelf($user_id, $book_id, $chapter_id); //阅读进度
            $this->_userModel->userReadLog($user_id, $book_id, $chapter_id, $record['name']); //阅读记录
        }
        
        //获取限时免费的书籍
        $isFree = $this->_novelModel->getTimelimitBook($book_id);
        if ($isFree) {
            $record['isvip'] = 0;
        }
        
        //如果是付费章节
        if ($record['isvip'] == 1) {
            $record['book_coin'] = !empty($userInfo['book_coin']) ? $userInfo['book_coin'] : 0; //书币
            
            //计算所需支付的书币
            $record['paycount'] = (isset($chapterInfo['price']) && !empty($chapterInfo['price'])) ? $chapterInfo['price'] : round($record['size'] * 5 / 1000);
            
            //查看用户是否对该章节付费
            $record['isbuy'] = !empty($user_id) ? $this->_payModel->isUserPayChapter($user_id, $book_id, $chapter_id) : 0;
            
            //未购买或余额不足
            if (!$record['isbuy']) {
                $content = msubstr($content, 0, 100, 'utf-8', '');
            }
        }
        $record['content'] = '<p>' . str_replace("\n", "</p><p>", $content) . '</p>';
        
        //更新书籍和章节的浏览次数
        $this->_novelModel->updateReadBook($book_id);
        $this->_novelModel->updateReadChapter($book_id, $chapter_id);
        
        if (isset($request['ajax'])) {
            $assign = array(
                'code' => 200,
                'rows' => $record,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        $this->display('content', $record);
    }
    
    //意见反馈/章节报错
    public function feedbookAction() {
        $postData = $this->getRequest()->getPost();
        if (!empty($postData)) {
            $code = 201;
            if (!empty($postData)) {
                $book_id = isset($postData['book_id']) ? (int)$postData['book_id'] : 0;
                $insertData = array(
                    'book_id' => $book_id,
                    'platform' => 0,
                    'type' => isset($postData['type']) ? (int)$postData['type'] : 1,
                    'contact' => isset($postData['contact']) ? $postData['contact'] : '',
                    'desc' => isset($postData['desc']) ? $postData['desc'] : '',
                    'chapter' => isset($postData['chapter']) ? $postData['chapter'] : 0,
                    'create_time' => __TIME__,
                );
                $this->_novelModel->insert('novel_feedbook', $insertData);
                $code = 200;
            }

            $assign = array(
                'code' => $code,
                'rows' => [],
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        
        $request = $this->getRequest()->getQuery();
        $book_id = isset($request['book_id']) ? (int) $request['book_id'] : 0;
        $chapter_id = isset($request['chapter_id']) ? (int) $request['chapter_id'] : 0;
        
        $bookInfo = $this->getBookInfo($book_id);
        $chapterList = $this->_novelModel->readChapter($book_id, 'list');
        $chapterInfo = !empty($chapterList) ? $chapterList[$chapter_id - 1] : [];
        
        $assign = array(
            'book_id' => $book_id,
            'chapter_id' => $chapter_id,
            'bookInfo' => $bookInfo,
            'chapterInfo' => $chapterInfo,
        );
        $this->display('feedbook', $assign);
    }
    
    //关注公众号
    public function followAction() {
        $sysMpConf = $this->_userModel->getSysMpConf($this->domain);
        $assign = ['mp_name' => '', 'mp_account' => '', 'mp_qrcode' => ''];
        if (!empty($sysMpConf)) {
            $assign = array(
                'mp_name' => $sysMpConf['mp_name'],
                'mp_account' => $sysMpConf['mp_account'],
                'mp_qrcode' => __STATIC_URL__ . $sysMpConf['mp_qrcode'],
            );
        }
        
        $this->display('follow', $assign);
    }
    
}