<?php
/*
 * 微信功能模型操作类
 */

class WechatModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
        $this->redis = Db\Redis::getInstance();
    }
    
    /**
     * 用户签到送书币
     * @param int $user_id 用户ID
     * @param int $book_coin 书币
     */
    public function bookReadSign($user_id = 0, $book_coin = 0) {
        $cacheKey = 'sign_bookcoin';
        if (!$this->redis->hexists($cacheKey, $user_id)) {
            $issign = 1;
            $insertData = [
                'user_id' => $user_id,
                'book_coin' => $book_coin,
                'create_at' => __TIME__,
            ];
            $this->db->insert('novel_bookcoin', $insertData);
            
            //存入缓存
            $this->redis->hset($cacheKey, $user_id, $insertData['create_at']);
        } else {
            $signTime = $this->redis->hget($cacheKey, $user_id);
            $startTime = strtotime(date('Y-m-d'));
            $issign = ((int)$signTime < $startTime) ? 1 : 2;
            if ($issign == 1) {
                //更新签到时间
                $this->db->execute("UPDATE novel_bookcoin SET `create_at` = " . __TIME__ . " WHERE `user_id` = {$user_id}");
                $this->redis->hset($cacheKey, $user_id, __TIME__);
            }
        }
        
        return array(
            'issign' => $issign,
            'givecoin' => $issign < 2 ? $book_coin : 0,
        );
    }
    
    /**
     * 根据关键字搜索书
     * @param int $sysUserId 系统用户ID
     * @param string $keyword 关键字
     */
    public function getMpKeyword($sysUserId = 0, $keyword = '') {
        $sql = "SELECT id, book_id, chapter_id FROM novel_mp_keyword WHERE `sys_user_id` = {$sysUserId} AND `keyword` = '{$keyword}' LIMIT 1";
        $query = $this->db->fetchAll($sql);
        if (!empty($query)) { //增加点击次数
            $this->db->execute("UPDATE novel_mp_keyword SET `click` = `click` + 1 WHERE `id` = {$query[0]['id']}");
        }
        return $query;
    }
    
    /**
     * 关键字搜索统计
     * @param int $user_id 用户ID
     * @param int $keyword_id 关键字ID
     */
    public function searchKeywordStats($user_id = 0, $keyword_id = 0) {
        $sql = "SELECT id FROM novel_mp_keyword_stats WHERE user_id = {$user_id} AND keyword_id = {$keyword_id} LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (empty($query)) {
            $data = array(
                'user_id' => $user_id,
                'keyword_id' => $keyword_id
            );
            $this->db->insertIgnore('novel_mp_keyword_stats', $data);
        }
    }
    
}