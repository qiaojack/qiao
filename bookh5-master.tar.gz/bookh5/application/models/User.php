<?php
/*
 * 用户模型操作类
 */

class UserModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
        $this->redis = Db\Redis::getInstance();
    }
    
    /**
     * 获取用户书架数据
     * @param int $user_id 用户ID
     */
    public function getBookshelf($user_id = 0) {
        $sql = "SELECT user_id, book_id, read_time, chapter_id FROM novel_bookshelf WHERE user_id = {$user_id} ORDER BY bid DESC";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 判断用户是否有加入某本书到书架
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     */
    public function checkHaveBook($user_id = 0, $book_id = 0) {
        $sql = "SELECT bid FROM novel_bookshelf WHERE user_id = {$user_id} AND book_id = {$book_id} LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 获取用户的阅读记录
     * @param int $user_id 用户ID
     * @param int $book_id 书籍ID
     */
    public function getBookReadLog($user_id = 0, $book_id = 0) {
        if (!empty($book_id)) {
            $sql = "SELECT user_id, book_id, chapter_id, read_time FROM novel_read_log WHERE user_id = {$user_id} AND book_id = {$book_id} LIMIT 1";
            return $this->db->fetchRow($sql);
        } else {
            $sql = "SELECT user_id, book_id, chapter_id, read_time FROM novel_read_log WHERE user_id = {$user_id} ORDER BY read_time DESC LIMIT 30";
            return $this->db->fetchAll($sql);
        }
    }
    
    /**
     * 根据userid获取openid和channel
     * @param int $user_id 用户ID
     */
    public function getUserByUserId($user_id = 0) {
        $sql = "SELECT `openid`, `channel`, `follow` FROM novel_user WHERE user_id = {$user_id} LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 获取用户的信息
     * @param array $data 用户数组
     */
    public function getUserInfo($data = []) {
        $where = '1 = 1';
        if (isset($data['user_id'])) {
            $where = "`user_id` = '{$data['user_id']}'";
        } else if (isset($data['openid'])) {
            $where = "`openid` = '{$data['openid']}'";
        } else if (isset($data['unionid'])) {
            $where = "`unionid` = '{$data['unionid']}'";
        } else if (isset($data['mobile'])) {
            $where = "`mobile` = '{$data['mobile']}'";
        }
        $sql = "SELECT a.user_id, a.nickname, a.openid, a.unionid, a.mobile, a.sex, a.avatar, a.lastlogintime, a.channel, b.`book_coin` FROM "
                . "(SELECT * FROM novel_user WHERE {$where}) a "
                . "LEFT JOIN novel_user_account b ON a.user_id = b.user_id LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (!empty($query)) {
            $query['book_coin'] = !empty($query['book_coin']) ? $query['book_coin'] : 0;
            if (!empty($query['avatar']) && strpos($query['avatar'], 'http') === false) {
                $query['avatar'] = __STATIC_URL__  . $query['avatar'];
            }
        }
        return $query;
    }
    
    /**
     * 更新用户的缓存数据
     * @param array $userInfo 用户缓存
     * @param array $uparr 要更新的数据
     */
    public function updateUserInfo($userInfo = [], $uparr = []) {
        $userInfo['book_coin'] = isset($userInfo['book_coin']) ? $userInfo['book_coin'] : 0;
        if (!empty($userInfo['channel']) && !empty($userInfo['openid'])) {
            if (isset($uparr['addcoin'])) {
                $userInfo['book_coin'] += $uparr['addcoin'];
            } else if (isset($uparr['decoin'])) {
                if ($userInfo['book_coin'] >= $uparr['decoin']) {
                    $userInfo['book_coin'] -= $uparr['decoin'];
                }
            }
            $this->redis->set($userInfo['channel'] . '_' . $userInfo['openid'], $userInfo);
        }
    }
    
    /**
     * 用户购书记录
     * @param int $user_id 用户ID
     * @param int $length 展示条数
     */
    public function getUserBuyLog($user_id = 0, $length = 50) {
        $sql = "SELECT user_id, book_id, trade_coin, create_at FROM novel_trade_record WHERE user_id = {$user_id} ORDER BY create_at DESC LIMIT {$length}";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 用户充值记录
     * @param int $user_id 用户ID
     * @param int $length 展示条数
     */
    public function getUserRechargeLog($user_id = 0, $length = 50) {
        $sql = "SELECT user_id, pay_amt, pay_coin, create_at FROM novel_pay_record "
                . "WHERE user_id = {$user_id} AND order_st = 1 AND ftype = 1 ORDER BY create_at DESC LIMIT {$length}";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 用户阅读记录
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param int $chapter_id 章节ID
     * @param tring $chapterName 章节名称
     */
    public function userReadLog($user_id = 0, $book_id = 0, $chapter_id = 0, $chapterName = '') {
        $readlog = $this->redis->hexists('readlog', $user_id) ? $this->redis->hget('readlog', $user_id) : [];
        if (!empty($readlog)) {
            foreach ($readlog as $key => $value) {
                if ($value['book_id'] == $book_id) {
                    unset($readlog[$key]);
                }
            }
        }
        $bookInfo = $this->redis->hget('book_list', $book_id);
        if (!empty($book_id) && !empty($bookInfo)) {
            $value = array(
                'book_id' => $book_id,
                'name' => $bookInfo['name'],
                'cover' => $bookInfo['cover'],
                'lastIndex' => $bookInfo['last_index'],
                'lastName' => $bookInfo['last_name'],
                'readIndex' => $chapter_id,
                'readName' => $chapterName,
                'readTime' => __TIME__,
            );
            array_unshift($readlog, $value);
            $this->redis->hset('readlog', $user_id, $readlog);
        }
    }
    
    /**
     * 更新用户书架数据
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param int $chapter_id 章节ID
     */
    public function updateBookshelf($user_id = 0, $book_id = 0, $chapter_id = 0) {
        $sql = "UPDATE novel_bookshelf SET chapter_id = {$chapter_id} WHERE user_id = {$user_id} AND book_id = {$book_id}";
        $this->db->execute($sql);
        
        //更新书架缓存
        $bookshelf = $this->redis->hget('h5_bookshelf', $user_id);
        if (!empty($bookshelf)) {
            $result = array_keys(array_column($bookshelf, 'book_id'), $book_id);
            if (!empty($result)) {
                $index = $result[0];
                $bookshelf[$index]['chapter_id'] = $chapter_id;
                $this->redis->hset('h5_bookshelf', $user_id, $bookshelf);
            }
        }
    }
    
    /**
     * 根据用户ID获取阅读记录
     * @param int $user_id 用户ID
     * @param int $offset 起始点
     * @param int $length 数量
     */
    public function getUserRead($user_id = 0, $offset = 0, $length = 1) {
        $readlog = [];
        if($this->redis->hexists('readlog', $user_id)) {
            $readlog = $this->redis->hget('readlog', $user_id);
            if ($length) {
                $readlog = count($readlog) ? array_slice($readlog, $offset, $length) : [];
            }
        }
        return $readlog;
    }
    
    /**
     * 通过推广渠道标识获取appid和app_secret
     * @param string $domain 推广渠道域名
     */
    public function getSysMpConf($domain = 'm.jiuwei.com') {
        $channel = explode('.', $domain)[0];
        $redisKey = "{$channel}_sysmpconf";
        $sysmpconf = $this->redis->get($redisKey);
        if (empty($sysmpconf)) {
            $sql = "SELECT sys_user_id, mp_account, mp_name, app_id, app_secret, `domain`, `token`, mp_qrcode "
                . "FROM novel_mp_set WHERE `domain` = '{$domain}' LIMIT 1";
            $sysmpconf = $this->db->fetchRow($sql);
            $this->redis->setex($redisKey, 300, $sysmpconf); //缓存5分钟
        }
        return $sysmpconf;
    }
    
    /**
     * 检测用户是否已关注公众号
     * @param int $user_id 用户ID
     * @param int $extend_id 推广ID
     * @param int $book_id 书ID
     */
    public function isFollowMp($user_id = 0, $extend_id = 0, $book_id = 0) {        
        $is_follow = 0;
        $channel = explode('.', $_SERVER['HTTP_HOST'])[0];
        $sql = "SELECT id, follow, stats_id FROM novel_mp_follow WHERE `user_id` = {$user_id} AND `channel` = '{$channel}' LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (empty($query)) {
            //增加访问统计
            $stats_id = $this->mpExtendStats($user_id, $extend_id, $book_id);
            
            $insertData = ['user_id' => $user_id, 'channel' => $channel, 'extend_id' => $extend_id, 'stats_id' => $stats_id];
            $this->db->insertIgnore('novel_mp_follow', $insertData);
        } else {
            $userInfo = $this->getUserByUserId($user_id);
            $is_follow = !empty($userInfo) ? (int)$userInfo['follow'] : (int)$query['follow'];
            $stats_id = !empty($query['stats_id']) ? (int)$query['stats_id'] : 0;
        }
        
        //读取强制关注的章节ID
        $extend = $this->db->fetchRow("SELECT `id`, `force_chapter` FROM novel_channel_extend WHERE `id` = {$extend_id} LIMIT 1");
        $follow_id = !empty($extend) ? (int)$extend['force_chapter'] : 0;
        
        return array(
            'stats_id' => $stats_id,
            'is_follow' => $is_follow,
            'follow_id' => $follow_id
        );
    }
    
    /**
     * 获取渠道ID
     * @param int $user_id 用户ID
     * @param int $extend_id 推广ID
     * @param int $book_id 书ID
     */
    public function getMpExtendId($user_id = 0, $extend_id = 0, $book_id = 0) {
        $sql = "SELECT `id` FROM novel_channel_stats WHERE `user_id` = {$user_id} AND `extend_id` = {$extend_id} AND `book_id` = {$book_id} LIMIT 1";
        $query = $this->db->fetchRow($sql);
        return !empty($query) ? (int)$query['id'] : 0;
    }
    
    /**
     * 渠道推广统计
     * @param int $user_id 用户ID
     * @param int $extend_id 推广ID
     * @param int $book_id 书ID
     */
    public function mpExtendStats($user_id = 0, $extend_id = 0, $book_id = 0) {
        $stats_id = $this->getMpExtendId($user_id, $extend_id, $book_id);
        if (empty($stats_id)) {
            $insertData = array(
                'user_id' => (int)$user_id,
                'extend_id' => (int)$extend_id,
                'book_id' => (int)$book_id,
                'follow_num' => 0,
                'create_at' => __TIME__,
            );
            $this->db->insertIgnore('novel_channel_stats', $insertData);
            $stats_id = $this->db->lastInsertId();
        }
        return $stats_id;
    }
    
    /**
     * 更新用户的关注状态
     * @param int $user_id 用户ID
     * @param string $channel 推广渠道
     */
    public function updateUserFollow($user_id = 0, $channel = '') {
        $sql = "SELECT id, follow, create_at, stats_id FROM novel_mp_follow WHERE `user_id` = {$user_id} AND `channel` = '{$channel}' LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (!empty($query)) {
            if (empty($query['create_at'])) {
                $this->db->update('novel_mp_follow', ['follow' => 1, 'create_at' => __TIME__], "id = {$query['id']}");
                
                //更新外推统计表关注数
                if (!empty($query['stats_id'])) {
                    $this->db->execute("UPDATE novel_channel_stats SET follow_num = follow_num + 1 WHERE `id` = {$query['stats_id']}");
                }
            }
            $this->db->update('novel_mp_follow', ['follow' => 1], "id = {$query['id']}");
        }
    }
    
    /**
     * 用户通过关键词注册则累计新增用户数
     * @param int $book_id 书ID
     * @param array $userInfo 用户缓存数据
     * @param string $domain 来源渠道
     */
    public function updateMpKeyWordNew($book_id = 0, $userInfo = [], $domain = '') {
        $user_id = $userInfo['user_id'];
        $sysmpconf = $this->getSysMpConf($domain);
        $sys_user_id = !empty($sysmpconf) ? (int)$sysmpconf['sys_user_id'] : 0;
        
        $sql = "SELECT book_id FROM novel_mp_keyword WHERE book_id = {$book_id} AND sys_user_id = {$sys_user_id}";
        $mpKeyword = $this->db->fetchRow($sql);
        if (!empty($mpKeyword)) {
            $statsObj = $this->redis->hget('mp_keyword_stats', $sys_user_id);
            $keywordnew = !empty($statsObj) ? $statsObj : [];
            if (!in_array($user_id, $keywordnew)) {
                //记录通过关键词注册的用户
                array_push($keywordnew, $user_id);
                $this->redis->hset('mp_keyword_stats', $sys_user_id, $keywordnew);
                
                $sql = "UPDATE novel_mp_keyword SET `new_user` = `new_user` + 1 WHERE book_id = {$book_id} AND sys_user_id = {$sys_user_id}";
                $this->db->execute($sql);
            }
        }
    }
    
    /**
     * 获取用户来源推广ID与类型
     * @param int $user_id 用户ID
     * @param string $channel 渠道
     */
    public function getUserFromExtend($user_id, $channel) {
        $sql = "SELECT a.id, a.extend_id, b.`channel_type` FROM novel_mp_follow a, novel_channel_extend b "
                . "WHERE a.`user_id` = {$user_id} AND a.`channel` = '{$channel}' AND a.`extend_id` = b.`id` LIMIT 1";
        $query = $this->db->fetchRow($sql);
        return array(
            'extend_id' => !empty($query) ? (int)$query['extend_id'] : 0,
            'channel_type' => !empty($query) ? (int)$query['channel_type'] : 1,
        );
    }
    
}