<?php

/**
 * 统计数据
 */
class StatsModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
        $this->redis = Db\Redis::getInstance();
    }
    
    /**
     * 内推统计
     * @param int $user_id 用户ID
     * @param int $extend_id 推广ID
     * @param int $book_id 书ID
     */
    public function inshow($user_id = 0, $extend_id = 0, $book_id = 0) {
        $sql = "SELECT * FROM novel_channel_istats WHERE user_id = {$user_id} AND extend_id = {$extend_id} LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (empty($query)) {
            $insertData = array(
                'user_id' => $user_id,
                'extend_id' => $extend_id,
                'book_id' => $book_id,
                'create_at' => __TIME__,
            );
            $this->insert('novel_channel_istats', $insertData);
        }
    }
    
    /**
     * 更新内推统计的充值数据
     * @param int $user_id 用户ID
     * @param int $extend_id 推广ID
     * @param int $book_id 书ID
     * @param float $pay_amt 充值金额
     */
    public function updateInshow($user_id = 0, $extend_id = 0, $book_id = 0, $pay_amt = 0) {
        $sql = "UPDATE novel_channel_istats SET pay_num = pay_num + 1, pay_amt = pay_amt + {$pay_amt} "
        . "WHERE user_id = {$user_id} AND extend_id = {$extend_id} AND book_id = {$book_id}";
        $this->db->execute($sql);
    }
    
}
