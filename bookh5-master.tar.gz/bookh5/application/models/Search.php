<?php

/*
 * 统计模型操作类
 */

class SearchModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
    }
    
    /**
     * 获取完整的书籍信息
     * @param string $book_name 小说名称
     */
    public function getBookInfoByName($book_name = '') {
        $sql = "SELECT a.book_id, a.name, a.cate_id, b.cate_name, a.author, a.intro, a.cover, a.size, a.`status` "
                . "FROM novel_list a, novel_category b WHERE a.name = '{$book_name}' "
                . "AND a.cate_id = b.cate_id LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 搜索自动提示的数据
     * @param int $keywords 要搜索的关键词
     */
    public function completeData($keywords) {
        if (preg_match("/^[a-zA-Z\s]+$/", $keywords)) {
            $sql = "SELECT DISTINCT `name` FROM novel_list WHERE (`name` LIKE '" . $keywords . "%' "
                . "OR `author` LIKE '" . $keywords . "%') AND `site` = 2 AND `status` > -1 ORDER BY LENGTH(`name`) ASC LIMIT 10";
        } else {
            $sql = "SELECT DISTINCT `name` FROM novel_list WHERE "
                . "MATCH(`name`,`author`) AGAINST('+{$keywords}*' IN BOOLEAN MODE) "
                . "AND `site` = 2 AND `status` > -1 LIMIT 10";
        }
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 读取搜索出来的记录
     * @param string $keywords 关键字 书名或作者
     * @param int $length 长度
     */
    public function getSearchResult($keywords, $length = 10) {
        if (preg_match("/^[a-zA-Z\s]+$/", $keywords)) {
            $sql = "SELECT `book_id`, `name`, `author` FROM novel_list WHERE (`name` "
                . "LIKE '{$keywords}%' OR `author` LIKE '{$keywords}%') AND `site` = 2 AND `status` > -1 "
                . "ORDER BY LENGTH(`name`) ASC LIMIT {$length}";
        } else {
            $sql = "SELECT `book_id`, `name`, `author` FROM novel_list WHERE "
                . "MATCH(`name`,`author`) AGAINST('+{$keywords}*' IN BOOLEAN MODE) "
                . "AND `site` = 2 AND `status` > -1 LIMIT {$length}";
        }
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 读取热门搜索
     * @param int $length 数量
     */
    public function getHotSearch($length = 20) {
        $sql = "SELECT content FROM novel_search ORDER BY search_count DESC LIMIT {$length}";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 更新搜索内容
     * @param string $content 搜索内容
     */
    public function updateSearch($content = '') {
        $sql = "SELECT search_id, content FROM novel_search WHERE content = '{$content}' LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (!empty($query)) {
            $this->db->execute("UPDATE novel_search SET search_count = search_count + 1 WHERE search_id = {$query['search_id']}");
        } else {
            $this->db->insert('novel_search', ['content' => $content, 'search_count' => 1]);
        }
    }
    
}
