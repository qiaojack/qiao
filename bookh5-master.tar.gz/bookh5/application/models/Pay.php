<?php

/*
 * 支付模型操作类
 */

class PayModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
        $this->redis = Db\Redis::getInstance();
        $this->_novelModel = NovelModel::getInstance();
    }
    
    /**
     * 充值记录
     * @param array $params 数据参数
     */
    public function createOrder($params) {
        $this->db->insert('novel_pay_record', $params);
        return $this->db->lastInsertId();
    }
    
    /**
     * 计算章节的书币价格
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param int $chapter_id 章节ID
     * @param int $endindex 截止购买index
     */
    public function chapterHandle($user_id = 0, $book_id = 0, $chapter_id = 0, $endindex = 0) {
        $isVip = 0;
        $amount = 0;
        $chapters = [];
        $paylog = [];
        $chapterList = $this->_novelModel->readChapter($book_id, 'list');
        if (!empty($chapterList)) {
            $index = $chapter_id - 1;
            $bookInfo = $this->redis->hget('book_list', $book_id);
            $haystack = $this->getBuyChapterRecord($user_id, $book_id);
            $arrSlice = !$endindex ? [$chapterList[$index]] : array_slice($chapterList, $index, $endindex);
            foreach ($arrSlice as $value) {
                $isVip = $value['isvip'];
                if (!in_array($value['index'], $haystack)) {
                    $book_coin = !empty($value['price']) ? $value['price'] : round($value['size'] * 5 / 1000);
                    $amount += $book_coin;
                    $chapters[] = $value['index'];
                    $paylog[] = array(
                        'user_id' => (int)$user_id,
                        'book_id' => (int)$book_id,
                        'book_name' => $bookInfo['name'],
                        'chapter_id' => (int)$value['index'],
                        'chapter_name' => $value['name'],
                        'book_coin' => (int)$book_coin,
                        'create_at' => __TIME__,
                    );
                }
            }
        }
        return [
            'isVip' => $isVip,
            'amount' => $amount,
            'chapters' => $chapters,
            'paylog' => $paylog,
        ];
    }
    
    /**
     * 用户购买章节扣除书币
     * @param int $user_id 用户ID
     * @param int $book_coin 要扣除的书币
     */
    public function deductions($user_id = 0, $book_coin = 0) {
        $sql = "UPDATE novel_user_account SET book_coin = book_coin - {$book_coin} WHERE user_id = {$user_id}";
        $this->db->execute($sql);
    }
    
    /**
     * 记录章节消费记录
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param int $book_coin 消耗的书币
     */
    public function tradeRecord($user_id = 0, $book_id = 0, $book_coin = 0) {
        $sql = "SELECT id FROM novel_trade_record WHERE user_id = {$user_id} AND book_id = {$book_id} LIMIT 1";
        $query = $this->db->fetchRow($sql);
        if (!empty($query)) {
            $sql = "UPDATE novel_trade_record SET trade_coin = trade_coin + {$book_coin}, create_at = " . __TIME__ . " "
                    . "WHERE user_id = {$user_id} AND book_id = {$book_id}";
            $this->db->execute($sql);
        } else {
            $insertData = [
                'user_id' => $user_id,
                'book_id' => $book_id,
                'trade_coin' => $book_coin,
                'create_at' => __TIME__,
            ];
            $this->db->insert('novel_trade_record', $insertData);
        }
    }
    
    /**
     * 读取已付费章节
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     */
    public function getBuyChapterRecord($user_id, $book_id) {
        $key = 'pay_chapter';
        $haystack = $this->redis->hExists($key, "{$user_id}_{$book_id}") ? $this->redis->hGet($key, "{$user_id}_{$book_id}") : [];
        return $haystack; 
    }
    
    /**
     * 查看用户是否对该章节付费
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param int $chapter_id 章节ID
     */
    public function isUserPayChapter($user_id = 0, $book_id = 0, $chapter_id = 0) {
        $cachePayBook = $this->getBuyChapterRecord($user_id, $book_id);
        $isbuy = !in_array($chapter_id, $cachePayBook) ? 0 : 1;
        return $isbuy;
    }
    
    /**
     * 查看用户是否对该章节付费
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     * @param array $chapters 已购买的章节数据
     */
    public function updatePayChapter($user_id = 0, $book_id = 0, $chapters = []) {
        $payChapters = $this->getBuyChapterRecord($user_id, $book_id);
        $records = array_unique(array_merge($payChapters, $chapters));
        $this->redis->hSet('pay_chapter', "{$user_id}_{$book_id}", $records);
    }
    
    /**
     * 根据订单号查询订单信息
     * @param string $orderId 订单号
     */
    public function getOrderInfo($orderId = '') {
        $sql = "SELECT user_id, pay_amt, pay_coin, order_st, channel, book_id, extend_id FROM `novel_pay_record` WHERE order_id = '{$orderId}' LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 更新用户的书币
     * @param int $user_id 用户ID
     * @param int $book_coin 要更新的书币
     */
    public function updateUserCoin($user_id = 0, $book_coin = 0) {
        $query = $this->db->fetchRow("SELECT user_id FROM novel_user_account WHERE user_id = {$user_id} LIMIT 1");
        if (!empty($query)) {
            $sql = "UPDATE novel_user_account SET book_coin = book_coin + {$book_coin} WHERE user_id = {$user_id}";
            $this->db->execute($sql);
        } else {
            $insertData = [
                'user_id' => $user_id,
                'book_coin' => $book_coin,
            ];
            $this->db->insert('novel_user_account', $insertData);
        }
    }
    
    /**
     * 章节书币消耗记录
     * @param int $book_id 书ID
     * @param int $chapter_id 章节ID
     * @param int $book_coin 消耗的书币数
     */
    public function chapterExpend($book_id = 0, $chapter_id = 0, $book_coin = 0) {
        if (!empty($book_id) && !empty($chapter_id) && $book_coin > 0) {
            $this->redis->hincrby("chapter_expend_{$book_id}", $chapter_id, $book_coin);
        }
    }
    
}