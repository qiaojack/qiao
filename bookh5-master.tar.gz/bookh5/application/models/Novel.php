<?php

/**
 * H5小说数据模型
 */

class NovelModel extends ApplicationModel {
    
    public function __construct() {
        $this->db = Db\Mysql::getInstance();
        $this->redis = Db\Redis::getInstance();
    }
    
    /**
     * 获取完整的书籍信息
     * @param int $book_id 小说ID
     */
    public function getFullBookInfo($book_id = 0) {
        $sql = "SELECT a.book_id, a.name, a.cate_id, b.cate_name, a.author, a.intro, a.cover, a.size, a.`status`, a.charge_type "
                . "FROM novel_list a, novel_category b, novel_chapter c WHERE a.book_id = {$book_id} "
                . "AND a.cate_id = b.cate_id AND a.book_id = c.book_id AND `site` = 2 AND `status` > -1 LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 获取书籍基础信息
     * @param int $book_id 小说ID
     */
    public function getBookInfoById($book_id = 0) {
        $sql = "SELECT book_id, `name`, cate_id, author, intro, cover, `size`, `status`, charge_type "
                . "FROM novel_list WHERE book_id = {$book_id} AND `site` = 2 AND `status` > -1 LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 根据小说ID读取章节数据
     * @param int $book_id 小说ID
     */
    public function getChapterInfo($book_id = 0) {
        $sql = "SELECT book_id, `count`, uptime FROM novel_chapter WHERE book_id = {$book_id} LIMIT 1";
        return $this->db->fetchRow($sql);
    }
    
    /**
     * 通过指定参数获取章节数据
     * @param int $book_id 书籍ID
     * @param string|int $index 文件名
     */
    public function readChapter($book_id = 0, $index = '1') {
        $cacheKey = "content_{$book_id}";
        $body = $this->redis->hget($cacheKey, $index);
        if (empty($body)) {
            $serverAddr = @$_SERVER['SERVER_ADDR'];
            if ($serverAddr == '221.195.1.253') {
                $apipath = "http://192.168.1.107:17331/app/read/index?book_id={$book_id}&index={$index}";
                $httpClient = new HttpClient($apipath, 'GET');
                $httpClient->exec();
                $response = $httpClient->getResponseBody();
                $jsonInfo = !empty($response) ? json_decode($response, true) : [];
                $body = isset($jsonInfo['info']) ? $jsonInfo['info'] : '';
            } else {
                $filepath = _BOOK_CONTENT__."/book/{$book_id}/{$index}.txt";
                $content = file_exists($filepath) ? fileGetContents($filepath) : '';
                $body = (!empty($content) && $index == 'list') ? json_decode($content, true) : $content;
            }
            $this->redis->hset($cacheKey, $index, $body);
            if ($this->redis->hlen($cacheKey) == 1) {
                $this->redis->expire($cacheKey, 2 * 3600);
            }
        }
        return $body;
    }
    
    /**
     * 根据书名获取全部源站的数据
     * @param string $book_name 书名
     */
    public function getCatalogList($book_name = '') {
        $sql = "SELECT id, `tag`, `name`, author, path FROM novel_catalog WHERE `name` = '{$book_name}'";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 根据ID获取分类数据
     * @param array $conditions 条件
     * @param int $offset 起始index
     * @param int $length 数量
     * @return array
     */
    public function getCateListById($conditions = array(), $offset = 0, $length = 10) {
        $where = array();
        if (isset($conditions['cate_id'])) {
            if (is_array($conditions['cate_id'])) {
                array_push($where, "cate_id In (" . join(',', $conditions['cate_id']) . ")");
            } else {
                array_push($where, "cate_id = " . $conditions['cate_id']);
            }
        }
        if (isset($conditions['book_id'])) {
            array_push($where, "book_id IN (" . $conditions['book_id'] . ")");
        }
        if (isset($conditions['status'])) {
            array_push($where, "status = " . $conditions['status']);
        } else {
            array_push($where, "status >= 0 ");
        }
        if (isset($conditions['size'])) {
            if ($conditions['size'] == 1) {
                array_push($where, "size < 200000");
            } elseif ($conditions['size'] == 2) {
                array_push($where, "size >= 200000");
                array_push($where, "size < 1000000");
            } elseif ($conditions['size'] == 3) {
                array_push($where, "size >= 1000000");
            }
        }

        $where = implode(" AND ", $where);
        $sql = "SELECT book_id, `name`, `author`, `intro`, `cover`, `status`, `size` FROM novel_list "
                . "WHERE {$where} AND `site` = 2 ORDER BY book_id ASC LIMIT {$offset},{$length}";
        return $this->db->fetchAll($sql);
    }

    //读取小说分类
    public function getCategoryList() {
        $sql = "SELECT cate_id, cate_name, cate_pid FROM novel_category WHERE cate_pid >= 0 AND cate_status = 1 ORDER BY cate_sort DESC";
        return $this->db->fetchAll($sql);
    }

    //根据id获取相应子分类
    public function getCateList($cate_id) {
        $sql = "SELECT cate_id, cate_name,cate_pid FROM novel_category WHERE cate_pid = {$cate_id}  AND cate_status = 1 ORDER BY cate_sort DESC";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 获取幻灯片
     * @param int $type 类型
     * @param int $length 数量
     */
    public function carouselSlide($type = 1, $length = 3) {
        $sql = "SELECT image, url FROM novel_slide WHERE `status` = 1 AND `pos` = {$type} ORDER BY list_order DESC LIMIT {$length}";
        $slideList = $this->db->fetchAll($sql);
        if (!empty($slideList)) {
            foreach ($slideList as $key => $value) {
                $slideList[$key]['image'] = __STATIC_URL__ . $value['image'];
            }
        }
        return $slideList;
    }
    
    /**
     * 获取首页幻灯片
     * @param int $type 类型
     * @param int $length 数量
     */
    public function indexSlide($length = 3) {
        $sql = "SELECT image, url FROM novel_slide WHERE `type` = 1 AND `pos` = 1 AND `status` = 1 ORDER BY list_order DESC LIMIT {$length}";
        $slideList = $this->db->fetchAll($sql);
        if (!empty($slideList)) {
            foreach ($slideList as $key => $value) {
                $slideList[$key]['image'] = __STATIC_URL__ . $value['image'];
            }
        }
        return $slideList;
    }
    
    /**
     * 推荐的书籍
     * @param int $type_id 推荐类型
     * @param int $offset 偏移量
     * @param int $length 长度
     */
    public function getData($type_id = 1, $offset = 0, $length = 10) {
        $sql = "SELECT book_id FROM novel_operate WHERE type_id = {$type_id} ORDER BY list_order DESC LIMIT {$offset},{$length}";

        return $this->db->fetchAll($sql);
    }
    
    /**
     * 统计书籍浏览热度
     * @param int $book_id 书籍ID
     */
    public function updateUserLike($book_id = 0) {
        $this->redis->zincrby('book_userlike', 1, $book_id);
    }
    
    /**
     * 更新书籍的浏览次数
     * @param int $book_id 书籍ID
     */
    public function updateReadBook($book_id = 0) {
        $this->redis->hincrby('readbook', $book_id, 1);
    }
    
    /**
     * 更新章节的浏览次数
     * @param int $book_id 书籍ID
     * @param int $index 章节index
     */
    public function updateReadChapter($book_id = 0, $index = 1) {
        $this->redis->hincrby("readchapter_{$book_id}", $index, 1);
    }
    
    /**
     * 读取大家都在看数据
     * @param int $offset 起始index
     * @param int $length 获取条数
     */
    public function getLikeBook($offset = 0, $length = 5) {
        $start = $offset * $length;
        $stop = ($offset + 1) * $length - 1;
        return $this->redis->zrevrange('book_userlike', $start, $stop);
    }
    
    /**
     * 根据来源类型获取数据
     * @param int $site 来源类型
     */
    public function getbookBySite($site = 2) {
        $sql = "SELECT book_id FROM novel_list WHERE `site` = {$site}";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * 读取限时免费的书籍数据
     * @param tinyint $limit_type 限时类型
     */
    public function getTimelimitData($limit_type = 0) {
        $cacheKey = 'book_timelimit_' . $limit_type;
        $timeData = $this->redis->get($cacheKey);
        if (empty($timeData)) {
            $sql = "SELECT book_id, limit_type, timeout FROM novel_timelimit WHERE `limit_type` = {$limit_type} ORDER BY `timeout` ASC";
            $timeData = $this->db->fetchAll($sql);
            if (!empty($timeData)) {
                $this->redis->setex($cacheKey, 3600, $timeData);
            }
        }
        return $timeData;
    }
    
    /**
     * 获取限时免费的书籍
     * @param int $book_id 书ID
     */
    public function getTimelimitBook($book_id = 0) {
        $cacheKey = 'book_timelimit';
        $query = $this->redis->hget($cacheKey, $book_id);
        if (empty($query)) {
            $sql = "SELECT book_id, limit_type, timeout FROM novel_timelimit WHERE `book_id` = {$book_id}";
            $query = $this->db->fetchRow($sql);
            if (!empty($query)) {
                $this->redis->hset($cacheKey, $book_id, $query);
                $this->redis->expire($cacheKey, 86400); //缓存1天
            }
        }
        $isFree = (!empty($query) && (int)$query['timeout'] > __TIME__) ? true : false;
        return $isFree;
    }
    
    /**
     * 判断章节是否vip收费
     * @param int $book_id 书ID
     * @param int $index 章节ID
     */
    public function isChapterVip($book_id = 0, $index = 1) {
        $isVip = false;
        $chapterList = $this->readChapter($book_id, 'list');
        if (!empty($chapterList)) {
            if ($index > 0) {
                $data = isset($chapterList[$index - 1]) ? $chapterList[$index - 1] : [];
                $isVip = !empty($data) ? (isset($data['isvip']) ? $data['isvip'] : false) : false;
            }
        }
        return $isVip;
    }
}