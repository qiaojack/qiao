<?php

/**
 * 首页书城
 */
class IndexController extends BaseController {
    
    private $_novelModel, $_userModel;
    
    public function init(){
        parent::init();
        $this->_userModel = UserModel::getInstance();
        $this->_novelModel = NovelModel::getInstance();
    }
    
    //书城首页
    public function indexAction() {
        $request = $this->getRequest()->getQuery();
        $type = isset($request['type']) ? (int)$request['type'] : 0;
        $page = isset($request['page']) ? (int)$request['page'] : 1;
        $length = isset($request['length']) ? (int)$request['length'] : 4;
        $shuffle = isset($request['shuffle']) ? (int)$request['shuffle'] : 0;
        
        if (!empty($type)) {
            $records = $this->getConfData($type, $page, $length, $shuffle);
            $assign = array(
                'code' => 200,
                'rows' => $records,
            );
            echo $this->stringifyJSON($assign);
            exit;
        }
        
        $userInfo = $this->getLoginUser();
        $user_id = isset($userInfo['user_id']) ? $userInfo['user_id'] : 0;
        $readlog = $this->_userModel->getUserRead($user_id, 0, 1); //阅读记录
        
        //公众号二维码
        $domain = $_SERVER['HTTP_HOST'];
        $sysMpConf = $this->_userModel->getSysMpConf($domain);
        $mpqrcode = isset($sysMpConf['mp_qrcode']) ? __STATIC_URL__ . $sysMpConf['mp_qrcode'] : '';
        
        $assign = array(
            'slide' => $this->_novelModel->indexSlide(4), //幻灯片
            'host' => $this->getConfData(101, 1, 4), //本周推荐
            'boy' => $this->getConfData(106, 1, 6), //男生精品
            'girl' => $this->getConfData(110, 1, 6), //女生精品
            'limit' => $this->timelimit(0, 0, 4), //限时免费
            'end' => $this->getConfData(104, 1, 5), //完结热推
            'new' => $this->getConfData(102, 1, 4), //人气新书
            'like' => $this->getBookLike(0, 5), //大家都在看
            'user' => [
                'isLogin' => !empty($userInfo) ? 1 : 0,
                'nickname' => isset($userInfo['nickname']) ? $userInfo['nickname'] : '',
                'headimg' => isset($userInfo['avatar']) ? $userInfo['avatar'] : '',
            ],
            'readlog' => $readlog,
            'mpqrcode' => $mpqrcode,
        );
        $this->display('index', $assign);
    }
    
    /**
     * 限时免费书籍
     * @param int $limit_type 限时类型
     * @param int $offset 偏移量
     * @param int $length 展示数量
     */
    private function timelimit($limit_type = 0, $offset = 0, $length = 4) {
        $recordList = [];
        $query = $this->_novelModel->getTimelimitData($limit_type);
        if (!empty($query)) {
            foreach ($query as $key => $value) {
                $bookInfo = !empty($value['book_id']) ? $this->getBookInfo($value['book_id']) : [];
                if (!empty($bookInfo) && $value['timeout'] > __TIME__) {
                    $recordList['book'][] = array(
                        'book_id' => (int)$bookInfo['book_id'],
                        'name' => $bookInfo['name'],
                        'author' => $bookInfo['author'],
                        'cover' => $bookInfo['cover'],
                    );
                    if ($key == count($query) - 1) {
                        $recordList['timeout'] = (int)$value['timeout'] - __TIME__;
                    }
                }
            }
            $recordList = array_slice($recordList, $offset, $length);
        }
        return $recordList;
    }
    
    //大家都在看
    public function allLikeAction() {
        $request = $this->getRequest()->getQuery();
        $page = isset($request['page']) ? (int) $request['page'] : 1;
        $length = isset($request['length']) ? (int) $request['length'] : 5;
        $offset = ($page - 1 > 0) ? $page - 1 : 0;
        
        //获取数据
        $records = $this->getBookLike($offset, $length);
        
        $assign = ['code' => 200, 'rows' => $records];
        echo $this->stringifyJSON($assign);
        exit;
    }
    
    /**
     * 读取大家都在看数据
     * @param int $offset 起始偏移量
     * @param int $length 长度
     */
    private function getBookLike($offset = 0, $length = 5) {
        $records = [];
        $result = $this->_novelModel->getLikeBook($offset, $length);
        foreach ($result as $book_id) {
            $bookInfo = !empty($book_id) ? $this->getBookInfo($book_id) : [];
            if (!empty($bookInfo) && !empty($bookInfo['cover'])) {
                $records[] = array(
                    'book_id' => (int)$bookInfo['book_id'],
                    'name' => $bookInfo['name'],
                    'author' => $bookInfo['author'],
                    'cover' => $bookInfo['cover'],
                    'intro' => $bookInfo['intro'],
                    'cate_name' => $bookInfo['cate_name'],
                    'status' => (int)$bookInfo['status'],
                );
            }
        }
        return $records;
    }
    
    //获得app版本
    public function versionAction() {
        $assign = array(
            'code' => 200,
            'rows' => [
                'android' => '',//'http://static.jiuwei.com/apk/jiuwei-local-1.0.7.apk',
                'ios' => '',
            ]
        );
        echo $this->stringifyJSON($assign);
        exit;
    }
}