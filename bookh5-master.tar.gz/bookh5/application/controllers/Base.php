<?php

/* 
 * H5控制器基类
 */
class BaseController extends ApplicationController {
    
    private $_userModel, $_novelModel, $_redis;
    protected $layout = 'frontend';
    
    public function init() {
        parent::init();
        $this->_novelModel = NovelModel::getInstance();
        $this->_userModel = UserModel::getInstance();
        $this->_redis = Db\Redis::getInstance();
    }
    
    /**
     * 读取书的详细信息
     * @param int $book_id 书ID
     */
    public function getBookInfo($book_id = 0) {
        if (!$this->_redis->hexists('book_list', $book_id)) {
            $bookInfo = $this->cacheBook($book_id);
        } else {
            $bookInfo = $this->_redis->hget('book_list', $book_id);
        }
        return $bookInfo;
    }
    
    /**
     * 缓存书籍的数据
     * @param ing $book_id 书ID
     */
    public function cacheBook($book_id = 0) {
        $bookInfo = $this->_novelModel->getFullBookInfo($book_id);
        if (!empty($bookInfo)) {
            $query = $this->_novelModel->getChapterInfo($book_id);
            $chapters = !empty($query) ? $this->_novelModel->readChapter($book_id, 'list') : [];
            $lastChild = !empty($chapters) ? array_slice($chapters, -1, 1)[0] : ['name' => '', 'index' => 0];
            $firstChild = !empty($chapters) ? array_slice($chapters, 0, 1)[0] : ['name' => '', 'index' => 0];
            
            $bookInfo = array(
                'book_id' => (int)$book_id,
                'name' => $bookInfo['name'],
                'cate_id' => isset($bookInfo['cate_id']) ? (int)$bookInfo['cate_id'] : 3,
                'cate_name' => $bookInfo['cate_name'],
                'author' => $bookInfo['author'],
                'intro' => formatContent($bookInfo['intro']),
                'cover' => !empty($bookInfo['cover']) ? __STATIC_URL__ . $bookInfo['cover'] : '',
                'size' => (int)number_format($bookInfo['size'] / 10000, 2),
                'status' => $bookInfo['status'],
                'count' => count($chapters),
                'first_index' => $firstChild['index'],
                'last_name' => $lastChild['name'],
                'last_index' => $lastChild['index'],
                'last_uptime' => (int)$query['uptime'],
                'charge_type' => (int)$bookInfo['charge_type'],
            );
            $this->_redis->hset('book_list', $book_id, $bookInfo);
        }
        return $bookInfo;
    }
    
    /**
     * 接口返回JSON字符串
     * @param array $data 返回的数组
     * @param boolean $gzip 是否压缩数据
     */
    public function stringifyJSON($data = array(), $gzip = false) {
        $assign = json_encode($data, JSON_UNESCAPED_UNICODE);
        
        //是否压缩json数据
        if ($gzip) {
            $assign = gzdeflate($assign);
        }
        return $assign;
    }
    
    /**
     * 根据token获取用户书架缓存数据
     * @param int $user_id 用户ID
     * @param boolean $reset 是否重置数据
     */
    public function getBookshelf($user_id = 0, $reset = false) {
        $bookshelf = [];
        if ((!empty($user_id) && !$this->_redis->hexists('h5_bookshelf', $user_id) || $reset)) {
            $bookshelf = $this->_userModel->getBookshelf($user_id);
            $this->_redis->hset('h5_bookshelf', $user_id, $bookshelf);
        } else {
            $bookshelf = $this->_redis->hget('h5_bookshelf', $user_id);
        }
        return $bookshelf;
    }
    
    /**
     * 是否已加入书架
     * @param int $user_id 用户ID
     * @param int $book_id 书ID
     */
    public function isHaveBook($user_id = 0, $book_id = 0) {
        $bookshelf = $this->getBookshelf($user_id);
        $haystack = !empty($bookshelf) ? array_column($bookshelf, 'book_id') : [];
        $haveBook = in_array($book_id, $haystack) ? 1 : 0;
        return $haveBook;
    }
    
    /**
     * 读取登录用户缓存数据
     * @param string $channel 来源渠道
     * @param string $openId 用户唯一ID
     */
    public function getLoginUser($channel = '', $openId = '') {
        $channel = !empty($channel) ? $channel : (isset($_COOKIE['channel']) ? $_COOKIE['channel'] : '');
        $openId = !empty($openId) ? $openId : (isset($_COOKIE['openId']) ? $_COOKIE['openId'] : '');
        $redisKey = "{$channel}_$openId";
        $userInfo = $this->_redis->get($redisKey);
        
        //记录活跃用户
        $this->activeLoginUser($channel, $openId);
        
        return $userInfo;
    }
    
    /**
     * 设置用户登录
     * @param array $userInfo 用户数组
     * @param string $domain cookie域
     */
    public function settingLogin($userInfo = [],  $domain = '') {
        $channel = $userInfo['channel'];
        $openId = $userInfo['openid'];
        $seconds = 30 * 86400;
        $expire_time = __TIME__ + $seconds; //过期时间30天
        
        //userToken存储至Redis
        $redisKey = "{$channel}_{$openId}";
        $hasToken = $this->_redis->exists($redisKey);
        if (empty($hasToken) && (!empty($channel) && !empty($openId))) {
            $this->_redis->setex($redisKey, $seconds, $userInfo);
        }
        
        //向用户客户端发送openid和channel
        if (!empty($openId)) {
            setcookie('openId', $openId, $expire_time, '/', $domain);
            setcookie('channel', $channel, $expire_time, '/', $domain);
        }
        
        return $openId;
    }
    
    /**
     * 推荐书籍
     * @param int $type_id 推荐类型
     * @param int $page 页码
     * @param int $length 展示数量
     * @param int $shuffle 是否打散数据
     */
    public function getConfData($type_id = 1, $page = 1, $length = 4, $shuffle = 0) {
        $offset = ($page - 1) * $length;
        $redisKey = "bookdata_conf_{$type_id}";
        $recordList = $this->_redis->get($redisKey);
        if (empty($recordList)) {
            $recordList = $this->_novelModel->getData($type_id, $offset, 50);
            if (!empty($recordList)) {
                foreach ($recordList as $key => $value) {
                    $bookInfo = !empty($value['book_id']) ? $this->getBookInfo($value['book_id']) : [];
                    if (!empty($bookInfo) && !empty($bookInfo['book_id']) && !empty($bookInfo['name'])) {
                        $recordList[$key] = array(
                            'book_id' => (int)$bookInfo['book_id'],
                            'name' => $bookInfo['name'],
                            'author' => $bookInfo['author'],
                            'cover' => $bookInfo['cover'],
                            'intro' => $bookInfo['intro'],
                            'cate_name' => $bookInfo['cate_name'],
                            'status' => (int)$bookInfo['status'],
                        );
                    }
                }
                $this->_redis->setex($redisKey, 3600, $recordList); //缓存1小时
            }
        }
        if (!empty($recordList)) {
            if ($shuffle) {
                shuffle($recordList);
            }
            $recordList = array_slice($recordList, 0, $length);
        }
        return $recordList;
    }
    
    /**
     * 充值赠送书币
     * @param int $price 充值金额
     */
    public function giveBookCoins($price = 0) {
        $record = array(
//            ['price' => 1, 'coin' => 100, 'give' => 100],
//            ['price' => 10, 'coin' => 1000, 'give' => 0],
            ['price' => 30, 'coin' => 3000, 'give' => 150],
            ['price' => 50, 'coin' => 5000, 'give' => 500],
            ['price' => 100, 'coin' => 10000, 'give' => 1500],
            ['price' => 200, 'coin' => 20000, 'give' => 0],
            ['price' => 500, 'coin' => 50000, 'give' => 0],
        );
        
        if (!empty($price)) {
            $priceKey = array_keys(array_column($record, 'price'), $price);
            $index = !empty($priceKey) ? $priceKey[0] : -1;
            $givenum = isset($record[$index]) ? $record[$index]['give'] : 0;
            return $givenum;
        } else {
            return $record;
        }
    }
    
    //记录活跃用户
    public function activeLoginUser($channel, $openid) {
        if (!empty($channel) && !empty($openid)) {
            $redisKey = "active_user_{$channel}";
            $length = $this->_redis->llen($redisKey);
            $openlist = $this->_redis->lrange($redisKey, 0, $length);
            if (!in_array($openid, $openlist)) {
                $this->_redis->lpush($redisKey, $openid);
                $this->_redis->expire($redisKey, 2 * 86400);
            }
        }
    }
}