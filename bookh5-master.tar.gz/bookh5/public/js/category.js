$(function() {
    
    $('.category-list li').on('click', function() {
        var cate_id = $(this).attr('cateid');
        window.location.href = '/h5/category/bookdata?cate_id=' + cate_id;
    });
    
    var page = 1;
    var getMoreData = function(cate_id, book_size, book_st, append) {
        var append = append || false;
        var params = {cate_id: cate_id, book_size: book_size, st: book_st, page: page, length: 10, r: 1};
        $.getJSON('/h5/category/bookdata', params, function (data) {
            if (data.code == 200) {
                var interText = doT.template($("#tmpl-bookdata").text());
                if (!append) {
                    $("#category_bookdata").html(interText(data.rows));
                } else {
                    $("#category_bookdata").append(interText(data.rows));
                }
                if (data.rows.length) {
                    $('#nomoredata').hide();
                    $('#loadbookmore').show().children().text('查看更多');
                } else {
                    $('#loadbookmore').hide();
                    $('#nomoredata').show();
                }
            }
        });
    };
    
    //点击子分类筛选
    $('#bookChildOpt a').on('click', function() {
        var cate_id = $(this).attr('item');
        $('#cate_id').val(cate_id);
        var book_size = $('#book_size').val();
        var book_st = $('#book_st').val();
        if (cate_id == 0) {
            cate_id = $("#fid").val();
        }
        $('#bookChildOpt a').removeClass('selected');
        $(this).addClass('selected');
        getMoreData(cate_id, book_size, book_st);
    });
    
    //点击字数筛选
    $('#bookSizeOpt a').on('click', function() {
        var optid = $(this).attr('item');
        $("#book_size").val(optid);
        var cate_id = $('#cate_id').val();
        var book_st = $('#book_st').val();
        if (cate_id == 0) {
            cate_id = $("#fid").val();
        }
        $('#bookSizeOpt a').removeClass('selected');
        $(this).addClass('selected');
        getMoreData(cate_id, optid, book_st);
    });
    
    //点击状态筛选
    $('#bookStatusOpt a').on('click', function() {
        var cate_id = $('#cate_id').val();
        var book_size = $('#book_size').val();
        var book_st = $(this).attr('item');
        $("#book_st").val(book_st);
        if (cate_id == 0) {
            cate_id = $("#fid").val();
        }
        $('#bookStatusOpt a').removeClass('selected');
        $(this).addClass('selected');
        getMoreData(cate_id, book_size, book_st);
    });
    
    $('#loadbookmore').on('click', function() {
        $(this).children().text('数据加载中...');
        var cate_id = $('#cate_id').val();
        var book_size = $('#book_size').val();
        var book_st = $('#book_st').val();
        if (cate_id == 0) {
            cate_id = $("#fid").val();
        }
        page++;
        getMoreData(cate_id, book_size, book_st, true);
    });
});