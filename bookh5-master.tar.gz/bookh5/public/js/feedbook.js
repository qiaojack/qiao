$(function() {
    
    //点击提交反馈报错
    $('#feedbooksubmit').on('click', function() {
        var obj = this;
        var desc = $("#desc").val() || '';
        if (!desc.length) {
            $(document).dialog({type: 'notice', infoText: "请描述一下您遇到的问题", autoClose: 2500, position: 'center'});
            return;
        }
        var contact = $("#contact").val() || '';
        if (!contact.length) {
            $(document).dialog({type: 'notice', infoText: "留下您的联系方式我们第一时间为您解决", autoClose: 2500, position: 'center'});
            return;
        }
        var params = {
            book_id: $('#book_id').val(),
            chapter: $('#chapter_id').val(),
            type: $('input[type=radio]:checked').val() || 1,
            desc: desc,
            contact: contact
        };
        $.post('/h5/read/feedbook', params, function(data) {
            if (data.code == 200) {
                $("#desc,#contact").val('');
                $(document).dialog({type: 'notice', infoText: "您的反馈已提交成功", autoClose: 2500, position: 'center'});
                history.go(-1);
            }
        }, 'json');
    });
});

