$(function () {
    //判断是否微信浏览器
    var ua = window.navigator.userAgent.toLowerCase();
    var isWeiXin = (ua.match(/MicroMessenger/i) == 'micromessenger') ? true : false;
    var requestUrl = location.origin;

    function getCookie(name) {
        var name = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ')
                c = c.substring(1);
            if (c.indexOf(name) != -1)
                return c.substring(name.length, c.length);
        }
        return '';
    }

    function getQueryString(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }

    var openId = getCookie('openId');
    var channel = getCookie('channel');
//    console.log(openId + '====' + channel);
    if (isWeiXin && (!openId.length || !channel.length)) {
        var code = getQueryString("code");
//        console.log('code:' + code);
        if (code !== null && code.length) {
            $.ajax({
                url: requestUrl + "/h5/login/wechat",
                data: {code: code},
                dataType: "json",
                success: function (res) {
                }
            });
        } else {
            var jump = encodeURIComponent(location.href);
            window.location.href = requestUrl + '/h5/login/auto?t=wechat&u=' + jump;
        }
    }
});