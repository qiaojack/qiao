$(function() {
    
    //短信验证码倒计时
    var smsCountDown = function() {
        var _time = 60;
        var auto = setInterval(function() {
            if (_time) {
                _time--;
                $(".sendcode").text('倒计时(' + _time + '秒)');
            } else {
                clearInterval(auto);
                $(".sendcode").text(60);
            }
        }, 1e3);
    };
    
    //短信验证码
    $(".sendcode").on("click", function() {
        var mobile = $("#mobile").val();
        if (mobile.length != 11) {
            $(document).dialog({type: 'notice', infoText: "请正确输入手机号", autoClose: 2500, position: 'center'});
            $("#mobile").focus();
            return;
        }
        $.ajax({
            type: "POST",
            url: "/h5/login/smsCode",
            data: {mobile: mobile},
            dataType: "json",
            success: function(data) {
                if (data.code == 'OK') {
                    smsCountDown(); //倒计时
                    $(document).dialog({type: 'notice', infoText: "验证码发送成功", autoClose: 2500, position: 'center'});
                } else {
                    $(document).dialog({type: 'notice', infoText: "验证码发送失败", autoClose: 2500, position: 'center'});
                }
            }
        });
    });
    
    //点击登录
    $('#login-btn').on('click', function() {
        var jump = $("#jump").val();
        var mobile = $("#mobile").val();
        var verifycode = $("#verifycode").val();
        if (mobile == '') {
            $(document).dialog({type: 'notice', infoText: "请正确输入手机号", autoClose: 2500, position: 'center'});
            $("#mobile").focus();
            return;
        }
        if (verifycode == '') {
            $(document).dialog({type: 'notice', infoText: "请正确输入验证码", autoClose: 2500, position: 'center'});
            $("#verifycode").focus();
            return;
        }
        
        $.ajax({
            type: "post",
            data: {mobile: mobile, verifycode: verifycode},
            url: '/h5/login/mobile',
            dataType: "json",
            success: function(data) {
                if (data.code == 101) {
                    $(document).dialog({type: 'notice', infoText: "参数错误", autoClose: 2500, position: 'center'});
                } else if (data.code == 102) {
                    $(document).dialog({type: 'notice', infoText: "验证码有误", autoClose: 2500, position: 'center'});
                } else if (data.code == 200) {
                    if (jump) {
                        window.location.href = jump;
                    } else {
                        window.location.href = '/';
                    }
                }
            }
        });
    });
    
    //点击微信登录
    $('.login-weixin').on('click', function() {
        var jump = encodeURIComponent($('#jump').val());
        var redirect = "/h5/login/auto?t=wechat&u=" + jump;
        window.location.href = redirect;
    });
    
    //点击QQ登录
    $('.login-qq').on('click', function() {
        var jump = encodeURIComponent($('#jump').val());
        var redirect = "/h5/login/auto?t=qq&u=" + jump;
        window.location.href = redirect;
    });
    
});

