$(function() {
    
    document.title = $('.top').text() || '钱塘看书_正版_原创_网络小说_原创网文_好看的小说尽在其中';
    
    //设置自动购买
    var checkval = Store.isset('setting_autopay') ? Store.fetch('setting_autopay') : 1;
    $(".checkbox-label").click(function() {
        checkval = (checkval == 1) ? 0 : 1;
        Store.store('setting_autopay', checkval);
    });
    if (checkval) {
        $("#checkbox-2").attr("checked", "");
    } else {
        $("#checkbox-2").removeAttr("checked");
    }
    
});


