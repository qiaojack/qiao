$(function() {
    
    //幻灯片
    new Swiper('.slider-banner>.swiper-container', {
        pagination: ".swiper-pagination",
        paginationClickable: true,
        centeredSlides: true,
        autoplay: 2500,
        touchRatio: 0.5,  
        longSwipesRatio: 0.1,  
        threshold: 50,
        observer: true,
    });
    
    //人气新书换一换
    $('#change_endrt').on("click", function() {
        $.getJSON('/h5/area/boy', {type: 108, page: 1, length: 8, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var endrt = data.rows.slice(0, 4);
                var interText = doT.template($("#tmpl-boyqzone-1").text());
                $("#endrt_1").html(interText(endrt));
                
                endrt = data.rows.slice(4, 8);
                interText = doT.template($("#tmpl-boyqzone-2").text());
                $("#endrt_2").html(interText(endrt));
            }
        });
    });
    
});

