$(function() {
    
    //充值选项选择
    $('.rs-list li').on('click', function() {
        $('.rs-list li').removeClass('active');
        $(this).addClass('active');
    });
    
    //微信支付
    function wechatpay() {
        var appid = $('#appid').val();
        var bkey = $('.active').find('input').attr('bkey');
        var redirect_uri = "https://jw21.jiuwei.com/h5/pay/wechat/?bkey=" + bkey;
        window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + appid + "&redirect_uri=" + redirect_uri + "&response_type=code&scope=snsapi_userinfo&state=#wechat_redirect";
    }
    
    //爱贝支付
    function aibeipay() {
        var bkey = $('.active').find('input').attr('bkey');
        $.ajax({
            type: "get",
            url: "/h5/jump",
            data: {bkey: bkey},
            dataType: 'json',
            success: function(data) {
                if (data.code == 200) {
                    if (data.rows.orderid != '') {
                        window.location.href = data.rows.payjumpurl;
                    } else {
                        $(document).dialog({type: 'notice', infoText: "订单生成失败，请重试！", autoClose: 2500, position: 'center'});
                    }
                } else if (data.code == 201) {
                    $(document).dialog({type: 'notice', infoText: "您尚未登录，请登录后再充值！", autoClose: 2500, position: 'center'});
                }
                $('.recharge-submit>input').attr('disabled', false).removeClass('disabled').addClass('defclk');
            }
        });
    }
    
    //点击确认支付
    $('.recharge-submit').on('click', function() {
        //确认按钮置灰为不可用
        $('.recharge-submit>input').attr('disabled', true).removeClass('defclk').addClass('disabled');
        
        var ua = window.navigator.userAgent.toLowerCase();
        var isWeiXin = (ua.match(/MicroMessenger/i) == 'micromessenger') ? true : false;
        if (isWeiXin) {
            wechatpay(); //公众号微信支付
        } else {
            aibeipay(); //爱贝H5支付
        }
    });
    
});


