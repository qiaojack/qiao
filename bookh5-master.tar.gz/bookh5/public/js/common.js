
document.title = $('.toptxt').text() || '钱塘看书_正版_原创_网络小说_原创网文_好看的小说尽在其中';

//跳转到详情页
function jumpDetail(book_id) {
    location.href = '/h5/detail?book_id=' + book_id;
}

//跳转到内容页
function jumpContent(book_id, chapter_id) {
    location.href = '/h5/read/content?book_id=' + book_id + '&chapter_id=' + chapter_id;
}

//返回上一页
$('.topback,.i-return').on('click', function() {
    window.history.go(-1);
});

//图片懒加载
if (typeof echo !== 'undefined') {
    echo.init({
        offset: 100,
        throttle: 0,
        unload: false
    });
}

//返回顶部
var back_to_top = $('.scrollTop');
if (back_to_top) {
    var offset = 200, offset_opacity = 1200, scroll_top_duration = 100;
    $(window).on('scroll', function() {
        back_to_top.show();
        ($(this).scrollTop() > offset) ? back_to_top.addClass('cd-is-visible') : back_to_top.removeClass('cd-is-visible cd-fade-out');
        if ($(this).scrollTop() > offset_opacity) {
            back_to_top.addClass('cd-fade-out');
        }
    });
    back_to_top.on('click', function() {
        document.documentElement.scrollTop = document.body.scrollTop = 0;
    });
}

//组装URL参数
function buildQuery(param) {
    var paramArray = [], str = "";
    for (var key in param) {
        paramArray.push(key);
    }
    paramArray.sort();
    for (var i = 0; i < paramArray.length; i ++) {
        str += "&" + paramArray[i] + "=" + param[paramArray[i]];
    }
    str = str.substring(1);
    return str;
}

//设置cookie
function setCookie(name, value, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = name + "=" + value + "; " + expires;
}

//获取cookie
function getCookie(name) {
    var name = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
    }
    return "";
}

//清除cookie  
function clearCookie(name) {  
    setCookie(name, "", -1);  
}

//替换URL的参数值
function changeUrlArg(url, arg, val) {
    var pattern = arg + '=([^&]*)';
    var replaceText = arg + '=' + val;
    return url.match(pattern) ? url.replace(eval('/(' + arg + '=)([^&]*)/gi'), replaceText) : (url.match('[\?]') ? url + '&' + replaceText : url + '?' + replaceText);
}