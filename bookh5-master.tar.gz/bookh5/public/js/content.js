$(function() {
    
    $('body').attr('unselectable', 'on').css('user-select', 'none').on('selectstart', false);
    
    var book_id = parseInt($('#book_id').val()),
        chapter_id = parseInt($('#chapter_id').val()),
        extend_id = parseInt($('#extend_id').val()),
        channel_type = parseInt($('#channel_type').val()),
        theme = ['bg-default', 'bg-sheepskin', 'bg-green', 'bg-purple', 'bg-night'],
        color = ['#373737', '#373737', '#373737', '#373737', '#626262'],
        isLogin = parseInt($('#isLogin').val()),
        havebook = parseInt($('#addBook').attr('havebook')),
        autopay = 1,
        chapterCount = 0;
    
    //是否已加入书架
    if (havebook) {
        $('#addBook').hide();
        $('#backBookshelf').show();
    } else {
        $('#addBook').show();
        $('#backBookshelf').hide();
    }
    
    //初始化字号
    var font_size = Store.isset('setting_size') ? parseInt(Store.fetch("setting_size")) : 18;
    $('#font_size').text(font_size);
    $(".read-main").css({'font-size': font_size + "px", 'line-height': font_size * 2 + "px"});

    //初始化背景主题
    var themeIndex = Store.isset('setting_theme') ? parseInt(Store.fetch("setting_theme")) : 0;
    $('body').removeClass().addClass(theme[themeIndex]);
    $('#theme>div>a').removeClass('themebox-cur');
    $('#theme>div').eq(themeIndex).children().addClass('themebox-cur');
    $(".read-main").css({color: color[themeIndex]});
    
    //初始化自动支付
    autopay = Store.isset('setting_autopay') ? parseInt(Store.fetch("setting_autopay")) : 1;
    if (autopay) {
        $("#buy-checkbox").attr("checked", "");
    } else {
        $("#buy-checkbox").removeAttr("checked");
    }
    
    //添加事件
    $("#bookMain").click(function(e) {
        e.stopPropagation();
        if ($("#topbox").css('display') == 'none') {
            $("#topbox,#sub_nav,#chapter,#sub_btn").show();
            $("#conf").hide();
        } else {
            $("#topbox,#sub_nav").hide();
        }
    });
    
    //加入书架
    $('#addBook').on('click', function(e) {
        e.stopPropagation();
        if (!isLogin) {
            $(document).dialog({type: 'notice', infoText: '登录后再加入书架吧', autoClose: 2500, position: 'center'});
            return;
        }
        $.getJSON('/h5/user/addBook?book_id=' + book_id + "&chapter_id=" + chapter_id, function(data) {
            if (data.code == 200) {
                $(document).dialog({type: 'notice', infoText: '已成功加入书架', autoClose: 2500, position: 'center'});
                $('#addBook').hide();
                $('#backBookshelf').show();
            }
        });
    });
    
    //展示批量购买界面
    $("#toast_coupon_link").on("click", function() {
        $("#batchbuy").show();
    });
    
    //批量购买关闭按钮
    $("#batchbuy_close").on("click", function() {
        $("#batchbuy").hide();
    });
    
    //点击离线
    $("#offline_btn").on("click", function() {
        $(document).dialog({type: 'notice', infoText: '离线功能开发中', autoClose: 2500, position: 'center'});
    });
    
    //点击设置
    $('#settingBox').on('click', function(e) {
        e.stopPropagation();
        $("#sub_nav,#conf").show();
        $("#chapter,#sub_btn").hide();
    });
    
    //关闭设置
    $('#settingClose').on('click', function() {
        $("#conf").hide();
        $("#topbox,#sub_nav,#chapter,#sub_btn").show();
    });
    
    //设置小号字体
    $('.fontbox-btn-small').on('click', function(e) {
        e.stopPropagation();
        var font_size = parseInt($('.read-main').css('font-size')) - 2;
        if (font_size < 14) {
            $(document).dialog({type: 'notice', infoText: '已经是最小字号', autoClose: 2500, position: 'center'});
            font_size = 14;
        }
        $('.read-main').css({'font-size': font_size + "px", 'line-height': (font_size / 2 + font_size + 5) + "px"});
        $('#font_size').text(font_size);
        Store.store('setting_size', font_size);
    });
    
    //设置大号字体
    $('.fontbox-btn-big').on('click', function(e) {
        e.stopPropagation();
        var font_size = parseInt($('.read-main').css('font-size')) + 2;
        if (font_size > 24) {
            $(document).dialog({type: 'notice', infoText: '已经是最大字号', autoClose: 2500, position: 'center'});
            font_size = 24;
        }
        $('#font_size').text(font_size);
        $(".read-main").css({'font-size': font_size + "px", 'line-height': font_size * 2 + "px"});
        Store.store('setting_size', font_size);
    });
    
    //阅读主题背景
    $('#theme>.themeboxw').on('click', function(e) {
        e.stopPropagation();
        var index = $(this).index();
        $('body').removeClass().addClass(theme[index]);
        $('#theme>div>a').removeClass('themebox-cur');
        $('#theme>div').eq(index).children().addClass('themebox-cur');
        $(".read-main").css({color: color[index]});
        Store.store('setting_theme', index, 30);
    });
    
    //点击报错
    $('#feedbook').on('click', function(e) {
        e.stopPropagation();
        location.href = '/h5/read/feedbook?book_id=' + book_id + '&chapter_id=' + chapter_id;
    });
    
    //读取章节内容
    function getContent(book_id, chapter_id, extend_id) {
        $('#loading').show();
        var params = {book_id: book_id, chapter_id: chapter_id, cid: extend_id, channel_type: channel_type, ajax: 1};
        $.ajax({
            url: '/h5/read/content',  //请求的URL
            timeout: 2000, //超时时间设置，单位毫秒
            type: 'get',  //请求方式，get或post
            data: params,  //请求所传参数，json格式
            dataType: 'json',//返回的数据格式
            success: function(result) { //请求成功的回调函数
                var data = result.rows;
                
                //如果是来源于推广强制关注公众号
                if (result.code === 2001) {
                    location.href = '/h5/read/follow';
                    return;
                }
                //判断用户是否登录
                if (data.isvip && !data.isLogin) {
                    var jump = encodeURIComponent(location.href);
                    location.href = '/h5/login?jump=' + jump;
                    return;
                }
                
                chapter_id = data.chapter_id;
                chapterCount = data.count;
                autopay = Store.isset('setting_autopay') ? parseInt(Store.fetch("setting_autopay")) : 1;
                
                //替换URL参数值保持URL的切换状态
                replaceURI = changeUrlArg(location.href, 'chapter_id', chapter_id);
                history.replaceState(location.href, '', replaceURI);
                
                $("#loginWrap,#bottomBar").hide();
                $("#price").text(data.paycount + "书币"); //章节价格
                $("#account_recharge").text(data.book_coin + "书币"); //余额

                if (data.isvip) {
                    if (data.isbuy) { //判断用户是否已付费
                        $("#buy").hide();
                        $("#bottomBar").show();
                    } else {
                        $("body").height($(window).height());
                        if (data.book_coin < data.paycount) { //用户余额不足
                            $("#buy,#not_enough").show();
                            $("#order_btn,#toast_coupon_link").hide();
                            $("#toast_recharge_cost").text(data.paycount);
                            $("#toast_recharge_need").text(data.needcount);
                        } else {
                            $("#buy,#order_btn,#toast_coupon_link").show();
                        }
                    }
                } else {
                    $("#bottomBar").show();
                    $("#buy,#loginWrap").hide();
                }
                $('#loading').hide();
                $("#topbox,#sub_nav").hide();
                $("#title").text(data.name); //渲染章节标题
                document.title = data.name; //设置title
                $("#content").html(data.content); //渲染章节内容
                window.scroll(0, 0);
            },
            complete: function(XMLHttpRequest, status) {
                if (status == 'timeout') { //超时,status还有success,error等值的情况
                    $('#loading').hide();
                    $("#content").html("您的网络环境不稳定，无法获取服务器信息，请确保良好的网络的环境后重试。");
                    $(document).dialog({
                        buttonTextConfirm: '点击刷新',
                        content: '您的网络好像有点慢哦，请刷新重试！',
                        onClickConfirmBtn: function() {
                            window.location.reload();
                        }
                    });
                }
            }
        });
    }
    
    //自动购买章节
    function buyChapter(book_id, chapter_id, endindex) {
        endindex = endindex || 0;
        $.getJSON('/h5/pay/chapter', {book_id: book_id, chapter_id: chapter_id, endindex: endindex}, function(data) {
            if (data.code == 200 || data.code == 203) {
                if (data.rows.isbuy) {
                    $(document).dialog({type: 'notice', infoText: "本章节已购买，共花费" + data.rows.trade_coin +"个书币", autoClose: 2500, position: 'center'});
                }
            }
            getContent(book_id, chapter_id, extend_id);
        });
    }
    
    //上一页
    $('.pagePrev').on('click', function(e) {
        e.stopPropagation();
        if (chapter_id <= 1) {
            chapter_id = 1;
            $(document).dialog({type: 'notice', infoText: "已是最前章节", autoClose: 2500, position: 'center'});
        } else {
            chapter_id = chapter_id - 1;
            if (autopay) {
                buyChapter(book_id, chapter_id, 0);
            } else {
                getContent(book_id, chapter_id, extend_id);
            }
        }
    });
    
    //下一页
    $('.pageNext').on('click', function(e) {
        e.stopPropagation();
        if (chapter_id >= chapterCount) {
            chapter_id = chapterCount;
            $(document).dialog({type: 'notice', infoText: "已是最尾章节", autoClose: 2500, position: 'center'});
        } else {
            chapter_id = chapter_id + 1;
            if (autopay) {
                buyChapter(book_id, chapter_id, 0);
            } else {
                getContent(book_id, chapter_id, extend_id);
            }
        }
    });
    
    //点击报错
    $('#feedbook').on('click', function() {
        location.href = '/h5/read/feedbook?book_id=' + book_id + '&chapter_id=' + chapter_id;
    });
    
    //购买本章
    $('#order_btn').on('click', function() {
        buyChapter(book_id, chapter_id, 0);
    });
    
    //批量购买
    $('#batchbuy>li').on('click', function() {
        var endindex = parseInt($(this).attr('endindex'));
        buyChapter(book_id, chapter_id, endindex);
    });
    
    //余额不足点击充值
    $('#not_enough').on('click', function() {
        var jump = encodeURIComponent(location.href);
        location.href = '/h5/pay?jump=' + jump;
    });
    
    //初次加载内容数据
    buyChapter(book_id, chapter_id);
});