$(function() {
    
    function freeCountDowm(timestamp) { //限时免费倒计时
        var day = 0, hour = 0, minute = 0, second = 0;
        var timer = window.setInterval(function() {
            // console.log(timestamp);
            if (timestamp >= 60) {
                day = Math.floor(timestamp / 86400);
                hour = Math.floor(timestamp / 3600);
                minute = Math.floor(timestamp / 60);
                second = timestamp % 60;

                if (minute >= 60) {
                    hour = Math.floor(minute / 60);
                    minute = minute % 60;
                    if (hour >= 24) {
                        hour = hour % 24;
                    }
                } else {
                    hour = 0;
                }
            } else {
                second = timestamp;
                hour = 0;
                minute = 0;
                day = 0;
            }
            hour = parseInt(hour) < 10 && parseInt(hour) > 0 ? '0' + hour : hour;
            minute = parseInt(minute) < 10 && parseInt(minute) > 0 ? '0' + minute : minute;
            second = parseInt(second) < 10 && parseInt(second) > 0 ? '0' + second : second;
            timestamp--;
            
            $("#cdtime>em").eq(0).text(day);
            $("#cdtime>em").eq(1).text(hour);
            $("#cdtime>em").eq(2).text(minute);
            $("#cdtime>em").eq(3).text(second);
        }, 1000);
        
        if (timestamp <= 0) {
            window.clearInterval(timer);
            $("#freeTime,#freeBotLine").remove();
        }
    }
    
    //限免倒计时
    var timeout = parseInt($('#freeTime').attr('timeout'));
    if (timeout > 0) {
        freeCountDowm(timeout);
    }
    
    //新书免费换一换
    $('#free_change_xsmf').on("click", function() {
        $.getJSON('/h5/free/index', {type: 7, page: 1, length: 8, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-free-xsmf").text());
                $("#free_xsmf").html(interText(data.rows));
            }
        });
    });
    
    //精品免费换一换
    $('#free_change_jpmf').on("click", function() {
        $.getJSON('/h5/free/index', {type: 8, page: 1, length: 8, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-free-jpmf").text());
                $("#free_jpmf").html(interText(data.rows));
            }
        });
    });
    
});