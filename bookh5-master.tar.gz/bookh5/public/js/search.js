$(function() {
    
    var historyData = Store.isset('history') ? Store.fetch("history") : [];
    if (historyData.length) {
        var serText = '';
        for (var i in historyData) {
            serText += '<li>' + decodeURIComponent(historyData[i]) + '</li>';
        }
        $('#historyList').html(serText);
        $(".search-history").show();
    }
    
    //搜索历史存入Store
    var saveStore = function(keyword) {
        if ($.inArray(keyword, historyData) == -1) {
            if (historyData.length == 10) {
                historyData.pop();
            }
            historyData.unshift(keyword);
            Store.store('history', historyData);
        }
    };
    
    //清空搜索历史
    $('.his-clear').on('click', function() {
        Store.unset('history');
        $(".search-history").hide();
    });
    
    $('.hot-tag-list li').on('click', function() {
        var keyword = $(this).children().text();
        saveStore(keyword);
        window.location.href = '/h5/search/result?q=' + encodeURIComponent(keyword);
    });
    
    //点击换一换
    $('.tag-options').on('click', function() {
        $.getJSON('/h5/search/index', {shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-search-hot").text());
                $(".hot-tag-list>ul").html(interText(data.rows));
            }
        });
    });
    
    $('#keyword').on('input', function() {
        var keyword = encodeURIComponent($("#keyword").val());
        $.getJSON('/h5/search/complete', {q: keyword}, function(data) {
            if (data.code == 200) {
                var searchData = data.rows;
                if (searchData.length) {
                    var content = '';
                    for (var i in searchData) {
                        content += '<li>' + searchData[i].name + '</li>';
                    }
                    $('#sug_wraper>ul').html(content);
                    $("#sug_wraper").show();
                    
                    $('#sug_wraper li').on('click', function() {
                        var keyword = $(this).text();
                        saveStore(keyword);
                        window.location.href = '/h5/search/result?q=' + encodeURIComponent(keyword);
                    });
                } else {
                    $("#sug_wraper").hide();
                }
            }
        });
    });
    
    $('.search-btn').on('click', function() {
        var keyword = encodeURIComponent($("#keyword").val());
        saveStore(keyword);
        window.location.href = '/h5/search/result?q=' + encodeURIComponent(keyword);
    });
});