$(function() {
    var book_id = $('#book_id').val();
    document.title = $('#book-name').text() + '-钱塘看书' || '钱塘看书_正版_原创_网络小说_原创网文_好看的小说尽在其中';
    
    var asc = function(a, b) {
        return parseInt($(a).attr('data-sort')) - parseInt($(b).attr('data-sort'));
    };
    var desc = function(a, b) {
        return parseInt($(b).attr('data-sort')) - parseInt($(a).attr('data-sort'));
    };
    var sortByInput = function(sortBy) {
        var sortEle = $("#book_chapters>li").sort(sortBy);
        $("#book_chapters").empty().append(sortEle);
    };
    //排序
    $('.chapter-order').on("click", function() {
        var obj = $('.chapter-order>a');
        if (obj.text() == '逆序') {
            obj.text('顺序');
            sortByInput(desc);
        } else {
            obj.text('逆序');
            sortByInput(asc);
        }
    });
    
    $('#book_chapters>li').on('click', function() {
        var index = $(this).attr('data-sort');
        window.location.href = '/h5/read/content?book_id=' + book_id + '&chapter_id=' + index;
    });
});