$(function() {
    
    document.title = '钱塘看书_正版_原创_网络小说_原创网文_好看的小说尽在其中';
    
    //轮播图
    new Swiper('.slider-banner>.swiper-container', {
        pagination: ".swiper-pagination",
        paginationClickable: true,
        centeredSlides: false,
        autoplay: 2500,
        touchRatio: 0.5,  
        longSwipesRatio: 0.1,  
        threshold: 50,
        observer: true,
    });
    
    //男生精品换一换
    $('#change_boyhot').on("click", function() {
        $.getJSON('/index', {type: 106, page: 1, length: 6, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var boyhot = data.rows.slice(0, 4);
                var interText = doT.template($("#tmpl-boyhot").text());
                $("#index-boyhot").html(interText(boyhot));
                
                boyhot = data.rows.slice(4, 6);
                interText = doT.template($("#tmpl-boyhot-more").text());
                $("#index-boyhot-more").html(interText(boyhot));
            }
        });
    });
    
    //女生精品换一换
    $('#change_girlhot').on("click", function() {
        $.getJSON('/index', {type: 110, page: 1, length: 6, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var girlhot = data.rows.slice(0, 4);
                var interText = doT.template($("#tmpl-girlhot").text());
                $("#index-girlhot").html(interText(girlhot));
                
                girlhot = data.rows.slice(4, 6);
                interText = doT.template($("#tmpl-girlhot-more").text());
                $("#index-girlhot-more").html(interText(girlhot));
            }
        });
    });
    
    //人气新书换一换
    $('#change_hotnew').on("click", function() {
        $.getJSON('/index', {type: 102, page: 1, length: 4, shuffle: 1}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-hotnew").text());
                $("#index-hotnew").html(interText(data.rows));
            }
        });
    });
    
    //大家都在看
    var page = 1;
    $('.mod-look-more').on("click", function() {
        var obj = this;
        $(this).children('a').text('数据加载中...');
        page++;
        $.getJSON('/index/index/alllike', {page: page, length: 5}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-allLike").text());
                $("#index-allLike").append(interText(data.rows));
                $(obj).children('a').text('查看更多');
            }
        });
    });
    
    //限时免费倒计时
    function indexCountDowm(timestamp) {
        var day = 0, hour = 0, minute = 0, second = 0;
        var timer = window.setInterval(function() {
            // console.log(timestamp);
            if (timestamp >= 60) {
                day = Math.floor(timestamp / 86400);
                hour = Math.floor(timestamp / 3600);
                minute = Math.floor(timestamp / 60);
                second = timestamp % 60;

                if (minute >= 60) {
                    hour = Math.floor(minute / 60);
                    minute = minute % 60;
                    if (hour >= 24) {
                        hour = hour % 24;
                    }
                } else {
                    hour = 0;
                }
            } else {
                second = timestamp;
                hour = 0;
                minute = 0;
                day = 0;
            }
            hour = parseInt(hour) < 10 && parseInt(hour) > 0 ? '0' + hour : hour;
            minute = parseInt(minute) < 10 && parseInt(minute) > 0 ? '0' + minute : minute;
            second = parseInt(second) < 10 && parseInt(second) > 0 ? '0' + second : second;
            timestamp--;
            
            $("#timeout>em").eq(0).text(day);
            $("#timeout>em").eq(1).text(hour);
            $("#timeout>em").eq(2).text(minute);
            $("#timeout>em").eq(3).text(second);
        }, 1000);
        
        if (timestamp <= 0) {
            window.clearInterval(timer);
            $("#indexTime,#indexBotLine").remove();
        }
    }
    
    //限免倒计时
    var timeout = parseInt($('#indexTime').attr('timeout'));
    if (timeout > 0) {
        indexCountDowm(timeout);
    }
});