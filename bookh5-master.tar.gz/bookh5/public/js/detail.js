$(function() {
    var book_id = $('#book_id').val();
    document.title = $('.detail-title').text() || '书籍详情';
    
    var bookIntro = $('#moreText').text();
    if (bookIntro.length > 100) {
        $("#moreText").hide();
        $('.open-flag,#cutText').show();
    } else {
        $("#moreText").show();
        $('.open-flag,#cutText').hide();
    }
    
    //展开书籍详情
    $('.detail-intro').on('click', function() {
        $('.open-flag,#cutText').hide();
        $("#moreText").show();
    });
    
    //加入书架
    $('.addbook').on('click', function() {
        $.getJSON('/h5/user/addBook', {book_id: book_id}, function(data) {
            if (data.code == 200) {
                $('.addbook').addClass('havebook').removeClass('addbook');
            } else if (data.code == 201) {
                $(document).dialog({type: 'notice', infoText: "登录后再加入书架吧", autoClose: 2500, position: 'center'});
            } else if (data.code == 202) {
                $(document).dialog({type: 'notice', infoText: "该书已在书架中", autoClose: 2500, position: 'center'});
            }
        });
    });
    
    //相似书籍换一换
    $('#detail_change_similar').on("click", function() {
        var cate_id = $("#detail_similar").attr('cate_id');
        $.getJSON('/h5/detail/changeSimilar', {cate_id: cate_id}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-detail-similar").text());
                $("#detail_similar").html(interText(data.rows));
            }
        });
    });
    
    //大家都在看换一换
    $('#detail_change_allLike').on("click", function() {
        $.getJSON('/h5/detail/changeLike', {}, function(data) {
            if (data.code == 200 && data.rows.length) {
                var interText = doT.template($("#tmpl-detail-allLike").text());
                $("#detail_allLike").html(interText(data.rows));
            }
        });
    });
    
});