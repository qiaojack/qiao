var imgPath = '', android_download = '', ios_download = '';
if (location.hostname.indexOf("31xs") >= 0) {
    imgPath = 'https://static.jiuwei.com/images/adext1.png';
    android_download = "https://static.jiuwei.com/apk/1/qt_31-1.1.7.apk";
    ios_download = "https://itunes.apple.com/cn/app/id1387361479?mt=8";
}
if (location.hostname.indexOf("147xs") >= 0) {
    imgPath = 'https://static.jiuwei.com/images/adext2.png';
    android_download = "https://static.jiuwei.com/apk/1/qt_147-1.1.7.apk";
    ios_download = "https://itunes.apple.com/cn/app/id1387361479?mt=8";
}
if (location.hostname.indexOf("qushuba") >= 0) {
    imgPath = 'https://static.jiuwei.com/images/adext1.png';
    android_download = "https://static.jiuwei.com/apk/1/qt_qushuba-1.1.7.apk";
    ios_download = "https://itunes.apple.com/cn/app/id1387361479?mt=8";
}

var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

var downloadPath = android_download;
if (isiOS) {
    downloadPath = ios_download;
}

if (downloadPath != '') {
    var innerHTML = '<a id="jwextab" href="' + downloadPath + '" style="z-index:99999; position:absolute; right:0; top:40%;">'
        + '<span style="display:block; width:70px; height:70px; background: url(\'' + imgPath + '\');background-size: 100% 100%;border-radius:2px;"></span>'
        + '</a>';
    document.writeln(innerHTML);
    window.onscroll = function(){document.getElementById('jwextab').style.position="fixed";}
}