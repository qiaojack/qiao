$(function() {
    
    var all_select = 0;
    var isLogin = parseInt($('#isLogin').val());
    
    if (!isLogin) {
        $(".bookshelf-remind").show();
        $(".bookshelf-list").hide();
    }
    
    //点击编辑
    $("#edit").click(function() {
        $("#editbar,#edit_shelf,#finish,.check_box").show();
        $("#edit,#amount").hide();
        $('#bookManage>li').unbind('click');
        $('#bookManage').off('click');

        $('#bookManage>li').on('click', function() {
            var index = $(this).index();
            var checked = $('.check_box').eq(index).prop('checked') ? false : true;
            $('.check_box').eq(index).prop('checked', checked);
            $('.check_box:checked').length>0? $('#del_btn').removeAttr('disabled'): $('#del_btn').attr('disabled','disabled');
            $('.check_box:checked').length>0? $('#del_btn').removeClass('disabled'): $('#del_btn').addClass('disabled','disabled');
            $('#del_btn').text('删除（'+$('.check_box:checked').length+'本）');
        });
    });
    
    //点击完成
    $("#finish").on("click", function() {
        $('.check_box').prop('checked', false);
        $(".check_box,#edit_shelf,#finish,#editbar").hide();
        $("#amount,#edit").show();
    });
    
    //全选书籍
    $('#select_all').on('click', function() {
        if (all_select == 0) {
            $('.check_box').prop('checked', true);
            $('#del_btn').removeAttr('disabled', "").removeClass("disabled").text('删除（' + $('.check_box:checked').length + '本）');
            $('#select_all').text('取消全选');
            all_select = 1;
        } else {
            $('.check_box').prop('checked', false);
            $('#del_btn').attr('disabled', 'disabled').addClass("disabled").text('删除');
            $('#select_all').text('全选');
            all_select = 0;
        }
    });
    
    //删除书籍
    $('#del_btn').on("click", function() {
        var read_book = [];
        $('.check_box:checked').forEach(function(item) {
            read_book.push(item.value);
            $("#bid_" + item.value).remove();
        });
        if (read_book.length) {
            $.post('/h5/user/delbook', {read_book: read_book}, function(res) {
                if (res.code == 200) {
                }
            }, 'json');
        }
    });
    
});


