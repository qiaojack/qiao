$(function() {
    
    $('#loading').hide();
    
    $(document).dialog({
        buttonTextConfirm: '刷新重试',
        content: '您的网络好像有问题！请重试！',
        onClickConfirmBtn: function() {
            alert(1111);
        }
    });
    
    function changeUrlArg(url, arg, val) {
        var pattern = arg + '=([^&]*)';
        var replaceText = arg + '=' + val;
        return url.match(pattern) ? url.replace(eval('/(' + arg + '=)([^&]*)/gi'), replaceText) : (url.match('[\?]') ? url + '&' + replaceText : url + '?' + replaceText);
    }
    
    $("#pagenext").on('click', function() {
        console.log(location.href);
        replaceURI = changeUrlArg(location.href, 'chapter_id', 19);
        history.replaceState(location.href, "", replaceURI);
        
    });
    
});


