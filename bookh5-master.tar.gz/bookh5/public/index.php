<?php
/**
 * yafphp项目主入口
 */

ini_set("display_errors", "On");
//项目根目录
define('APP_PATH', realpath(dirname(__FILE__) . '/../'));

//models所在目录
define('MODELS_PATH', APP_PATH . '/application/models/');

//对外访问的URL(末尾勿加'/')
$domain = $_SERVER['HTTP_HOST'];
define('__DOMAIN_URL__', $_SERVER['REQUEST_SCHEME'] . '://' . $domain);

//回调域名
define('__CALLBACK_URL__', 'http://wap.jiuwei.com');

//静态URL(末尾勿加'/')
define('__STATIC_URL__', 'http://static.jiuwei.com');

define('_BOOK_CONTENT__', '/data2/projectdata/');
//develop 为开发环境  product 为生产环境
$app = new Yaf_Application(APP_PATH . "/config/application.ini", "develop");
//$app = new Yaf_Application(APP_PATH . '/config/application.ini', 'product');

//测试
$app->bootstrap()->run();
